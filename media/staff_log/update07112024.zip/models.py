from django.db import models,transaction
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
import os


class login_table(models.Model):
    username = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    user_type = models.CharField(max_length=50)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    # created_on=models.DateTimeField()
    # updated_on=models.DateTimeField()
    # created_by=models.IntegerField()
    # updated_by=models.IntegerField()
    
    class Meta:
        db_table = "login"


class category_table(models.Model):
    name = models.CharField(max_length=150)
    image = models.ImageField(upload_to='images/', max_length=300)
    description = models.CharField(max_length=300)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="categories"


class package_table(models.Model):
    name = models.CharField(max_length=150)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="packages"


class brand_table(models.Model):
    name = models.CharField(max_length=150)
    image = models.ImageField(upload_to='images/', max_length=300)
    description = models.CharField(max_length=300)
    category_id = models.CharField(max_length=300)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="brands"


class uom_table(models.Model):
    name = models.CharField(max_length=150)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="uom"

class holiday_table(models.Model):
    date = models.DateField()
    year = models.IntegerField()
    name = models.CharField(max_length=50)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "public_holidays"

class frequency_table(models.Model):
    name = models.CharField(max_length=150)
    maintenance_type = models.CharField(max_length=50)
    frequency_category = models.CharField(max_length=50)
    frequency = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    times = models.CharField(max_length=50)
    frequency_code = models.CharField(max_length=100)
    description = models.TextField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="frequency_master"


class system_table(models.Model):
    name = models.CharField(max_length=50)
    parent_code_ref = models.CharField(max_length=100)
    parent_code = models.CharField(max_length=100)
    category_id = models.IntegerField(default=0)
    frequency_id  = models.CharField(max_length=200)
    report_emails  = models.CharField(max_length=200)
    description  = models.CharField(max_length=500)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="asset_system"

class system_action(models.Model):
    name = models.CharField(max_length=500)
    asset_group_id = models.IntegerField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="actions"

class system_finding(models.Model):
    name = models.CharField(max_length=500)
    asset_group_id = models.IntegerField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="findings"


class system_description(models.Model):
    name = models.CharField(max_length=500)
    asset_group_id = models.IntegerField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="descriptions"

class system_checklist(models.Model):
    description = models.CharField(max_length=300,blank=True, null=True)
    question = models.CharField(max_length=300,blank=True, null=True)
    asset_group_id = models.IntegerField()
    frequency_id = models.CharField(max_length=3,blank=True, null=True)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField(blank=True, null=True)
    updated_on=models.DateTimeField(blank=True, null=True)
    created_by=models.IntegerField(blank=True, null=True)
    updated_by=models.IntegerField(blank=True, null=True)
    class Meta:
        db_table="checklist"






class vendor_table(models.Model):
    company_code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=50)
    primary_technician = models.IntegerField()
    contact_person = models.CharField(max_length=50)
    customer_prefix = models.CharField(max_length=50)
    image = models.ImageField(upload_to='images/', max_length=50)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    postal_code = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    admin_signature = models.ImageField(upload_to='images/', max_length=100)
    description = models.CharField(max_length=300)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()
    company_id = models.IntegerField()
    logo = models.ImageField(upload_to='', max_length=50)

    class Meta:
        db_table = "vendors"

    



class ProjectIncharge(models.Model):
    project_id = models.IntegerField()
    employee_id = models.CharField(max_length=50)
    vendor_id = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="project_incharge"


class project_vendor_table(models.Model):
    project_id = models.IntegerField()
    vendor_id = models.IntegerField(default=0)
    incharge_id = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="project_vendor"
        


from django.db import models
from django.utils import timezone

from django.utils import timezone

class project_table(models.Model):
    num_series = models.IntegerField()
    project_code = models.CharField(max_length=50, unique=True, blank=True)
    name = models.CharField(max_length=50)
    prefix = models.CharField(max_length=50)
    description = models.CharField(max_length=300)
    vendor_id = models.CharField(max_length=50)
    package_id = models.IntegerField()
    customer_id = models.IntegerField()
    customer_employee_id = models.CharField(max_length=50)
    start_date = models.DateField()
    end_date = models.DateField()
    project_value = models.CharField(max_length=30)
    project_incharge = models.CharField(max_length=300)
    technician_id = models.IntegerField()
    incharge_email = models.CharField(max_length=300)
    incharge_phone = models.CharField(max_length=300)
    package = models.CharField(max_length=300)
    vendor_assigned = models.CharField(max_length=50)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField(default=timezone.now)
    updated_on = models.DateTimeField(auto_now=True)
    created_by = models.IntegerField()
    updated_by = models.IntegerField()
    reference_id = models.IntegerField(null=True, blank=True) 

    class Meta:
        db_table = "projects"

    





class pk_project_table(models.Model):
    name = models.CharField(max_length=50)
    prefix = models.CharField(max_length=50)
    project_code = models.CharField(max_length=50, unique=True, blank=True)
    description = models.CharField(max_length=300)
    customer_id = models.IntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    project_value = models.CharField(max_length=300)
    project_incharge = models.CharField(max_length=300)
    technician_id = models.IntegerField()
    incharge_email = models.CharField(max_length=300)
    incharge_phone = models.CharField(max_length=300)
    package = models.CharField(max_length=300)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField(default=timezone.now)
    updated_on = models.DateTimeField(auto_now=True)
    

    class Meta:
        db_table = "pk_projects" 


class customer_table(models.Model):
    name = models.CharField(max_length=150)
    employee_id = models.CharField(max_length=50)
    description = models.CharField(max_length=200)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="customer"

class asset_table(models.Model):
    num_series = models.CharField(max_length=50, unique=True)
    asset_item_code = models.CharField(max_length=50)
    vendor_id = models.IntegerField()
    customer_id = models.IntegerField()
    project_id= models.IntegerField(default=0)  
    asset_parent_id = models.IntegerField(default=0)
    asset_parent_name = models.CharField(max_length=100)
    asset_group_id = models.IntegerField(default=0)
    frequency_id = models.CharField(max_length=50)
    frequency_time = models.CharField(max_length=300)
    brand_id = models.IntegerField(default=0)
    category_id = models.IntegerField(default=0)
    technician_id = models.IntegerField()
    item_id = models.IntegerField()
    floor_plan= models.FileField(upload_to='', max_length=300)
    name = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100)
    estimated_life = models.CharField(max_length=100)
    qrcode = models.CharField(max_length=300)
    commissioning_date = models.DateField()
    service_start_date = models.DateField()
    warranty_start_date = models.DateField(blank=True, null=True)
    warranty_end_date = models.DateField(blank=True, null=True)
    description = models.CharField(max_length=500)
    is_camera = models.IntegerField()
    is_smart_sensor = models.IntegerField()
    sensor_type = models.CharField(max_length=50)
    report_type = models.CharField(max_length=50)
    macAddress = models.CharField(max_length=300)
    threshold = models.CharField(max_length=300)
    is_pmt = models.IntegerField(default=1)
    quantity = models.CharField(max_length=10)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    reference_id = models.IntegerField(null=True, blank=True) 
    class Meta:
        db_table="assets"


class qar_table(models.Model):
    task_id = models.CharField(max_length=50, null=True, blank=True)
    year = models.IntegerField(default=0)
    month = models.IntegerField(default=0)
    customer_id = models.IntegerField(default=0)
    project_id = models.IntegerField()
    asset_id = models.IntegerField(default=0)
    asset_group_id = models.IntegerField(default=0)
    frequency_id = models.IntegerField(default=0)
    file_name = models.CharField(max_length=250)
    qar_status = models.CharField(max_length=20, default='generating')  
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="qar_track"


class qar_report_status(models.Model):
    task_id = models.CharField(max_length=50)
    month = models.CharField(max_length=10)
    year = models.CharField(max_length=10)
    project_id = models.IntegerField()
    customer_id = models.IntegerField()
    generated_by = models.IntegerField()
    generated_on = models.TimeField()
    qar_status = models.CharField(max_length=20, default='generating')  
    file = models.CharField(max_length=150)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()

    class Meta:
        db_table="qar_followup"

class asset_list_table(models.Model):
    num_series = models.CharField(max_length=50, unique=True)
    asset_item_code = models.CharField(max_length=50)
    vendor_id = models.IntegerField()
    customer_id = models.IntegerField()
    customer_name = models.CharField(max_length=100)
    quantity = models.CharField(max_length=10)    
    project_id= models.IntegerField(default=0)
    project = models.CharField(max_length=150)
    name = models.CharField(max_length=50)
    qrcode = models.CharField(max_length=300)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    asset_group_id = models.IntegerField(default=0)
    asset_group_name = models.CharField(max_length=150)
    item_id = models.IntegerField()
    item_name = models.CharField(max_length=150)
    brand_id = models.IntegerField(default=0)
    frequency_id = models.CharField(max_length=50)
    brand_name = models.CharField(max_length=150)
    category_id = models.IntegerField(default=0)
    category = models.CharField(max_length=150)
    description = models.CharField(max_length=500)
    file_name= models.FileField(upload_to='', max_length=300)
    location = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100)
    estimated_life = models.CharField(max_length=100)
    commissioning_date = models.DateField()
    service_start_date = models.DateField()
    warranty_start_date = models.DateField(blank=True, null=True)
    warranty_end_date = models.DateField(blank=True, null=True)
    updated_on=models.DateTimeField()
    asset_child = models.IntegerField()
    pending = models.IntegerField()
    total_tickets = models.IntegerField()
    technician_id = models.IntegerField()
    is_camera = models.IntegerField()
    is_smart_sensor = models.IntegerField()
    macAddress = models.CharField(max_length=300)
    threshold = models.CharField(max_length=300)
    report_type = models.CharField(max_length=50)
    class Meta:
        db_table="asset_list"





class qar_parent_table(models.Model):
    asset_id = models.IntegerField(default=0)
    asset_system_id = models.IntegerField(default=0)
    frequency = models.CharField(max_length=100)
    question = models.TextField()
    frequency_id = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="qar_parent"



class asset_vendor_table(models.Model):
    company_id = models.IntegerField(default=0)
    customer_id = models.IntegerField(default=0)
    project_id = models.IntegerField()
    vendor_id = models.IntegerField(default=0)
    asset_id = models.IntegerField(default=0)
    technician_id = models.IntegerField(default=0)
    frequency_id = models.CharField(max_length=50)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="asset_vendor"
        

class pk_asset_table(models.Model):
    customer_id = models.IntegerField()
    project_id = models.IntegerField()
    asset_parent_id = models.IntegerField(default=0)
    asset_group_id = models.IntegerField()
    frequency_id = models.CharField(max_length=100)
    frequency_time = models.CharField(max_length=300)
    brand_id = models.IntegerField()
    category_id = models.IntegerField()
    technician_id = models.IntegerField()
    item_id = models.IntegerField()
    num_series = models.CharField(max_length=50, unique=True)
    file_name = models.CharField(max_length=300, unique=True)
    asset_item_code = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100)
    estimated_life = models.CharField(max_length=100)
    qrcode = models.CharField(max_length=300)
    commissioning_date = models.DateField()
    service_start_date = models.DateField()
    warranty_start_date = models.DateField(blank=True, null=True)
    warranty_end_date = models.DateField(blank=True, null=True)
    description = models.CharField(max_length=500)
    is_camera = models.IntegerField()
    is_smart_sensor = models.IntegerField()
    sensor_type = models.CharField(max_length=50)
    report_type = models.CharField(max_length=50)
    macAddress = models.CharField(max_length=300)
    threshold = models.CharField(max_length=300)
    is_pmt = models.IntegerField(default=1)
    quantity = models.CharField(max_length=10)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    
    class Meta:
        db_table="pk_assets"


class DateMaster(models.Model):
    dd = models.IntegerField()
    mm = models.IntegerField()
    yyyy = models.IntegerField()
    mdate = models.DateField()
    day = models.CharField(max_length=50)
    day_no = models.IntegerField()
    week_no = models.IntegerField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()    
    class Meta:
        db_table="date_master"






class ticket_table(models.Model):
    num_series = models.CharField(max_length=50,blank=True)
    ticket_no = models.CharField(max_length=50,blank=True)
    vendor_id = models.IntegerField(null=True)
    category_id = models.IntegerField(null=True)
    system_id = models.IntegerField(null=True)
    customer_id = models.IntegerField(null=True)
    project_id = models.IntegerField(null=True)
    asset_item_id = models.IntegerField()
    asset_ref_id = models.IntegerField()
    technician_id = models.IntegerField(null=True,default='0')
    frequency_id = models.CharField(max_length=50,blank=True)
    is_technician_approved = models.IntegerField(default=0,blank=True)
    ticket_completed_by = models.CharField(max_length=50,blank=True)
    ticket_date = models.DateField(blank=True, null=True)
    schedule_date = models.DateField(blank=True, null=True)
    ticket_time = models.TimeField(blank=True, null=True)
    priority = models.CharField(max_length=50,default='Normal')
    ticket_type = models.CharField(max_length=50,blank=True,default='PMT')
    description = models.CharField(max_length=500,blank=True)
    action = models.CharField(max_length=1000,blank=True)
    findings = models.CharField(max_length=1000,blank=True)
    remarks = models.CharField(max_length=255,blank=True)
    requested_by = models.IntegerField(blank=True)
    approved_by = models.IntegerField(blank=True)
    ticket_status = models.CharField(max_length=50,default='Pending')
    is_checklist = models.IntegerField(default=0,blank=True)
    is_signature = models.IntegerField(default=0)
    is_endorsed = models.IntegerField(default=0)
    is_completed = models.IntegerField(default=0)
    is_uploaded = models.IntegerField(default=0)
    signature = models.FileField(upload_to='',max_length=300,blank=True)
    customer_signature = models.FileField(upload_to='',max_length=300,blank=True)
    customer_name = models.CharField(max_length=50,blank=True)
    file_name = models.FileField(upload_to='file/',max_length=300,blank=True)
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    total_hrs = models.CharField(max_length=50,blank=True)
    auto_id = models.IntegerField(blank=True, null=True)
    is_sensor_ticket = models.IntegerField(default=0)
    is_customer_signed = models.IntegerField(default=0)
    signed_by = models.IntegerField(default=0)
    customer_approved_on=models.DateTimeField(blank=True, null=True)
    name = models.CharField(max_length=300,blank=True)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField(blank=True, null=True)
    updated_on=models.DateTimeField(blank=True, null=True)
    created_by=models.IntegerField(blank=True, null=True)
    updated_by=models.IntegerField(blank=True, null=True)
    color = models.CharField(max_length=50,blank=True)
    reference_id = models.IntegerField(null=True, blank=True) 
    
    class Meta:
        db_table="tickets"

class pk_ticket_table(models.Model):
    ticket_no = models.CharField(max_length=50,blank=True)
    num_series = models.CharField(max_length=50,blank=True)
    customer_id = models.IntegerField(null=True)
    project_id = models.IntegerField(null=True)
    asset_item_id = models.IntegerField(null=True)
    technician_id = models.IntegerField(null=True,default='0')
    frequency_id = models.CharField(max_length=50,blank=True)
    is_technician_approved = models.IntegerField(default=0,blank=True)
    ticket_completed_by = models.CharField(max_length=50,blank=True)
    ticket_date = models.DateField(blank=True, null=True)
    ticket_time = models.TimeField(blank=True, null=True)
    priority = models.CharField(max_length=50,default='normal')
    ticket_type = models.CharField(max_length=50,blank=True,default='PMT')
    description = models.CharField(max_length=500,blank=True)
    action = models.CharField(max_length=1000,blank=True)
    findings = models.CharField(max_length=1000,blank=True)
    remarks = models.CharField(max_length=255,blank=True)
    requested_by = models.IntegerField(blank=True)
    approved_by = models.IntegerField(blank=True)
    ticket_status = models.CharField(max_length=50,default='pending')
    is_checklist = models.IntegerField(default=0,blank=True)
    is_signature = models.IntegerField(default=0)
    is_completed = models.IntegerField(default=0)
    is_uploaded = models.IntegerField(default=0)
    signature = models.FileField(upload_to='signature/',max_length=300,blank=True)
    file_name = models.FileField(upload_to='file/',max_length=300,blank=True)
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    total_hrs = models.CharField(max_length=50,blank=True)
    auto_id = models.IntegerField(blank=True, null=True)
    is_sensor_ticket = models.IntegerField(default=0)
    is_customer_signed = models.IntegerField(default=0)
    signed_by = models.IntegerField(default=0)
    customer_approved_on=models.DateTimeField(blank=True, null=True)
    name = models.CharField(max_length=300,blank=True)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField(blank=True, null=True)
    updated_on=models.DateTimeField(blank=True, null=True)
    
    class Meta:
        db_table="tts_tickets"



class ticket_summary_table(models.Model):
    ticket_no = models.CharField(max_length=50,blank=True)
    ticket_date = models.DateField(blank=True, null=True)
    ticket_close_date = models.DateField(blank=True, null=True)
    job_type = models.CharField(max_length=50,blank=True)
    frequency_id = models.CharField(max_length=50,blank=True)
    service_frequency = models.CharField(max_length=50,blank=True)
    frequency_code = models.CharField(max_length=50,blank=True)
    customer_name = models.CharField(max_length=150)
    technician_name = models.CharField(max_length=150)
    asset_group_code = models.CharField(max_length=150)
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)
    remarks = models.CharField(max_length=255,blank=True)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    ticket_status = models.CharField(max_length=50)
    priority = models.CharField(max_length=50,default='Normal')
    customer_id = models.IntegerField(null=True)
    project_id = models.IntegerField(null=True)
    total_time = models.CharField(max_length=50,blank=True)
    valid_customer_id = models.IntegerField(null=True)
    valid_project_id = models.IntegerField(null=True)
    description = models.CharField(max_length=500,blank=True)
    action = models.CharField(max_length=1000,blank=True)

     
    
    class Meta:
        db_table="ticket_summary"




class ticket_list_table(models.Model):
    ticket_date = models.DateField(blank=True, null=True)
    ticket_no = models.CharField(max_length=50,blank=True)
    customer_id = models.IntegerField(null=True)
    vendor_id = models.IntegerField(null=True)
    project_id = models.IntegerField(null=True)
    asset_item_id = models.IntegerField()
    category_id = models.IntegerField(null=True)
    asset_group_id = models.IntegerField(null=True)
    technician_id = models.IntegerField(null=True,default='0')
    frequency_id = models.CharField(max_length=50,blank=True)
    is_technician_approved = models.IntegerField(default=0,blank=True)
    ticket_completed_by = models.CharField(max_length=50,blank=True)
    ticket_time = models.TimeField(blank=True, null=True)
    ticket_type = models.CharField(max_length=50)
    asset_description = models.CharField(max_length=500,blank=True)
    location = models.CharField(max_length=100,blank=True)
    description = models.CharField(max_length=150,blank=True)
    action = models.TextField(blank=True)
    findings = models.TextField(blank=True)
    remarks = models.CharField(max_length=255,blank=True)
    requested_by = models.IntegerField(blank=True)
    approved_by = models.IntegerField(blank=True)
    priority = models.CharField(max_length=50)
    ticket_status = models.CharField(max_length=50)
    is_checklist = models.IntegerField(default=0,blank=True)
    is_signature = models.IntegerField(default=0)
    is_completed = models.IntegerField(default=0)
    is_uploaded = models.IntegerField(default=0)
    signature = models.FileField(upload_to='signature/',max_length=300,blank=True)
    file_name = models.FileField(upload_to='file/',max_length=300,blank=True)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    total_hrs = models.CharField(max_length=50,blank=True)
    auto_id = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=300,blank=True)
    created_on=models.DateTimeField(blank=True, null=True)
    updated_on=models.DateTimeField(blank=True, null=True)
    customer = models.CharField(max_length=150)
    project = models.CharField(max_length=150)
    vendor = models.CharField(max_length=150)
    category = models.CharField(max_length=150)
    frequency = models.CharField(max_length=150)
    quantity = models.IntegerField()
    incharge_email = models.CharField(max_length=300)
    asset_group_name = models.CharField(max_length=150)
    parent_code = models.CharField(max_length=150)
    asset_group_description = models.CharField(max_length=300)
    asset = models.CharField(max_length=150)
    asset_item_code = models.CharField(max_length=50)
    item_name = models.CharField(max_length=100)
    technician = models.CharField(max_length=150)
    ages = models.IntegerField()
    response =  models.CharField(max_length=150)
    repair_time =  models.CharField(max_length=150)
    is_customer_signed = models.IntegerField(default=0)
    signed_by = models.IntegerField(default=0)    
    
    class Meta:
        db_table="list_tickets"




class complaint_table(models.Model):
    vendor_id = models.IntegerField()
    asset_id = models.IntegerField()
    project_id = models.IntegerField()
    subject = models.CharField(max_length=500)
    contact_person = models.CharField(max_length=500)
    contact_phone = models.CharField(max_length=500)
    remarks = models.CharField(max_length=500)
    complaint_status = models.CharField(max_length=50,default='open')
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField()
    updated_on=models.DateTimeField()
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="complaints"




from django.core.exceptions import ValidationError

class employee_table(models.Model):
    employee_code = models.CharField(max_length=15, unique=True)
    employee_role = models.CharField(max_length=50)
    user_role = models.CharField(max_length=50)
    name = models.CharField(max_length=150)
    username = models.CharField(max_length=150)
    finger_print = models.CharField(max_length=150)
    address_line1 = models.CharField(max_length=150)
    address_line2 = models.CharField(max_length=150, blank=True, null=True)
    password = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    postal_code = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    mobile = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(max_length=255)
    certificate = models.FileField(upload_to='', max_length=300, blank=True, null=True)
    is_superadmin = models.BooleanField(default=False)
    is_scheduler = models.BooleanField(default=False)
    is_technician = models.BooleanField(default=False)
    is_supervisor = models.BooleanField(default=False)
    is_foreigner = models.BooleanField(default=False)
    is_gps = models.BooleanField(default=False)
    is_photo = models.BooleanField(default=False)
    is_qr = models.BooleanField(default=False)
    is_signature = models.BooleanField(default=False)
    vehicle_number = models.CharField(max_length=50)
    color = models.CharField(max_length=7)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    vendor_id = models.IntegerField(default=0)
    company_id = models.IntegerField(default=0)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    updated_by = models.IntegerField()
    device_id = models.CharField(max_length=20)
    fcm_token = models.CharField(max_length=100)
    auth_id = models.IntegerField()
    emp_reference_id = models.IntegerField(null=True, blank=True) 
    tec_reference_id = models.IntegerField(null=True, blank=True) 

    class Meta:
        db_table = "employee"



class pk_employee_table(models.Model):
    user_code = models.IntegerField()
    company_id = models.IntegerField(default=0)
    name = models.CharField(max_length=50)
    package = models.IntegerField()
    project_id = models.CharField(max_length=250)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    alternate_phone = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    user_type = models.CharField(max_length=50)
    signature = models.CharField(max_length=100)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True) 
    class Meta:
        db_table = "pk_tts_employee"


class pk_vendor_emp_table(models.Model):
    staff_id = models.IntegerField(default=0)
    customer_id = models.IntegerField(default=0)
    name = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    is_admin = models.IntegerField()    
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True) 
    class Meta:
        db_table = "pk_vendor_employee"



class pk_technician_table(models.Model):
    technician_code = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    user_name = models.CharField(max_length=100)
    company_id = models.IntegerField()
    technician_type = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    designation = models.CharField(max_length=100)
    ic_no = models.CharField(max_length=100)
    dob = models.DateField(null=True)
    permit_expiry = models.DateField(null=True)
    file_name = models.CharField(max_length=100)
    description = models.CharField(max_length=300)
    package = models.CharField(max_length=300)
    remarks = models.CharField(max_length=300)
    is_logged = models.CharField(max_length=50)
    fcm_token = models.CharField(max_length=1500)
    device_token = models.CharField(max_length=500)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True) 
    class Meta:
        db_table = "pk_technicians"
   

class AdminRoles(models.Model):
    name = models.CharField(max_length=150)
    descriptions = models.CharField(max_length=150)
    status = models.IntegerField(default=1)
    is_active = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "admin_roles"


class AdminModules(models.Model):
    name = models.CharField(max_length=150)
    sort_order_no = models.IntegerField()
    is_vendor = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "admin_module"

class AdminPrivilege(models.Model):
    role_id = models.IntegerField()
    module_id = models.IntegerField()
    vendor_id = models.IntegerField()
    is_create = models.IntegerField(default=0)
    is_read = models.IntegerField(default=0)
    is_update = models.IntegerField(default=0)
    is_delete = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "admin_privilege"



class UserRoles(models.Model):
    name = models.CharField(max_length=150)
    descriptions = models.CharField(max_length=150)
    status = models.IntegerField(default=1)
    is_active = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "user_roles"


class UserModules(models.Model):
    name = models.CharField(max_length=150)
    sort_order_no = models.IntegerField()
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "user_module"

class UserPrivilege(models.Model):
    role_id = models.IntegerField()
    module = models.CharField(max_length=150)
    is_create = models.IntegerField(default=0)
    is_read = models.IntegerField(default=0)
    is_update = models.IntegerField(default=0)
    is_delete = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()

    class Meta:
        db_table = "user_privilege"








class company_table(models.Model):
    name = models.CharField(max_length=150)
    prefix = models.CharField(max_length=10)
    address_line1 = models.CharField(max_length=150)
    address_line2 = models.CharField(max_length=150)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    state_code = models.CharField(max_length=50)
    gstin = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    mobile = models.CharField(max_length=15)
    email = models.CharField(max_length=30)
    fax = models.CharField(max_length=30)
    tax_id = models.IntegerField()
    contact_person = models.CharField(max_length=50)
    cp_phone = models.CharField(max_length=15)
    cp_mobile = models.CharField(max_length=15)
    cp_email = models.CharField(max_length=30)
    report_email = models.CharField(max_length=30)
    opening_balance = models.IntegerField()
    latitude = models.CharField(max_length=50)
    longitude = models.CharField(max_length=50)
    logo = models.ImageField(upload_to='images/', max_length=50)
    logo_small = models.ImageField(upload_to='images/', max_length=50)
    logo_invoice = models.ImageField(upload_to='images/', max_length=50)
    # enc_code = models.CharField(max_length=250)
    company_code = models.CharField(max_length=50)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(auto_now_add=True)
    created_by=models.IntegerField()
    updated_by=models.IntegerField()
    class Meta:
        db_table="company"





class TicketChecklistTable(models.Model):
    ticket_id = models.IntegerField()
    asset_group_id = models.IntegerField()
    frequency_id = models.IntegerField(default=0)
    checklist_id = models.IntegerField(default=0)
    is_checked = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()
    created_by = models.IntegerField()
    updated_by = models.IntegerField()
    reference_id = models.IntegerField(null=True, blank=True) 

    class Meta:
        db_table = "ticket_checklist"


class pk_ticket_checklist_table(models.Model):
    ticket_id = models.IntegerField()
    asset_group_id = models.IntegerField()
    frequency_id = models.IntegerField(default=0)
    checklist_id = models.IntegerField(default=0)
    is_checked = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()    

    class Meta:
        db_table = "pk_checklist"




class product_table(models.Model):
    product_code = models.CharField(max_length=50)
    name = models.CharField(max_length=150)
    description = models.TextField()
    image = models.CharField(max_length=100)
    customer_id = models.IntegerField()
    category_id = models.IntegerField(default=0)
    subcategory_id = models.IntegerField(default=0)
    brand_id = models.CharField(max_length=50)
    uom = models.CharField(max_length=50)
    quantity = models.CharField(max_length=30)
    mrp = models.CharField(max_length=30)
    selling_price = models.CharField(max_length=50)
    is_featured = models.IntegerField(default=0)
    is_stock = models.IntegerField(default=0)
    is_active = models.IntegerField(default=1)
    status = models.IntegerField(default=1)
    created_on = models.DateTimeField()
    updated_on = models.DateTimeField()    
    created_by = models.IntegerField(default=0)    

    class Meta:
        db_table = "pk_products"


class TaskStatus(models.Model):
    user_id = models.IntegerField()
    task_id = models.CharField(max_length=255)  
    project_id = models.IntegerField()
    zip_file = models.CharField(max_length=150)
    created_on = models.DateTimeField()
    status = models.CharField(max_length=50)  # 'PENDING', 'SUCCESS', 'FAILURE'
    updated_on = models.DateTimeField()
    error_message = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "celery_task"