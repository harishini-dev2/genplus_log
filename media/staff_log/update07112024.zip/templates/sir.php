<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Frequency extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Asia/Singapore');
		$this->load->model('common_model','common');
		$this->load->model('admin/frequency_model','freq');
	}
	
	public function index()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/nav_bar');
		$this->load->view('includes/side_bar');
		$this->load->view('admin/frequency');
	}

	public function add_frequency()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/nav_bar');
		$this->load->view('includes/side_bar');
		$this->load->view('admin/add_frequency');
	}

	public function insert(){

		$table='frequency_master';

		$data=array(
			'maintenance_type'=>$this->input->post('maintenance_type'),
			'frequency_category'=>$this->input->post('frequency_category'),
			'frequency'=>$this->input->post('frequency'),
			'times'=>$this->input->post('times'),
			'frequency_code'=>$this->input->post('frequency_code'),
			'name'=>$this->input->post('name'),
			'description'=>$this->input->post('description'),
			'is_active'=>1,
			'status'=>1,
			'created_on'=>date('Y-m-d H:i:s'),
			'updated_on'=>date('Y-m-d H:i:s')
		);

		$result=$this->common->insert($table, $data);

		if($result){
			echo 'yes';
		}else{
			echo 'no';

		}
	}
	
	public function update(){
		
		$where['id']=$this->input->post('edit_id');
		$table='frequency_master';

		$data=array(
			'frequency'=>$this->input->post('frequency'),
			'times'=>$this->input->post('times'),
			'frequency_code'=>$this->input->post('frequency_code'),
			'name'=>$this->input->post('name'),
			'description'=>$this->input->post('description'),
			'is_active'=>1,
			'status'=>1,
			'created_on'=>date('Y-m-d H:i:s'),
			'updated_on'=>date('Y-m-d H:i:s')
		);
		
		$result=$this->common->update('frequency_master',$data,$where);
		
		if($result){
			echo "yes";
		}else{
			echo "no";  
		}
	}


	public function ajax_report(){
		
		$frequency=$this->freq->get_datatables();
		$data=array();
		$a=1;
		foreach ($frequency as $k) {
			$row=array();
			$row[] = $a++;
			$row[] = '<a class="mb-xs mt-xs mr-xs btn btn-outline-danger btn-amu" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$k['id']."'".')"><i class="fa fa-pencil"></i></a>';
			$row[] = $k['name'];
			$row[] = $k['frequency_code'];
			$row[] = $k['description'];
			
			if ($k['is_active']==1) {
				$row[] = '<span class="badge badge-boxed  badge-success"> Active </span>';
			}else{
				$row[] = '<span class="badge badge-boxed  badge-danger">Inactive </span>';
			}
			
			$data[]=$row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->freq->count_all(),
			"recordsFiltered" => $this->freq->count_filtered(),
			"data" => $data,
		);
	
		echo json_encode($output);

	}


	public function frequency_data(){
		$where['id']=$this->input->post('id');
		$result=$this->common->select_row('assets', $where);
		echo json_encode($result);
	}
	
	public function edit_frequency(){
		$id=base64_decode($this->uri->segment(4));
		$whr['id']=$id;
		
		$data['frequency']=$this->common->select_row('frequency_master', $whr);
		
		$this->load->view('includes/header');
		$this->load->view('includes/nav_bar');
		$this->load->view('includes/side_bar');
		$this->load->view('admin/edit_frequency', $data);
		
	}
	
	
	public function generate_master(){
			$date = $this->displayDates('2026-01-01', '2030-12-31', 'day');

			foreach ($date as $key => $v) {
				# code...
			//	print_r($v);
				$this->common->insert('date_master', $v);
			}
			//echo json_encode($date);
	}

	public function frequency_year_wise($start, $end, $times, $name){
		$begin=date('Y-m-d', strtotime($start));
		$end=date('Y-m-d', strtotime($end));
		$interval=$times;
		$begin_day_no=date("N", strtotime(date('l',strtotime($begin))));
		$begin_week_no=$this->getWeeks(date('Y-m-d',strtotime($begin)),date('l',strtotime($begin)));
		$where['mdate>=']=$begin;
		$where['mdate<=']=$end;
		$where['day_no']=$begin_day_no;
		$where['week_no']=$begin_week_no;
		$where['mm']=date('m', strtotime($begin));

		$this->db->select('*');
		$this->db->from('date_master');
		$this->db->where($where);
		$data=$this->db->get()->result();

		$i=0;
		foreach ($data as $key => $v) {
					
			if ($interval==1) {
				$json[]=$v;
			}else if($interval==2){
				
				if($i%2==0){
					
					$json[]=$v;
				}

			}else if($interval==3){
				if($i%3==0){
					
					$json[]=$v;
				}
			}else if($interval==4){
				if($i%4==0){
					
					$json[]=$v;
				}
			}else if($interval==5){
				if($i%5==0){
					
					$json[]=$v;
				}

			}else if($interval==6){
				if($i%6==0){
					
					$json[]=$v;
				}

			}else if($interval==7){
				if($i%7==0){
					
					$json[]=$v;
				}

			}else if($interval==8){
				if($i%8==0){
					
					$json[]=$v;
				}

			}else if($interval==9){
				if($i%9==0){
					
					$json[]=$v;
				}

			}else if($interval==10){
				if($i%10==0){
					
					$json[]=$v;
				}

			}
			
			$i++;
			
		}
	if(isset($json)){

		foreach ($json as $key => $v) {
			$cdata['ticket_date']=$v->mdate;
			$cdata['ticket_day']=$v->day;
			$cdata['week_no'] = $v->week_no;
			$cdata['frequency']=$name;
			$mjson[]=$cdata;
		}
				
		return $mjson;
	}

	}

	public function frequency_month_wise($start, $end, $times, $name){
		$begin=date('Y-m-d', strtotime($start));
		$end=date('Y-m-d', strtotime($end));
		$interval=$times;
		$begin_day_no=date("N", strtotime(date('l',strtotime($begin))));
		$begin_week_no=$this->getWeeks(date('Y-m-d',strtotime($begin)),date('l',strtotime($begin)));
		$where['mdate>=']=$begin;
		$where['mdate<=']=$end;
		$where['day_no']=$begin_day_no;
		$where['week_no']=$begin_week_no;
		//$where['dd']=date('d', strtotime($begin));

		$this->db->select('*');
		$this->db->from('date_master');
		$this->db->where($where);
		$data=$this->db->get()->result();

		$i=0;
		foreach ($data as $key => $v) {
					
			if ($interval==1) {
				$json[]=$v;
			}else if($interval==2){
				
				if($i%2==0){
					
					$json[]=$v;
				}

			}else if($interval==3){
				if($i%3==0){
					
					$json[]=$v;
				}
			}else if($interval==4){
				if($i%4==0){
					
					$json[]=$v;
				}
			}else if($interval==5){
				if($i%5==0){
					
					$json[]=$v;
				}

			}else if($interval==6){
				if($i%6==0){
					
					$json[]=$v;
				}

			}else if($interval==7){
				if($i%7==0){
					
					$json[]=$v;
				}

			}else if($interval==8){
				if($i%8==0){
					
					$json[]=$v;
				}

			}else if($interval==9){
				if($i%9==0){
					
					$json[]=$v;
				}

			}else if($interval==10){
				if($i%10==0){
					
					$json[]=$v;
				}

			}
			
			$i++;
			
		}
	if(isset($json)){
		foreach ($json as $key => $v) {
			$cdata['ticket_date']=$v->mdate;
			$cdata['ticket_day']=$v->day;
			$cdata['week_no'] = $v->week_no;
			$cdata['frequency']=$name;
			$mjson[]=$cdata;
		}
				
		return $mjson;

			
	}

	}

public function frequency_week_wise($start, $end, $times, $name){
		$begin=date('Y-m-d', strtotime($start));
		$end=date('Y-m-d', strtotime($end));
		$interval=$times;
		$begin_day_no=date("N", strtotime(date('l',strtotime($begin))));
		$begin_week_no=$this->getWeeks(date('Y-m-d',strtotime($begin)),date('l',strtotime($begin)));
		$where['mdate>=']=$begin;
		$where['mdate<=']=$end;
		$where['day_no']=$begin_day_no;
		//$where['week_no']=$begin_week_no;
		//$where['mm']=date('m', strtotime($begin));

		$this->db->select('*');
		$this->db->from('date_master');
		$this->db->where($where);
		$data=$this->db->get()->result();

		$i=0;
		foreach ($data as $key => $v) {
					
			if ($interval==1) {
				
					$json[]=$v;
				
				
			}else if($interval==2){
				
				if($i%2==0){
					
					$json[]=$v;
				}

			}else if($interval==3){
				if($i%3==0){
					
					$json[]=$v;
				}
			}else if($interval==4){
				if($i%4==0){
					
					$json[]=$v;
				}
			}else if($interval==5){
				if($i%5==0){
					
					$json[]=$v;
				}

			}else if($interval==6){
				if($i%6==0){
					
					$json[]=$v;
				}

			}else if($interval==7){
				if($i%7==0){
					
					$json[]=$v;
				}

			}else if($interval==8){
				if($i%8==0){
					
					$json[]=$v;
				}

			}else if($interval==9){
				if($i%9==0){
					
					$json[]=$v;
				}

			}else if($interval==10){
				if($i%10==0){
					
					$json[]=$v;
				}

			}
			
			$i++;
			
		}
	if(isset($json)){

		foreach ($json as $key => $v) {
			$cdata['ticket_date']=$v->mdate;
			$cdata['ticket_day']=$v->day;
			$cdata['week_no'] = $v->week_no;
			$cdata['frequency']=$name;
			$mjson[]=$cdata;
		}
				
		return $mjson;
	}

	}

	public function frequency_day_wise($start, $end, $times, $name){
		$begin=date('Y-m-d', strtotime($start));
		$end=date('Y-m-d', strtotime($end));
		$interval=$times;
		$begin_day_no=date("N", strtotime(date('l',strtotime($begin))));
		$begin_week_no=$this->getWeeks(date('Y-m-d',strtotime($begin)),date('l',strtotime($begin)));
		$where['mdate>=']=$begin;
		$where['mdate<=']=$end;
		$is_include_saturday=$this->input->post('is_include_saturday') ? 1 : 0;

		if($is_include_saturday>0){
			//$where['day_no<=']=6;//For include Saturday only
			$where['day_no<=']=7;//For include Sat & Sunday	
		}else{
			$where['day_no<=']=5;
		}
		
		//print_r($where);exit;

		if ($times>1) {
			if($times==2){
				if ($begin_day_no>=4) {
					$m=$begin_day_no-2;
				}else{
					$m=$begin_day_no+2;
				}
				//	$where['day_no']=$m;
				//	$where['day_no<=']=6;
				$where_in['day_no']=array($begin_day_no,$m);

				//print_r($where_in)
				
				$this->db->where($where);
				$this->db->where_in($where_in);
				
			}else if($times==3){
				if ($begin_day_no>=3) {
					$m=$begin_day_no-3;
				}else{
					$m=$begin_day_no+3;
				}
				$where_in['day_no']=array($begin_day_no,$m);
				
				$this->db->where($where);
				$this->db->where_in($where_in);
			}else {
				if($is_include_saturday>0){
					//$where['day_no<=']=6;  //Upto Sat
					$where['day_no<=']=7;  //Upto Sun
					
				}else{
					$where['day_no<=']=5;
				}
				$this->db->where($where);
			}
			// $where['day_no<=']=5;
		}else{
			if($is_include_saturday>0){
				//$where['day_no<=']=6;  //Upto Sat
				$where['day_no<=']=7;  //Upto Sun
			}else{
				$where['day_no<=']=5;
			}
			$this->db->where($where);
		}
	//	$where['week_no']=$begin_week_no;
		//$where['mm']=date('m', strtotime($begin));

		$this->db->select('*');
		$this->db->from('date_master');
		
		$data=$this->db->get()->result();
		
		$i=0;
		foreach ($data as $key => $v) {
					
			if ($interval==1) {
				
					$json[]=$v;
				
				
			}else if($interval==2){
				
				if($i%2==0){

					if ($begin_day_no>=4) {
					$m=$begin_day_no-2;
				}else{
					$m=$begin_day_no+2;
				}
				if($v->day_no==$begin_day_no || $v->day_no==$m){
					$json[]=$v;
				}
				}

			}else if($interval==3){
				if ($begin_day_no>3) {
						$m=$begin_day_no-3;
					}elseif($begin_day_no==3){
						$m=$begin_day_no+3;
					}else{
						$m=$begin_day_no+3;
					}

					if($v->day_no==$begin_day_no){
						$json[]=$v;
					}else if($v->day_no==$m){
						$json[]=$v;
						
					}
			}else if($interval==4){
				if($i%4==0){
					
					$json[]=$v;
				}
			}else if($interval==5){
				if($i%5==0){
					
					$json[]=$v;
				}

			}else if($interval==6){
				if($i%6==0){
					
					$json[]=$v;
				}

			}else if($interval==7){
				if($i%7==0){
					
					$json[]=$v;
				}

			}else if($interval==8){
				if($i%8==0){
					
					$json[]=$v;
				}

			}else if($interval==9){
				if($i%9==0){
					
					$json[]=$v;
				}

			}else if($interval==10){
				if($i%10==0){
					
					$json[]=$v;
				}

			}
			
			$i++;
			
		}
	if(isset($json)){

		foreach ($json as $key => $v) {
			$cdata['ticket_date']=$v->mdate;
			$cdata['ticket_day']=$v->day;
			$cdata['week_no'] = $v->week_no;
			$cdata['frequency']=$name;
			$mjson[]=$cdata;
		}

		//print_r($mjson);exit;
				
		return $mjson;
	}

	}

	function displayDates($date1, $date2, $type, $format = 'd-m-Y') {
      $dates = array();
      $current = strtotime($date1);
      $date2 = strtotime($date2);
      $stepVal = '+1 '.$type;
      while( $current <= $date2 ) {
      	$cdate= date($format, $current);
         $data['dd'] =date('d', strtotime($cdate));
         $data['mm'] =date('m',  strtotime($cdate));
         $data['yyyy'] =date('Y',  strtotime($cdate));
         $data['mdate'] =date('Y-m-d',  strtotime($cdate));
         $data['day'] =date('l',strtotime($cdate));
         $data['day_no'] =date("N", strtotime(date('l',strtotime($cdate))));
         $data['week_no']=$this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)));
         $data['is_active']=1;
         $data['status']=1;
         $data['created_on']=date('Y-m-d H:i:s');
         $data['updated_on']=date('Y-m-d H:i:s');
         $dates[]=$data;
     		
         $current = strtotime($stepVal, $current);
      }
      return $dates;
   }

   public function generate_bulk_frequency(){
   			$config['upload_path'] =  './uploads/bulk/assettickets/';
		//Only allow this type of extensions 
		$config['allowed_types'] = '*';
		$this->load->library('upload', $config);
		// if any error occurs 
		if ( ! $this->upload->do_upload('file'))
		{
		//	print_r("ssssss");exit;
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('msg1',$error);
			redirect('admin/tickets');
		}
		//if successfully uploaded the file 
		else
		{
		//	print_r("ssssss file upload");exit;
			$upload_data = $this->upload->data();
			$file_name = $upload_data['file_name'];
			$fileextension=explode('.',$file_name);
			$counts=count($fileextension)-1;
			//load library phpExcel
			$this->load->library("Excel");
			//here i used microsoft excel 2007

			if($fileextension[$counts]=='xlsx' || $fileextension[$counts]=='Xlsx')
			{
				$objReader = PHPExcel_IOFactory::createReader('Excel2007');
			}
			else
			{
				$objReader = PHPExcel_IOFactory::createReader('Excel5');
			}	

			//$objReader = PHPExcel_IOFactory::createReader('Excel2007');
			//set to read only
			$objReader->setReadDataOnly(true);
			//load excel file
			$objPHPExcel = $objReader->load('uploads/bulk/assettickets/'.$file_name);
			$sheetnumber = 0;
			foreach ($objPHPExcel->getWorksheetIterator() as $sheet)
			{

				$s = $sheet->getTitle();	// get the sheet name 
				$sheet= str_replace(' ', '', $s); // remove the spaces between sheet name 
				$sheet= strtolower($sheet); 
				$objWorksheet = $objPHPExcel->getSheetByName($s);
				$lastRow = $objPHPExcel->setActiveSheetIndex($sheetnumber)->getHighestRow(); 
				$sheetnumber++;
				for($j=2; $j<=$lastRow; $j++)
				{
					
					
					$asset_code = $objWorksheet->getCellByColumnAndRow(0,$j)->getValue(); 
					$start_date = $objWorksheet->getCellByColumnAndRow(1,$j)->getValue(); 
					$end_date = $objWorksheet->getCellByColumnAndRow(2,$j)->getValue();
					
				
					
					$where_asset['asset_item_code']=$asset_code;
					$asset=$this->common->select_row('assets',$where_asset);  
					$asset_id=$asset->id;
					
				//print_r($asset);exit;
				$this->generate_frequency($asset_id, $start_date, $end_date);
					// $ast_result=$this->common->insert('tickets',$data);
		
				}// loop ends 
				
			

				// $ast_result=$this->db->affected_rows()!=1 ? false:true;	
				// if($ast_result=true)
				// {
				// 	$this->session->set_flashdata('msg','Assets Added Successfully !');
					
				// 	exit;
				// }else{
				// 	$this->session->set_flashdata('msg1','Assets Added UnSuccessfully !');
				// 	echo "yes"; exit;
				// } 

			}

			echo "yes";
		}
   }

   public function generate_frequency($asset_id, $startdate, $todate){
		
		$start_date=$startdate;
		$end_date=$todate;
		$asset_id=$asset_id;
		$where['id']=$asset_id;
		$asset=$this->common->select_row('assets', $where);
		
		//print_r($asset_id);exit; 
		
		$data=explode(",", $asset->frequency_id);
		$result[]=array();
		$yearly_array=array();
		$monthly_array=array();
		$weekly_array=array();
		$wkly_arr=array();
		$daily_array=array();
		
		for($i=0;$i<sizeof($data);$i++){
			$whr['id']=$data[$i];
			$freq=$this->common->select_row('frequency_master', $whr);
			
			switch($freq->frequency){
				case 'YEAR':
					$yearly_array[]=$this->frequency_year_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'MONTH':
					$monthly_array[]=$this->frequency_month_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'WEEK':
					$weekly_array[]=$this->frequency_week_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'DAY':
					$daily_array[]=$this->frequency_day_wise($start_date, $end_date, $freq->times, $freq->name); 
					break;
			}
			 
		}



		$merged_daily=[];
		foreach ($daily_array as $key => $value) {
			if($merged_daily!=null){
				$merged_daily=array_merge($merged_daily,$value);
			}else{
				$merged_daily=array_merge($value);
			}
		}

		$merged_weekly=[];
		foreach ($weekly_array as $key => $value) {
			if($merged_weekly!=null){
				$merged_weekly=array_merge($merged_weekly,$value);
			}else{
				$merged_weekly=array_merge($value);
			}
		}

		$merged_monthly=[];
		foreach ($monthly_array as $key => $value) {
			if($merged_monthly!=null){
				$merged_monthly=array_merge($merged_monthly,$value);
			}else{
				$merged_monthly=array_merge($value);
			}
		}

		$merged_yearly=[];
		foreach ($yearly_array as $key => $value) {
			if($merged_yearly!=null){
				$merged_yearly=array_merge($merged_yearly,$value);
			}else{
				$merged_yearly=array_merge($value);
			}
		}


		$arr=array_merge($merged_daily, $merged_weekly, $merged_monthly, $merged_yearly);
		
		// echo json_encode($arr);
		//print_r($arr);exit;
		

		foreach ($arr as $k) {
				$added=false;
			 	$mdata['ticket_date']=$k['ticket_date'];
				$mdata['ticket_day']=$k['ticket_day'];
				$mdata['ticket_frequency']=$k['frequency'];
				if(isset($json)){
					//print_r('2');
					foreach ($json as $key=>$v) {
						if($v['ticket_date']==$k['ticket_date']){
							$json[$key]['ticket_frequency']=$json[$key]['ticket_frequency'].', '.$k['frequency'];
							$added=true;
							//print_r('3');
						}

					}
					if(!$added){
						//print_r('4');
						$json[]=$mdata;
					}
				}else{
					//print_r('1');
					$json[]=$mdata;
				}
		}



		//print_r($json);
		//$start_date=$this->input->post('startdate');
		//$end_date=$this->input->post('todate');
		//$asset_id=$this->input->post('asset_id');
		$this->generate_auto_tickets($asset_id, json_encode($json),$startdate,$todate);
		// pass to insert ticket


		 
	}

	public function generate_auto_tickets($asset_id, $tickets, $startdate, $todate){
		
		//print_r($_POST);
		$where['id']=$asset_id;
		$asset=$this->common->select_row('assets', $where);
		$tickets_list = json_decode(stripslashes($tickets));

	//	print_r($tickets_list);exit;
		$track_data=array(
			'asset_id'=>$asset_id,
			'start_date'=>$startdate,
			'end_date'=>$todate,
			'is_active'=>1,
			'status'=>1,
			'created_on'=>date('Y-m-d H:i:s'),
			'updated_on'=>date('Y-m-d H:i:s')
		);
		
		$result=$this->common->insertWithIDreturn('automation_track', $track_data);
		
		if($result['result']){
			$i=0;
			foreach($tickets_list as $k){
					$table='tickets';
					$num_series=$this->unique_ticket_code($asset->customer_id, $asset->project_id);
					
					$where_cust['id']=$asset->customer_id;
					$cust_data=$this->common->select_row('customers', $where_cust);
					$where_pro['id']=$asset->project_id;
					$project_data=$this->common->select_row('projects', $where_pro);
					$ticket_no=$cust_data->customer_prefix.$project_data->prefix.$num_series;
					$data=array(
						'ticket_no'=>$ticket_no,
						'ticket_date'=>date('Y-m-d',strtotime($k->ticket_date)),
						'customer_id'=>$asset->customer_id,
						'project_id'=>$asset->project_id,
						'num_series'=>$num_series,
						'auto_id'=>$result['last_id'],
						'name'=>$k->ticket_frequency,
						'asset_item_id'=>$asset->id,
						'technician_id'=>$asset->technician_id,
						'frequency_id'=>$asset->frequency_id,
						'ticket_type'=>'PMT',
						'description'=>'PMT Automated Ticket',
						'ticket_status'=>"Pending",
						'is_technician_approved'=>1,
						'is_active'=>1, 
						'status'=>1,
						'created_on'=>date('Y-m-d H:i:s'),
						'updated_on'=>date('Y-m-d H:i:s')
					); 		
					$whr['ticket_date']=date('Y-m-d',strtotime($k->ticket_date));
					$whr['customer_id']=$asset->customer_id;
					$whr['asset_item_id']=$asset->id;
					$whr['status']=1;
					$exist=$this->common->select_count('tickets', $whr);
					if ($exist>0) {
						# code...
					}else{
						$res=$this->common->insert('tickets',$data);
						$i++;
					}
						
			
			}

			//print_r($i.', ');//exit;
		
			// if($res){
			// 	echo "yes";
			// }else{
			// 	echo "no";
			// }
			
		}
		
		
	}


		public function unique_ticket_code($customer_id, $project_id)
	{
		$where['status']=1;
		$where['customer_id']=$customer_id;
		$where['project_id']=$project_id;
		
		$unique_id=$this->common->unique_ticket_id('tickets',$where);
		
		
		
		if(!empty($unique_id))
		{ 
			$product_code = $unique_id['num_series']; /* Last user id  from the table */
			$number=preg_replace("/[^0-9 ]/", '', $product_code);
			if(strpos($product_code,'999')&&strlen($number)==3){
				$product_code=str_replace('999', '1000', $product_code);
			}elseif(strpos($product_code,'9999')&&strlen($number)==4){
				$product_code=str_replace('9999', '10000', $product_code);
			}elseif(strpos($product_code,'99999')&&strlen($number)==5){
				$product_code=str_replace('99999', '100000', $product_code);
			}elseif(strpos($product_code,'999999')&&strlen($number)==6){
				$product_code=str_replace('999999', '1000000', $product_code);
			}else{
				$product_code++; /* Increment the last  user id here */
				
				
			}
		}else{
			$product_code = '000001';
		}
		return sprintf('%06d',$product_code);
	} 


	
	
	
	public function generate_ticket_frequency(){
		
		$start_date=$this->input->post('startdate');
		$end_date=$this->input->post('todate');
		$asset_id=$this->input->post('asset_id');
		$frequency= implode(',',$this->input->post('frequency_id'));
		//print_r($frequency);exit;
		$where['id']=$asset_id;
		$asset=$this->common->select_row('assets', $where);
		
		//print_r($asset_id);exit; 
		
		$data=explode(",", $frequency);
		$result[]=array();
		$yearly_array=array();
		$monthly_array=array();
		$weekly_array=array();
		$wkly_arr=array();
		$daily_array=array();
		
		for($i=0;$i<sizeof($data);$i++){
			$whr['id']=$data[$i];
			$freq=$this->common->select_row('frequency_master', $whr);
			
			switch($freq->frequency){
				case 'YEAR':
					$yearly_array[]=$this->frequency_year_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'MONTH':
					$monthly_array[]=$this->frequency_month_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'WEEK':
					$weekly_array[]=$this->frequency_week_wise($start_date, $end_date, $freq->times, $freq->name);
					break;
				case 'DAY':
					$daily_array[]=$this->frequency_day_wise($start_date, $end_date, $freq->times, $freq->name); 
					break;
			}
			 
		}



		$merged_daily=[];
		foreach ($daily_array as $key => $value) {
			if($merged_daily!=null){
				$merged_daily=array_merge($merged_daily,$value);
			}else{
				$merged_daily=array_merge($value);
			}
		}

		$merged_weekly=[];
		foreach ($weekly_array as $key => $value) {
			if($merged_weekly!=null){
				$merged_weekly=array_merge($merged_weekly,$value);
			}else{
				$merged_weekly=array_merge($value);
			}
		}

		$merged_monthly=[];
		foreach ($monthly_array as $key => $value) {
			if($merged_monthly!=null){
				$merged_monthly=array_merge($merged_monthly,$value);
			}else{
				$merged_monthly=array_merge($value);
			}
		}

		$merged_yearly=[];
		foreach ($yearly_array as $key => $value) {
			if($merged_yearly!=null){
				$merged_yearly=array_merge($merged_yearly,$value);
			}else{
				$merged_yearly=array_merge($value);
			}
		}


		$arr=array_merge($merged_daily, $merged_weekly, $merged_monthly, $merged_yearly);
		
		echo json_encode($arr);
		//print_r($arr);
		 
	}
	
	
	public function getYearlyDates($start, $end, $times, $name){
	//	print_r($times);exit;
		$begin = new DateTime($start);
		$end = new DateTime($end);
		$intv=$times;
		$interval = new DateInterval('P'.$intv.'Y');
		$period = new DatePeriod($begin, $interval, $end);
		$dates = [];

		$current_day = date('N', strtotime($start));
		$cday=$current_day;  
		
		foreach ($period as $date) {
		    $monday = $date->modify('+'.$times.' year');
		    if ($monday < $end) {
		        $dates[] = $monday;
		    }
		}
			
		$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($start)),date('l',strtotime($start)));
		if($data['week_no']>4){
			$mstart = new DateTime(date('Y-m-d',strtotime($start)));
			$mstart=$mstart->modify('next '.date('l',strtotime($start)));
			$cstart= date('Y-m-d', strtotime($mstart->format('Y-m-d')));
			$data['ticket_date']=date('Y-m-d',strtotime($cstart));
			$data['ticket_day']=date('l',strtotime($cstart));
		}else{
			$data['ticket_date']=date('Y-m-d',strtotime($start));
			$data['ticket_day']=date('l',strtotime($start));
		}
		$data['frequency']=$name;
		$json[]=$data;

		foreach ($dates as $date) {

				$dayofweek = date('N', strtotime($date->format('Y-m-d')));
				$current_day = date('N', strtotime($start));
			  
			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if ($dayofweek==0) {
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					$cdate= date('Y-m-d', strtotime('+'.$day_count_add.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}

				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}

				if ($cdate) {
						$data['ticket_date']=date('Y-m-d',strtotime($cdate));
						$data['ticket_day']=date('l',strtotime($cdate));
						$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)));//$date->format("W");
						$data['frequency']=$name;
						$json[]=$data;
				}else{
					$json[]=$data;
				}
				
				//$arr[]=$json;

			}

			return $json;
		
	}
	
	public function getDailyDates($start, $end, $times, $name){
	//	print_r($times);exit;
		$begin = new DateTime($start);
		$end = new DateTime($end);
		$intv=$times;
		$interval = new DateInterval('P'.$intv.'D');
		$period = new DatePeriod($begin, $interval, $end);
		$dates = [];
 
		$current_day = date('N', strtotime($start));
		$cday=$current_day;  
		
		foreach ($period as $date) {
		    $monday = $date->modify('+'.$times.' day');
		    if ($monday < $end) {
		        $dates[] = $monday;
		    }
		}
			
			
			// print_r($dates);exit;
		$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($start)),date('l',strtotime($start)));
		if($data['week_no']>4){
			$mstart = new DateTime(date('Y-m-d',strtotime($start)));
			$mstart=$mstart->modify('next '.date('l',strtotime($start)));
			$cstart= date('Y-m-d', strtotime($mstart->format('Y-m-d')));
			$data['ticket_date']=date('Y-m-d',strtotime($cstart));
			$data['ticket_day']=date('l',strtotime($cstart));
		}else{
			$data['ticket_date']=date('Y-m-d',strtotime($start));
			$data['ticket_day']=date('l',strtotime($start));
		}
		$data['frequency']=$name;
		$json[]=$data;

		foreach ($dates as $date) {

				$dayofweek = date('N', strtotime($date->format('Y-m-d')));
				$current_day = date('N', strtotime($start));
			  
			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if ($dayofweek==0) {
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					$cdate= date('Y-m-d', strtotime('+'.$day_count_add.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}

				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}

				if ($cdate) {
						$data['ticket_date']=date('Y-m-d',strtotime($cdate));
						$data['ticket_day']=date('l',strtotime($cdate));
						$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)));//$date->format("W");
						$data['frequency']=$name;
						$json[]=$data;
				}else{
					$json[]=$data;
				}
				
				//$arr[]=$json;

			}

			return $json;
		
	}
	
	
	
	public function getMonthlyDates($start, $end, $times, $name){
			$begin = new DateTime($start);
			$end = new DateTime($end);

			//if ($begin > $end) {
				
		
			$intv=$times;
			$interval = new DateInterval('P'.$intv.'M');
			$period = new DatePeriod($begin, $interval, $end);
			$dates = [];

			$current_day = date('N', strtotime($start));
			$cday=$current_day;


		//	print_r($interval);exit;
			// $times=2;
			foreach ($period as $date) {
			    $monday = $date->modify('+'.$times.' month');
			   // print_r($monday);exit;
			    if ($monday < $end) {
			    //	$dayofweek = date('w', strtotime($monday));
			        $dates[] = $monday;
			    }
			}
			
			
			$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($start)),date('l',strtotime($start)));
			if($data['week_no']>4){
				$mstart = new DateTime(date('Y-m-d',strtotime($start)));
				$mstart=$mstart->modify('next '.date('l',strtotime($start)));
				$cstart= date('Y-m-d', strtotime($mstart->format('Y-m-d')));
				$data['ticket_date']=date('Y-m-d',strtotime($cstart));
				$data['ticket_day']=date('l',strtotime($cstart));
			}else{
				$data['ticket_date']=date('Y-m-d',strtotime($start));
				$data['ticket_day']=date('l',strtotime($start));
			}
			$data['frequency']=$name;
			
			$json[]=$data;
		//	print_r($current_day);exit;
			foreach ($dates as $date) {

				$dayofweek = date('N', strtotime($date->format('Y-m-d')));
				 

			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}
				

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if ($dayofweek==0) {
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					$cdate= date('Y-m-d', strtotime('+'.$day_count_add.' day', strtotime($date->format('Y-m-d'))));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}

				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
					if($this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)))>4){
						$mdate = new DateTime(date('Y-m-d',strtotime($cdate)));
						$mdate=$mdate->modify('next '.date('l',strtotime($cdate)));
						$cdate= date('Y-m-d', strtotime($mdate->format('Y-m-d')));
					}
				}

				if ($cdate) {
						$data['ticket_date']=date('Y-m-d',strtotime($cdate));
						$data['ticket_day']=date('l',strtotime($cdate));
						$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)));
						$data['frequency']=$name;
						$json[]=$data;
				}else{
					
					$json[]=$data;
				}

			}
			return $json;
			//echo json_encode($json);
	}
	
	public function getWeeklyDates($start, $end, $times, $name){
		$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($start)),date('l',strtotime($start)));
	
			$data['ticket_date']=date('Y-m-d',strtotime($start));
			$data['ticket_day']=date('l',strtotime($start));
			$start=$start;
		
		$data['frequency']=$name;
		$json[]=$data;

			$begin = new DateTime($start);
			$end = new DateTime($end);

			//if ($begin > $end) {
				
			$intv=$times;
			$interval = new DateInterval('P'.$intv.'W');
			$period = new DatePeriod($begin, $interval, $end);
			$dates = [];

			foreach ($period as $date) {
			    $monday = $date->modify('+'.$times.' week');
			    if ($monday < $end) {
			        $dates[] = $monday;
			    }
			}
			
			//  print_r($dates);exit; 
			

		$prev_date=$start;
		foreach ($dates as $date) {
			
		
				$dayofweek = date('N', strtotime($date->format('Y-m-d')));
				$current_day = date('N', strtotime($start));
				$prev_date = $this->getWeeks(date('Y-m-d',strtotime($prev_date)), date('l',strtotime($prev_date)));//date('w', strtotime($prev_date));
				//if($prev_date-)
		//			print_r($prev_date);//exit;  
			  
			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.' day', strtotime($date->format('Y-m-d'))));
					
				}else if ($dayofweek==0) {
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
					
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					$cdate= date('Y-m-d', strtotime('+'.$day_count_add.' day', strtotime($date->format('Y-m-d'))));
					
				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
					
				}

				if ($cdate) {
						$data['ticket_date']=date('Y-m-d',strtotime($cdate));
						$prev_date=date('Y-m-d',strtotime($cdate));
						$data['ticket_day']=date('l',strtotime($cdate));
						$data['week_no'] = $this->getWeeks(date('Y-m-d',strtotime($cdate)),date('l',strtotime($cdate)));//$date->format("W");
						$data['frequency']=$name;
						$json[]=$data;
				}else{
					$json[]=$data;
				}
				
				//$arr[]=$json;

			}
			//exit;

			return $json;
	}

	function getWeeks($date, $rollover)
    {
        $cut = substr($date, 0, 8);
        $daylen = 86400;

        $timestamp = strtotime($date);
        $first = strtotime($cut . "00");
        $elapsed = ($timestamp - $first) / $daylen;

        $weeks = 1;

        for ($i = 1; $i <= $elapsed; $i++)
        {
            $dayfind = $cut . (strlen($i) < 2 ? '0' . $i : $i);
            $daytimestamp = strtotime($dayfind);

            $day = strtolower(date("l", $daytimestamp));

            if($day == strtolower($rollover))  $weeks ++;
        }

        return $weeks-1;
    }


	public function frequency_tickets(){

		$where['id']=$this->input->post('asset_id');

		$todate=$this->input->post('todate');
		$asset=$this->common->select('assets', $where);

		$frequency_id=$asset[0]['frequency_id'];

		for ($i=0; $i < 6 ; $i++) { 
			$data['ticket_date']="01-01-2021";
			$data['ticket_day']="Monday";
			$json[]=$data;
		}

//echo json_encode($json);exit;
		//print_r($asset);exit;
		

		$today=date('Y-m-d H:i:s');
		$todate=date('Y-m-d', strtotime($this->input->post('todate')));
		//print_r($todate);exit;
	//$where['is_active']=1;
	//$where['status']=1;
		//$assets=$this->common->select('asset', $where);

		foreach ($asset as $k) {
			$freq_id=$k['frequency_id'];
			if ($freq_id!=0&&$freq_id!=null) {

				$frequency=$this->common->getItemByID('frequency_master', $freq_id);
				
				if($frequency->maintenance_type == 'PM'){

					if ($frequency->frequency_category == 'ADD') {
						
						switch ($frequency->frequency) {
							case 'YEAR':
								//$this->pm_year_ticket($k, $frequency->times, $fromdate, $todate);
								break;
							case 'MONTH':
								$this->pm_month_ticket($k, $frequency->times, $todate);
								break;
							case 'WEEK':
							//	$this->pm_week_ticket($v, $frequency->times);
								break;
							case 'DAY':
							//	$this->pm_day_ticket($v, $frequency->times);
								break;
							
							default:
								# code...
								break;
						}


					}else if($frequency->frequency_category == 'BCM'){
						switch ($frequency->frequency) {
							case 'YEARLY':
							//	$this->cm_yearly_ticket($v, $frequency->times);
								break;
							case 'MONTHLY':
								$this->cm_monthly_ticket($v, $frequency->times, $todate);
								break;
							case 'WEEKLY':
							//	$this->cm_weekly_ticket($v, $frequency->times);
								break;
							case 'DAILY':
							//	$this->cm_daily_ticket($v, $frequency->times);
								break;
							
							default:
								# code...
								break;
						}
					}else{

					}


				}else if($frequency->maintenance_type == 'CM'){



				}
		
			}
		}

	}


	public function cm_monthly_ticket(){

	}


	    public function pm_year_ticket($asset, $times, $todate){
    		$where['asset_item_id']=$asset['id'];
    		$last_pmt=$this->common->last_service_date('tickets',$where);
    		//print_r($last_pmt['ticket_date']);exit;
			if($last_pmt){
				$last_pmt_date=$last_pmt['ticket_date'];
			}else{
				$last_pmt_date=$asset['service_start_date'];
			}
    		$begin = new DateTime($last_pmt_date);
			$end = new DateTime($todate);

			//if ($begin > $end) {
				
		
			$intv=$times;
			$interval = new DateInterval('P'.$intv.'Y');
			$period = new DatePeriod($begin, $interval, $end);
			$dates = [];

		//	print_r($interval);exit;
			// $times=2;
			foreach ($period as $date) {
			    $monday = $date->modify('+'.$times.' year');
			   // print_r($monday);exit;
			    if ($monday < $end) {
			    //	$dayofweek = date('w', strtotime($monday));
			        $dates[] = $monday;
			    }
			}
			foreach ($dates as $date) {

				$dayofweek = date('w', strtotime($date->format('Y-m-d')));
				$current_day = date('w', strtotime($last_pmt_date));
			  	//print_r($current_day);exit;

			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.'day', strtotime($date->format('Y-m-d'))));
				}else if ($dayofweek==0&&$current_day==1) {
					$cdate= date('Y-m-d', strtotime('+1 day', strtotime($date->format('Y-m-d'))));
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_add.'day', strtotime($date->format('Y-m-d'))));
				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
				}

				if ($cdate) {

					foreach ($cdate as $cd => $value) {
						# code...
						$data['ticket_date']=date('Y-m-d',strtotime($cd));
						$data['ticket_day']=date('D',strtotime($cd));
						$json[]=$data;
					}
						// echo date('D: Y-m-d',strtotime($cdate)).'</br>';
					echo json_encode($json);


				}else{
					echo "no date in the limit";
				}

				// if ($result) {
				// 	//echo "success";
				// }
			}

		// }else{

		// }

    }


   public function pm_month_ticket($asset, $times, $todate){
    		$where['asset_item_id']=$asset['id'];
    		$last_pmt=$this->common->last_service_date('tickets',$where);

			
    		//print_r($last_pmt['ticket_date']);exit;
			if($last_pmt){
				$last_pmt_date=$last_pmt['ticket_date'];
			}else{
				$last_pmt_date=$asset['service_start_date'];
			}
    		$begin = new DateTime($last_pmt_date);
			$end = new DateTime($todate);

			//if ($begin > $end) {
				
		
			$intv=$times;
			$interval = new DateInterval('P'.$intv.'M');
			$period = new DatePeriod($begin, $interval, $end);
			$dates = [];

			$current_day = date('w', strtotime($last_pmt_date));
			$cday=$current_day;


		//	print_r($interval);exit;
			// $times=2;
			foreach ($period as $date) {
			    $monday = $date->modify('+'.$times.' month');
			   // print_r($monday);exit;
			    if ($monday < $end) {
			    //	$dayofweek = date('w', strtotime($monday));
			        $dates[] = $monday;
			    }
			}
			
		//	print_r($current_day);exit;
			foreach ($dates as $date) {

				$dayofweek = date('w', strtotime($date->format('Y-m-d')));
				
			  	//print_r($dayofweek.'--'.$cday).'</br>';


			  	if ($current_day==0) {
			  	 	$current_day++;
			  	}

				if ($dayofweek>$current_day) {
					$day_count_sub=$dayofweek-$current_day;
					$cdate= date('Y-m-d', strtotime('-'.$day_count_sub.' day', strtotime($date->format('Y-m-d'))));
				}else if ($dayofweek==0) {
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
				}else if($dayofweek==0&&$current_day>1){
					$cdate= date('Y-m-d', strtotime('+'.$current_day.' day', strtotime($date->format('Y-m-d'))));
				}else if($dayofweek<$current_day){
					$day_count_add=$current_day-$dayofweek;
					//print_r($day_count_add);exit;
					//print_r($date->format('D: Y-m-d'));exit;
					$cdate= date('Y-m-d', strtotime('+'.$day_count_add.' day', strtotime($date->format('Y-m-d'))));

				}else{
					$cdate=date('Y-m-d',  strtotime($date->format('Y-m-d')));
				}

				if ($cdate) {
					//print_r($cdate);
					//echo date('D: Y-m-d',strtotime($cdate)).'</br>';

					//foreach ($cdate as $cd => $value) {
						# code...
						$data['ticket_date']=date('Y-m-d',strtotime($cdate));
						$data['ticket_day']=date('l',strtotime($cdate));
						$json[]=$data;
				//	}
						// echo date('D: Y-m-d',strtotime($cdate)).'</br>';
					


					

				}else{
					//$data['ticket_date']=date('Y-m-d',strtotime($cd));
					//$data['ticket_day']=date('D',strtotime($cd));
					$json[]=$data;
				}
				 
			}
			
			echo json_encode($json);
			
    }

}
?>