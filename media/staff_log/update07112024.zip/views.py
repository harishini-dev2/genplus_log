import json
from django.conf import settings
from django.shortcuts import render
from facility_app.models import *
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
from django.http import JsonResponse
from django.db.models import Q
from django.db.models import Max
from django.db.models import F
import hashlib
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from rest_framework.parsers import JSONParser
from django.core.exceptions import ObjectDoesNotExist
from datetime import datetime
from django.utils.dateparse import parse_date
import pdfkit
import base64
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from django.http import FileResponse
from reportlab.pdfgen import canvas
import io
from django.urls import reverse
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from datetime import date
from num2words import num2words
from decimal import Decimal
from django.views.decorators.csrf import csrf_exempt
from django.db import transaction
from django.db.models import Sum
from facility_app.forms import *
from .forms import *
from facility_app.serializers import *
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import login_table, employee_table
import hashlib

from django.http import JsonResponse
from django.shortcuts import redirect
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from django.shortcuts import redirect
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.conf import settings
from google.auth.transport.requests import AuthorizedSession
from google.auth.transport.requests import AuthorizedSession
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from django.shortcuts import redirect
from django.http import JsonResponse
from django.utils import timezone
from django.middleware.csrf import get_token
from django.conf import settings
import hashlib
from django.shortcuts import render, redirect
from django.http import JsonResponse
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google.auth.transport.requests import AuthorizedSession
from .models import login_table, employee_table

import hashlib
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from google.auth.transport.requests import AuthorizedSession
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.middleware.csrf import get_token
from .models import employee_table  # Ensure employee_table is imported
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.utils import timezone
from django.db import IntegrityError
from .forms import assetForm
from .models import asset_table, vendor_table, project_table
from django.utils.dateformat import format
import openpyxl
import pandas as pd

from django.shortcuts import render, redirect
from django.http import JsonResponse
import qrcode
from io import BytesIO
import base64
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import qrcode
import base64
from io import BytesIO
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.shortcuts import render
import qrcode
import base64
from io import BytesIO
from PyPDF2 import PdfMerger
import os
from django.utils import timezone
from django.conf import settings
from django.shortcuts import render



def is_ajax(request):
    return request.headers.get('x-requested-with') == 'XMLHttpRequest'



def getItemNameById(tbl,cat_id):
    category = (tbl.objects.get(id=cat_id)).name
    return category


#````````````````````````````````********````````````````````````````````````````````

def index(request):
    return render(request,'login.html')


def signin(request):
    return render(request,'login.html')


import hashlib
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import employee_table 

def login(request):
    if request.method == "POST":
        uname = request.POST.get('email')
        pwd = request.POST.get('password')

        hashed_pwd = hashlib.md5(pwd.encode()).hexdigest()

        if employee_table.objects.filter(email=uname, password=hashed_pwd).exists():
            employee = employee_table.objects.get(email=uname, password=hashed_pwd)
            print('employee',employee)
            
            # Set session data common for both admin and vendor users
            request.session['user_id'] = employee.id
            request.session['user_username'] = employee.username
            request.session['user_name'] = employee.name
            request.session['user_mail'] = employee.email

            if employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 1:
                request.session['user_type'] = 'superadmin'
                print(request.session['user_type'])
                return HttpResponseRedirect("/admin")

            elif employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 0:
                request.session['user_type'] = 'admin'
                print(request.session['user_type'])
                return HttpResponseRedirect("/admin")

            # Check if the user is a vendor (company_id=0 and vendor_id has some value)
            elif employee.company_id == 0 and employee.vendor_id != 0:
                request.session['user_type'] = 'vendor'
                print(request.session['user_type'] )
                request.session['vendor_id'] = employee.vendor_id
                return HttpResponseRedirect("/vendor/dashboard")

        else:
            # If the user doesn't exist or the credentials are incorrect
            return HttpResponseRedirect("/signin")

    # Render the login page if the request method is GET
    return render(request, 'login.html')



# OAuth2 flow setup
SCOPES = [
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/userinfo.email',
    'openid'
]


flow = Flow.from_client_config(
    client_config={
        "web": {
            "client_id": settings.GOOGLE_CLIENT_ID,
            "client_secret": settings.GOOGLE_CLIENT_SECRET,
            "redirect_uris": [settings.GOOGLE_REDIRECT_URI],
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token"
        }
    },
    scopes=SCOPES,
    redirect_uri=settings.GOOGLE_REDIRECT_URI
)





def auth_login(request):
    csrf_token = get_token(request)
    print('CSRF Token:', csrf_token)

    print('GET Parameters:', request.GET)

    if 'code' in request.GET:
        code = request.GET.get('code')
        print('Authorization Code Received:', code)

        try:
            flow.fetch_token(code=code)
            credentials = flow.credentials
            print('Credentials:', credentials)

            request.session['token'] = credentials.token
            request.session['refresh_token'] = credentials.refresh_token
            request.session['token_expiry'] = credentials.expiry.isoformat()

            userinfo_endpoint = 'https://www.googleapis.com/oauth2/v3/userinfo'
            authed_session = AuthorizedSession(credentials)
            response = authed_session.get(userinfo_endpoint)
            user_profile = response.json()
            print('User Profile:', user_profile)

            email = user_profile.get('email')
            name = user_profile.get('name')
            address = user_profile.get('address', 'Address not provided')  # Safely fetch address
            print('Email:', email)
            print('Name:', name)
            print('Address:', address)

            if not email:
                print('Email not found in user profile.')
                return JsonResponse({'error': 'Email not found in user profile.'})

            # Fetch employee based on email
            employee = None

            try:
                employee = employee_table.objects.get(email=email, is_active=True, status=1)
                print(f'User found in employee_table: {employee.name}')
            except employee_table.DoesNotExist:
                print('User not found in employee_table.')

            if employee:
                # Superadmin login logic
                if employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 1:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'superadmin'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    return redirect('/admin')

                # Admin login logic
                elif employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 0:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'admin'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    request.session['company_id'] = employee.vendor_id
                    return redirect('/admin')

                # Vendor login logic
                elif employee.company_id == 0 and employee.vendor_id != 0:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'vendor'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    request.session['company_id'] = employee.vendor_id
                    return redirect('/vendor/dashboard')

            else:
                print('User does not exist in employee_table.')
                return render(request, 'login.html', {
                    'error_message': 'User does not exist in employee_table.'
                })

        except Exception as e:
            print('Exception during token exchange:', str(e))
            return JsonResponse({'error': str(e)})

    elif 'token' in request.session:
        try:
            credentials = Credentials(
                token=request.session['token'],
                refresh_token=request.session.get('refresh_token'),
                token_uri="https://oauth2.googleapis.com/token",
                client_id=settings.GOOGLE_CLIENT_ID,
                client_secret=settings.GOOGLE_CLIENT_SECRET
            )

            if credentials.expired and credentials.refresh_token:
                old_token = request.session['token']
                credentials.refresh(Request())
                new_token = credentials.token
                print(f"Old Token: {old_token}")
                print(f"New Token: {new_token}")

                request.session['token'] = new_token
                request.session['token_expiry'] = credentials.expiry.isoformat()
            else:
                print("Token is still valid and not expired.")

            userinfo_endpoint = 'https://www.googleapis.com/oauth2/v3/userinfo'
            authed_session = AuthorizedSession(credentials)
            response = authed_session.get(userinfo_endpoint)
            user_profile = response.json()
            print('User Profile:', user_profile)

            email = user_profile.get('email')
            name = user_profile.get('name')
            address = user_profile.get('address', 'Address not provided')  # Safely fetch address
            print('Email:', email)
            print('Name:', name)
            print('Address:', address)

            if not email:
                print('Email not found in user profile.')
                return JsonResponse({'error': 'Email not found in user profile.'})

            # Check if email exists in employee_table
            employee = None

            try:
                employee = employee_table.objects.get(email=email, is_active=True, status=1)
                print(f'User found in employee_table: {employee.name}')
            except employee_table.DoesNotExist:
                print('User not found in employee_table.')

            if employee:
                if employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 1:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'superadmin'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    return redirect('/admin')

                elif employee.company_id == 1 and employee.vendor_id == 0 and employee.is_superadmin == 0:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'admin'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    request.session['company_id'] = employee.vendor_id
                    return redirect('/admin')

                elif employee.company_id == 0 and employee.vendor_id != 0:
                    request.session['user_id'] = employee.id
                    request.session['user_name'] = employee.name
                    request.session['user_username'] = employee.username
                    request.session['user_mail'] = employee.email
                    request.session['user_type'] = 'vendor'
                    request.session['user_is_google_login'] = True
                    request.session['logged_in'] = True
                    request.session['company_id'] = employee.vendor_id
                    return redirect('/vendor/dashboard')

            else:
                print('User does not exist in employee_table.')
                return render(request, 'login.html', {
                    'error_message': 'User does not exist in employee_table.'
                })

        except Exception as e:
            print('Exception during token handling:', str(e))
            return JsonResponse({'error': str(e)})

    else:
        auth_url, _ = flow.authorization_url(prompt='consent', access_type='offline', include_granted_scopes='true')
        print('Authorization URL:', auth_url)
        return redirect(auth_url)


def logout(request):
    if 'user_id' in request.session:
        request.session.flush() 
    return HttpResponseRedirect("/signin")


# ```````````````````````````````````````````DASHBOARD```````````````````````````````````````````````````````````
def dashboard(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        print(f"User ID: {request.session.get('user_id')}")  # Print user ID for debugging

        if user_type == 'superadmin' or user_type == 'admin':
            vendor = vendor_table.objects.filter(status=1).count()
            vendors = vendor_table.objects.filter(status=1)
            project2 = project_table.objects.filter(status=1).count()
            completed = ticket_table.objects.filter(ticket_status='Completed', status=1).count()
            pending = ticket_table.objects.filter(ticket_status='Pending', status=1).count()
            customer = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            print()

            status_counts = {
                'pending': ticket_table.objects.filter(ticket_status='Pending', status=1).count(),
                'completed': ticket_table.objects.filter(ticket_status='Completed', status=1).count(),
                'hold': ticket_table.objects.filter(ticket_status='hold', status=1).count(),
                'partial': ticket_table.objects.filter(ticket_status='Partial', status=1).count(),
                'cancelled': ticket_table.objects.filter(ticket_status='Cancelled', status=1).count(),
                'open': ticket_table.objects.filter(ticket_status='Open', status=1).count(),
            }

            # Print the status counts for debugging
            print(f"Status counts: {status_counts}")

            return render(request, 'dashboard.html', {
                'vendor': vendor,
                'vendors': vendors,
                'project2': project2,
                'completed': completed,
                'pending': pending,
                'customer': customer,
                'project': project,
                'category': category,
                'frequency': frequency,
                'status_counts': status_counts,
            })
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")





def get_projects(request):
    vendor_id = request.GET.get('vendor_id')
    projects = project_table.objects.filter(vendor_id=vendor_id).values('id', 'name')
    return JsonResponse({'projects': list(projects)})

def get_assets(request):
    project_id = request.GET.get('project_id')
    assets = asset_table.objects.filter(project_id=project_id).values('id', 'name')
    return JsonResponse({'assets': list(assets)})




def asset_dashboard(request):
    vendor_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    category_id = request.POST.get('category')

    assets = asset_table.objects.filter(status=1).order_by('-id')
    if project_id == 'Select':
        return JsonResponse({'data': []})
    if vendor_id and vendor_id.isdigit():
        assets = assets.filter(vendor_id=vendor_id)
    if project_id and project_id.isdigit():
        assets = assets.filter(project_id=project_id)
    if category_id and category_id.isdigit():
        assets = assets.filter(id=category_id)
    

    data = []
    for index, item in enumerate(assets, start=1):  # Start the counter from 1
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []
        frequency_names = [frequency_table.objects.get(id=int(freq_id)).name for freq_id in frequency_ids if freq_id.isdigit()]
        frequency_str = ', '.join(frequency_names)
        
        category_name = category_table.objects.get(id=item.category_id).name if item.category_id else '-'
        brand_name = brand_table.objects.get(id=item.brand_id).name if item.brand_id else '-'
        project_name = project_table.objects.get(id=item.project_id).name if item.project_id else '-'
        system_name = system_table.objects.get(id=item.asset_group_id).name if item.asset_group_id else '-'
        technician_name = employee_table.objects.get(id=item.technician_id).name if item.asset_group_id else '-'
        item_name = system_table.objects.get(id=item.item_id).name if item.item_id else '-'

        system_id = item.id
        completed_ticket_count = ticket_table.objects.filter(asset_item_id=system_id, ticket_status="Completed", status=1).count()
        total_ticket_count = ticket_table.objects.filter(asset_item_id=system_id, status=1).count()

        # Format dates in "day-month-year" format
        warranty_start_date = item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-'
        warranty_end_date = item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-'
        
        formatted_item = {
            'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
                      '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_schedule(\'{}\')" class="btn  btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
                      '</div>',
            'item': item_name,
            'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Tickets ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
            'qr': item.asset_item_code if item.asset_item_code else '-',
            'code': system_name if system_name else '-',
            'project': project_name,
            'technician': technician_name if technician_name else '-',
            'name': item.name if item.name else '-',
            
            'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
        }

        data.append(formatted_item)

    return JsonResponse({'data': data})





def ticket_dashboard(request):
    status_id = request.POST.get('ticket')   
    print('vendor_id',status_id)
    from_date = request.POST.get('from_date')
    to_date = request.POST.get('to_date')
    print(from_date,to_date)

   
    assets = ticket_table.objects.filter(status=1)

    if status_id:
        assets = assets.filter(ticket_status=status_id)
    
    if from_date and to_date:
        assets = assets.filter(ticket_date__range=[from_date, to_date])
    data = []
    for item in assets:
        asset_name = asset_table.objects.get(id=item.asset_item_id)
        ticket_date = item.ticket_date.strftime('%d-%m-%Y') if item.ticket_date else '-'
        
        formatted_item = {           
            'code': item.ticket_no if item.ticket_no else '-',  
            'customer': getItemNameById(vendor_table, item.vendor_id),
            'project':  getItemNameById(project_table, item.project_id) if item.project_id else '-',            
            'asset': asset_name.asset_item_code, 
            'technician': getItemNameById(employee_table, item.technician_id) if item.technician_id else '-',
            'status': '<span class="badge text-bg-{}">{}</span>'.format(get_status_color(item.ticket_status), item.ticket_status),
        }

        data.append(formatted_item)

    return JsonResponse({'data': data})






#````````````````````````````````````````````````COMPANY```````````````````````````````````````````````````````````````````

def company(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            cmpy = company_table.objects.filter(id=1).first()
            return render(request, 'masters/company.html', {'company': cmpy})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def profile(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            cmpy = company_table.objects.filter(id=1).first()
            return render(request, 'masters/profile.html', {'company': cmpy})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



def update_company(request):
    if request.method == "POST":
        company_id = request.POST.get('id')
        user_id = request.session.get('user_id')
        
        company_instance = company_table.objects.get(id=company_id)
        form = companyform(request.POST, request.FILES, instance=company_instance)
        
        if form.is_valid():
            company_instance.updated_by = user_id
            company_instance.updated_on = timezone.now()
            form.save()
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})

#``````````````````````````````````````````````USER MODULES```````````````````````````````````````````````````````````````

def user_roles(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'masters/user_roles.html')

        elif user_type == 'vendor':
            return render(request,'customer_template/user_roles.html')
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")




def get_roles(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        
        if user_type == 'superadmin' or user_type == 'admin':
            roles = AdminRoles.objects.filter(status=1)

        elif user_type == 'vendor':
            # Exclude roles with the name 'Admin' for vendor users
            roles = AdminRoles.objects.filter(status=1).exclude(name='Admin')
        else:
            return JsonResponse({'error': 'Invalid user type'}, status=400)
        
        # Prepare roles data
        roles_data = [{'id': role.id, 'name': role.name} for role in roles]
        
        return JsonResponse(roles_data, safe=False)

    else:
        return HttpResponseRedirect("/signin")




    


def view_roles(request):
    role_id = request.POST.get('role_id')

    user_type = request.session.get('user_type')
    vendor_id = request.session.get('vendor_id', None)  # Assuming vendor_id is stored in the session

    # Fetch all active modules
    all_modules = AdminModules.objects.filter(status=1).values('id', 'name').distinct().order_by('sort_order_no')

    if user_type == 'vendor' and vendor_id:
        # If user is a vendor, only list modules where vendor=1 and vendor_id is not 0
        all_modules = all_modules.filter(is_vendor=1)

    formatted = []

    if role_id:
        privileges = AdminPrivilege.objects.filter(role_id=role_id).values('module_id', 'is_create', 'is_read', 'is_update', 'is_delete')

        privilege_dict = {priv['module_id']: priv for priv in privileges}

        for item in all_modules:
            module_id = item['id']
            module_name = item['name']
            privilege_info = privilege_dict.get(module_id, None)

            if privilege_info:
                formatted.append({
                    'module_id': module_id,
                    'module': module_name,
                    'is_create': privilege_info['is_create'],
                    'is_read': privilege_info['is_read'],
                    'is_update': privilege_info['is_update'],
                    'is_delete': privilege_info['is_delete']
                })
            else:
                # If no privileges are defined for this module, set all privileges to 0
                formatted.append({
                    'module_id': module_id,
                    'module': module_name,
                    'is_create': 0,
                    'is_read': 0,
                    'is_update': 0,
                    'is_delete': 0
                })
    else:
        # If no role_id is provided, set all privileges to default (0) for all modules
        formatted = [
            {
                'module_id': item['id'],
                'module': item['name'],
                'is_create': 0,
                'is_read': 0,
                'is_update': 0,
                'is_delete': 0
            }
            for item in all_modules
        ]


    return JsonResponse({'data': formatted})








def add_roles(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        cid = frm.get('id')
        nm = frm.get('role')
        desc = frm.get('description')
        role = AdminRoles()
        role.name=nm
        role.descriptions=desc
        role.created_on=timezone.now()
        role.created_by=user_id
        role.updated_on=timezone.now()
        role.updated_by=user_id
        role.save()
        res = "Success"
        return JsonResponse({"data": res})



def privileges_update(request):
    if request.method == 'POST':
        role_id = request.POST.get('role_id')
        privileges_json = request.POST.get('privileges')
        user_id = request.session['user_id']
        employee = get_object_or_404(employee_table, id=user_id)
        vendor_id = employee.vendor_id

        privileges = json.loads(privileges_json)

        try:
            role = AdminRoles.objects.get(id=role_id)
        except AdminRoles.DoesNotExist:
            return JsonResponse({'error': 'Role with ID {} does not exist'.format(role_id)}, status=404)

        # Clear existing privileges for the role
        AdminPrivilege.objects.filter(role_id=role.id).delete()

        for privilege_data in privileges:
            module_id = privilege_data.get('module_id')  # Get module_id
            is_create = privilege_data.get('create', 0)
            is_read = privilege_data.get('read', 0)
            is_update = privilege_data.get('update', 0)
            is_delete = privilege_data.get('delete', 0)

            privilege = AdminPrivilege.objects.create(
                role_id=role.id,
                module_id=module_id,
                is_create=is_create,
                is_read=is_read,
                is_update=is_update,
                is_delete=is_delete,
                created_on=timezone.now(),
                updated_on=timezone.now(),
                created_by=user_id,
                updated_by=user_id,
                vendor_id=vendor_id
            )

            privilege.save()

        response_data = {
            'message': 'Privileges updated successfully for role ID: {}'.format(role_id)
        }
        return JsonResponse(response_data)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=400)


def edit_roles(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = AdminRoles.objects.filter(id=request.POST.get('id'))
    return JsonResponse(data.values()[0])



def update_roles(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        cid = frm.get('id')
        nm = frm.get('role')
        desc = frm.get('description')
        role = AdminRoles.objects.get(id=cid)
        role.name=nm
        role.descriptions=desc
        role.updated_on=timezone.now()
        role.updated_by=user_id
        role.save()
        res = "Success"
        return JsonResponse({"data": res})


def duplicate_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = AdminRoles.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def role_duplicate(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        form_data = request.POST
        original_role_id = form_data.get('duplicate_id')
        new_role_name = form_data.get('role')
        new_role_desc = form_data.get('description')
        
        try:
            with transaction.atomic():
                original_role = AdminRoles.objects.get(id=original_role_id)
                
                new_role = AdminRoles.objects.create(
                    name=new_role_name,
                    descriptions=new_role_desc,
                    created_on=original_role.created_on,
                    created_by=original_role.created_by,
                    updated_on=timezone.now(),
                    updated_by=user_id
                )
                
                original_privileges = AdminPrivilege.objects.filter(role_id=original_role.id)
                for privilege in original_privileges:
                    new_privilege = AdminPrivilege.objects.create(
                        role_id=new_role.id,  # Use new_role.id instead of new_role
                        module=privilege.module,
                        is_create=privilege.is_create,
                        is_read=privilege.is_read,
                        is_update=privilege.is_update,
                        is_delete=privilege.is_delete,
                        created_on=timezone.now(),
                        updated_on=timezone.now(),
                        created_by=user_id,
                        updated_by=user_id
                    )
                
                return JsonResponse({"data": "Success"})
        
        except Exception as e:
            return JsonResponse({"error": str(e)})
    else:
        return JsonResponse({"error": "Invalid request method or not AJAX request"})





def delete_roles(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            AdminRoles.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except AdminRoles.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


from django.http import JsonResponse
from django.utils import timezone

def refresh_privileges(request):
    if request.method == 'POST':
        role_id = request.POST.get('role_id')

        # Get all active modules
        modules = AdminModules.objects.filter(status=1).values('id')

        # Fetch existing privileges for the given role
        existing_privileges = AdminPrivilege.objects.filter(role_id=role_id).values_list('module_id', flat=True)
        existing_privileges_set = set(existing_privileges)  # Use a set for efficient look-up

        # Prepare to insert missing privileges
        new_privileges = []
        for module in modules:
            module_id = module['id']
            if module_id not in existing_privileges_set:
                new_privileges.append(AdminPrivilege(
                    role_id=role_id,
                    module_id=module_id,
                    vendor_id=0,  # Set default vendor_id, modify if needed
                    is_create=0,
                    is_read=0,
                    is_update=0,
                    is_delete=0,
                    is_active=1,
                    status=1,
                    created_on=timezone.now(),
                    updated_on=timezone.now(),
                    created_by=request.session['user_id'],  # Ensure user_id is in the session
                    updated_by=request.session['user_id']
                ))

        # Bulk create missing privileges if any
        if new_privileges:
            AdminPrivilege.objects.bulk_create(new_privileges)

        return JsonResponse({'message': 'Privileges refreshed successfully.'})
    
    return JsonResponse({'error': 'Invalid request method'}, status=400)



#````````````````````````````````````````````CATEGORY``````````````````````````````````````````````````

def category(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'masters/category.html')
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def category_add(request):
    if request.method == 'POST':
        user_id = request.session['user_id']
        form = categoryForm(request.POST, request.FILES)
        if form.is_valid():
            category = form.save(commit=False)
            photo = request.FILES.get('image')
            desc = request.POST.get('description')
            category.image = photo
            category.description = desc
            category.created_by = user_id
            category.updated_by = user_id
            category.created_on = timezone.now()
            category.updated_on = timezone.now()
            category.save()
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    else:
        form = categoryForm()
    return render(request, 'masters/category.html', {'form': form})



def category_view(request):
    data = list(category_table.objects.filter(status=1).order_by('-id').values())
    formatted = [
        {
            'id': index + 1,  # Auto-generated ID starting from 1
            'action': '<button type="button" onclick="category_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                      <button type="button" onclick="category_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
            'category': item['name'] if item['name'] else '-', 
            'description': item['description'] if item['description'] else '-', 
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        } 
        for index, item in enumerate(data)
    ]
    return JsonResponse({'data': formatted})




def category_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = category_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def category_update(request):
    if request.method == "POST":
        category_id = request.POST.get('id')
        category = category_table.objects.get(id=category_id)
        form = categoryForm(request.POST, request.FILES, instance=category)
        if form.is_valid():
            photo = request.FILES.get('image')
            desc = request.POST.get('description')
            user_id = request.session.get('user_id')
            category.description = desc
            category.image = photo
            category.updated_by = user_id
            category.updated_on = timezone.now()
            form.save()            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})


def category_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            category_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except category_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})



#`````````````````````````````````````BRAND``````````````````````````````````````````````````````````

def brand(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            category = category_table.objects.filter(status=1)
            return render(request, 'masters/brand.html',{'category':category})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")

def brand_add(request):
    if request.method == 'POST':
        user_id = request.session['user_id']
        form = brandForm(request.POST, request.FILES)
        if form.is_valid():
            category = form.save(commit=False)
            selected_category = request.POST.getlist('category_id')
            photo = request.FILES.get('image')
            desc = request.POST.get('description')

            category.category_id = ','.join(selected_category)
            category.image = photo
            category.description = desc
            category.created_by = user_id
            category.updated_by = user_id
            category.created_on = timezone.now()
            category.updated_on = timezone.now()
            category.save()
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    else:
        form = brandForm()
    return render(request, 'masters/brand.html', {'form': form})


def brand_view(request):
    category = {cat.id: cat.name for cat in category_table.objects.filter(is_active=1)}
        
    data = list(brand_table.objects.filter(status=1).order_by('-id').values())
    
    formatted = []
    for index, item in enumerate(data):
        category_ids = [cat_id.strip() for cat_id in str(item['category_id']).split(',')]
        category_names = []
        for cat_id in category_ids:
            try:
                cat_id_int = int(cat_id)
                if cat_id_int in category:
                    category_names.append(category[cat_id_int])
                else:
                    category_names.append('Unknown')
            except ValueError:
                category_names.append('Unknown')
                
        # Replace 'Unknown' with hyphen if category_names list is empty
        category_display = ', '.join(category_names) if category_names else '-'

        # Replace 'Unknown' with hyphen
        category_display = '-' if category_display == 'Unknown' else category_display

        formatted.append({
            'action': f'<button type="button" onclick="brand_edit(\'{item["id"]}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                       <button type="button" onclick="brand_delete(\'{item["id"]}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>',
            'id': index + 1,
            'brand': item['name'],
            'category': category_display,
            'description': item['description'] if item['description'] else '-',
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'
        })

    return JsonResponse({'data': formatted})





def brand_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = brand_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def brand_update(request):
    if request.method == "POST":
        brand_id = request.POST.get('id')
        brand = brand_table.objects.get(id=brand_id)
        form = brandForm(request.POST, request.FILES, instance=brand)
        if form.is_valid():
            selected_categories = request.POST.getlist('category_id')
            category_names = [category_table.objects.get(id=category_id).name for category_id in selected_categories]
            photo = request.FILES.get('image')
            desc = request.POST.get('description')

            brand.category_id = ','.join(selected_categories)  
            user_id = request.session.get('user_id')
            brand.image = photo
            brand.description = desc
            brand.updated_by = user_id
            brand.updated_on = timezone.now()
            form.save()  # Save the form instance
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})




def brand_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            brand_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except brand_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#```````````````````````````````````UOM``````````````````````````````````````````````

def uom(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            category = category_table.objects.filter(status=1)
            return render(request, 'masters/uom.html',{'category':category})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def uom_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":  
        user_id = request.session['user_id']
        frm = request.POST
        uname = frm.get('name')
        uom = uom_table()
        uom.name=uname
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})



def uom_view(request):
    data = list(uom_table.objects.filter(status=1).order_by('-id').values())
    formatted = [
        {
            'action': '<button type="button" onclick="uom_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>\
                      <button type="button" onclick="uom_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
            # 'id': item['id'], 
            'id': index + 1, 

            'name': item['name'] if item['name'] else '-', 
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        } 
        for index, item in enumerate(data)
    ]
    # formatted.reverse()
    
    return JsonResponse({'data': formatted})

def uom_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = uom_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def uom_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        name = request.POST.get('name')
        is_active = request.POST.get('is_active')
        
        try:
            uom = uom_table.objects.get(id=uom_id)
            uom.name = name
            uom.is_active = is_active
            uom.updated_by = user_id
            uom.updated_on = timezone.now()
            uom.save()
            return JsonResponse({'message': 'success'})
        except uom_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def uom_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            # Update the status field to 0 instead of deleting
            uom_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except uom_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#````````````````````````````````PUBLIC HOLIDAYS```````````````````````````````````````````

def holidays(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'masters/holidays.html')
        else:
            return HttpResponseRedirect('/signin')
    else:
        return HttpResponseRedirect("/signin")



def holidays_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')  # Use .get() to avoid KeyError if 'user_id' is not in session
        frm = request.POST
        hdate = frm.get('date')
        hname = frm.get('name')

        if hdate:
            try:
                hdate_obj = timezone.datetime.strptime(hdate, "%Y-%m-%d").date()
                hyear = hdate_obj.year  # Extract the year from the date object
            except ValueError:
                return JsonResponse({"data": "Failed", "error_message": "Invalid date format. Please use YYYY-MM-DD."})

            holiday = holiday_table(
                date=hdate_obj,  # Store the date object
                year=hyear,
                name=hname,
                created_on=timezone.now(),
                created_by=user_id,
                updated_on=timezone.now(),
                updated_by=user_id
            )
            holiday.save()
            res = "Success"
            return JsonResponse({"data": res})
        else:
            return JsonResponse({"data": "Failed", "error_message": "Date is required."})
    else:
        return JsonResponse({"data": "Failed", "error_message": "Invalid request"})



def holidays_view(request):
    data = list(holiday_table.objects.filter(status=1).order_by('-id').values())
    formatted = [
        {
            'action': '<button type="button" onclick="holidays_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                      <button type="button" onclick="holidays_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
            'id': index + 1, 
            'date': item['date'] if item['date'] else '-', 
            'year': item['year'] if item['year'] else '-', 
            'name': item['name'] if item['name'] else '-', 
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is an integer field with 1 as active
        } 
        for index, item in enumerate(data)
    ]
    return JsonResponse({'data': formatted})




def holidays_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = holiday_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])




def holidays_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        edit_id = request.POST.get('id')
        hdate = request.POST.get('date')
        hname = request.POST.get('name')
        is_active = request.POST.get('is_active')
        # Parse the date to extract the year
        if hdate:
            try:
                hdate_obj = timezone.datetime.strptime(hdate, "%Y-%m-%d").date()
                hyear = hdate_obj.year  
            except ValueError:
                return JsonResponse({"data": "Failed", "error_message": "Invalid date format. Please use YYYY-MM-DD."})
        
        try:
            holiday = holiday_table.objects.get(id=edit_id)
            holiday.date = hdate
            holiday.year = hyear
            holiday.name = hname
            holiday.is_active = is_active
            holiday.updated_by = user_id
            holiday.updated_on = timezone.now()
            holiday.save()
            return JsonResponse({'message': 'success'})
        except EmployeeHolidays.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'Holiday not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})



def holidays_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            holiday_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except holiday_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#````````````````````````````````MASTER FREQUENCY```````````````````````````````````````````


def service_frequency(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'common/frequency.html')
        else:
            return HttpResponseRedirect('/signin')
    else:
        return HttpResponseRedirect("/signin")


def frequency_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        freq = frm.get('frequency')
        time = frm.get('time')
        code = frm.get('code')
        title = frm.get('title')
        description = frm.get('description')
        color = request.POST.get('color_code') 
        frequencies = frequency_table()
        frequencies.frequency=freq
        frequencies.times=time
        frequencies.color=color
        frequencies.frequency_code=code
        frequencies.name=title
        frequencies.description=description
        frequencies.created_on=timezone.now()
        frequencies.created_by=user_id
        frequencies.updated_on=timezone.now()
        frequencies.updated_by=user_id
        frequencies.save()
        res = "Success"
        return JsonResponse({"data": res})



def frequency_view(request):
    data = list(frequency_table.objects.filter(status=1).order_by('-id').values())
    formatted = [
        {
            'action': '<button type="button" onclick="frequency_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>  \
                      <button type="button" onclick="frequency_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></</button>'.format(item['id'], item['id']), 
            # 'id': item['id'], 
            'id': index + 1,
            'title': item['name'] if item['name'] else '-',  
            'code': item['frequency_code'] if item['frequency_code'] else '-',  
            'description': item['description'] if item['description'] else '-',  
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        } 
        for index, item in enumerate(data)
    ]
    # formatted.reverse()
    
    return JsonResponse({'data': formatted})


def frequency_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = frequency_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])

def frequency_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        cid = request.POST.get('id')
        freq= request.POST.get('frequency')
        time = request.POST.get('time')
        code = request.POST.get('code')
        title = request.POST.get('title')
        description = request.POST.get('description')
        color = request.POST.get('color_code') 
        cstatus = request.POST.get('is_active')        
        try:
            frequency = frequency_table.objects.get(id=cid)
            frequency.frequency=freq
            frequency.times=time
            frequency.color=color
            frequency.frequency_code=code
            frequency.name=title
            frequency.description=description
            frequency.is_active=cstatus
            frequency.updated_by = user_id
            frequency.updated_on = timezone.now()
            frequency.save()
            return JsonResponse({'message': 'success'})
        except frequency_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})



def frequency_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            frequency_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except frequency_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#````````````````````````````````````````ASSET LIBRARY``````````````````````````````````````````````

def asset_system(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            frequency = frequency_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            return render(request, 'common/asset_system.html',{'frequency':frequency,'category':category})
        else:
            return HttpResponseRedirect('/signin')
    else:
        return HttpResponseRedirect("/signin")

from django.http import JsonResponse
from django.utils import timezone

def system_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        system = frm.get('system')
        cat_id = frm.get('category')
        report = ','.join(frm.getlist('report'))
        mail = frm.get('mail')
        description = frm.get('description')

        # Initialize a new instance of system_table
        asset = system_table()
        asset.name = system
        asset.category_id = cat_id
        asset.frequency_id = report
        asset.report_emails = mail
        asset.description = description
        asset.created_on = timezone.now()
        asset.created_by = user_id
        asset.updated_on = timezone.now()
        asset.updated_by = user_id

        # Get the name corresponding to category_id
        try:
            category = category_table.objects.get(id=cat_id) 
            asset.parent_code = category.name  # Save the name in parent_code
        except category_table.DoesNotExist:
            asset.parent_code = 'NA'

        asset.save()  # Save the asset instance
        res = "Success"
        return JsonResponse({"data": res})

    return JsonResponse({"data": "Invalid request"}, status=400)



def system_view(request):
    data = list(system_table.objects.filter(status=1).order_by('-id').values())
    formatted = []

    for index, item in enumerate(data):
        system_id = item['id']
        
        # Count specific related objects for this system_id
        action_count = system_action.objects.filter(asset_group_id=system_id, status=1).count()
        finding_count = system_finding.objects.filter(asset_group_id=system_id, status=1).count()
        description_count = system_description.objects.filter(asset_group_id=system_id, status=1).count()
        checklist_count = system_checklist.objects.filter(asset_group_id=system_id, status=1).count()
        
        formatted.append({
            'action': '<button type="button" onclick="system_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                      <button type="button" onclick="system_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(system_id, system_id), 
            'id': index + 1, 
            'category': getItemNameById(category_table, item['category_id']) if getItemNameById(category_table, item['category_id']) else '-',
            'asset': item['name'] if item['name'] else '-', 
            'description': item['description'] if item['description'] else '-', 
            'actions': '<button type="button" onclick="action_page(\'{}\')" class="btn btn-outline-success btn-xs">Actions ({})</button>'.format(system_id, action_count),
            'finding': '<button type="button" onclick="finding_page(\'{}\')" class="btn btn-outline-success btn-xs">Finding ({})</button>'.format(system_id, finding_count),
            'descriptions': '<button type="button" onclick="description_page(\'{}\')" class="btn btn-outline-success btn-xs">Descriptions ({})</button>'.format(system_id, description_count),
            'checklist': '<button type="button" onclick="checklist_page(\'{}\')" class="btn btn-outline-success btn-xs" >Checklist ({})</button>'.format(system_id, checklist_count),
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        })
    
    return JsonResponse({'data': formatted})



def system_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = system_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])


def system_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        system = request.POST.get('system')
        cat = request.POST.get('category')
        report = request.POST.getlist('report')  # Convert report to a list
        mail = request.POST.get('mail')
        description = request.POST.get('description')
        is_active = request.POST.get('is_active')
        
        try:
            asset = system_table.objects.get(id=uom_id)  # Fetch the system
            asset.name = system
            asset.category_id = cat
            asset.report_emails = mail
            asset.description = description

            frequency = asset.frequency_id.split(',') if asset.frequency_id else []

            # Combine frequency and report lists
            updated_batch_days = frequency + report
            updated_batch_days = list(set(updated_batch_days))
            asset.frequency_id = ','.join(updated_batch_days)

            asset.is_active = is_active
            asset.updated_by = user_id
            asset.updated_on = timezone.now()
             # Get the name corresponding to category_id
            try:
                category = category_table.objects.get(id=cat) 
                asset.parent_code = category.name  # Save the name in parent_code
            except category_table.DoesNotExist:
                asset.parent_code = 'NA'

            asset.save()  # Save the asset instance
            asset.save()
            return JsonResponse({'message': 'success'})
        except system_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'System not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def system_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            system_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except system_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#````````````````````````````````````````````ASSET LIBARAY ACTION`````````````````````````````````````````````````````````

def action_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            encoded_id = request.GET.get('id', None)
            if encoded_id:
                plan_id = request.GET.get('id')
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                asset = system_table.objects.filter(id=decoded_id)
                return render(request, 'common/system_action.html', {'id': decoded_id,'asset':asset})
            else:
                return HttpResponse("ID parameter is missing")
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def action_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":  
        user_id = request.session['user_id']
        frm = request.POST
        uname = frm.get('description')
        asset = frm.get('system_id')
        uom = system_action()
        uom.name=uname
        uom.asset_group_id=asset
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})


def action_view(request):   
    if request.method == 'POST':
        system = request.POST.get('system')
        action = system_action.objects.filter(asset_group_id=system)
        data = list(action.filter(status=1).order_by('-id').values())
        formatted = [
            {
                'action': '<button type="button" onclick="action_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>  \
                          <button type="button" onclick="action_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></</button>'.format(item['id'], item['id']), 
                'id': index + 1, 
                'name': item['name'] if item['name'] else '-',  
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
            } 
            for index, item in enumerate(data)
        ]
        return JsonResponse({'data': formatted})



def action_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = system_action.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def action_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        name = request.POST.get('description')
        asset = request.POST.get('system_id')
        is_active = request.POST.get('is_active')        
        try:
            action = system_action.objects.get(id=uom_id)
            action.description = name
            action.asset_group_id = asset
            action.is_active = is_active
            action.updated_by = user_id
            action.updated_on = timezone.now()
            action.save()
            return JsonResponse({'message': 'success'})
        except system_action.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def action_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            # Update the status field to 0 instead of deleting
            system_action.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except system_action.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})



#```````````````````````````````````````ASSET LIBRARY FINDING```````````````````````````````````````````````````````
def finding_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            encoded_id = request.GET.get('id', None)
            if encoded_id:
                plan_id = request.GET.get('id')
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                asset = system_table.objects.filter(id=decoded_id)
                return render(request, 'common/system_finding.html', {'id': decoded_id,'asset':asset})
            else:
                return HttpResponse("ID parameter is missing")
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def finding_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        uname = frm.get('description')
        asset = frm.get('system_id')
        uom = system_finding()
        uom.name=uname
        uom.asset_group_id=asset
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})


def finding_view(request):   
    if request.method == 'POST':
        system = request.POST.get('system')
        action = system_finding.objects.filter(asset_group_id=system)
        data = list(action.filter(status=1).order_by('-id').values())
        formatted = [
            {
                'action': '<button type="button" onclick="finding_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>  \
                          <button type="button" onclick="finding_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></</button>'.format(item['id'], item['id']), 
                 'id': index + 1, 
                'name': item['name'] if item['name'] else '-', 
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
            } 
             for index, item in enumerate(data)
        ]
        return JsonResponse({'data': formatted})



def finding_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = system_finding.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def finding_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        asset = request.POST.get('system_id')
        name = request.POST.get('description')
        asset = request.POST.get('system_id')
        is_active = request.POST.get('is_active')        
        try:
            action = system_finding.objects.get(id=uom_id)
            action.description = name
            action.asset_group_id = asset
            action.asset_group_id=asset
            action.is_active = is_active
            action.updated_by = user_id
            action.updated_on = timezone.now()
            action.save()
            return JsonResponse({'message': 'success'})
        except system_finding.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def finding_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            system_finding.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except system_finding.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#```````````````````````````````````````ASSET LIBRARY DESCRIPTON``````````````````````````````````````````````````````

def description_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            encoded_id = request.GET.get('id', None)
            if encoded_id:
                plan_id = request.GET.get('id')
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                asset = system_table.objects.filter(id=decoded_id)
                return render(request, 'common/system_description.html', {'id': decoded_id,'asset':asset})
            else:
                return HttpResponse("ID parameter is missing")
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def description_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        uname = frm.get('description')
        asset = frm.get('system_id')
        uom = system_description()
        uom.name=uname
        uom.asset_group_id=asset
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})


def description_view(request):   
    if request.method == 'POST':
        system = request.POST.get('system')
        action = system_description.objects.filter(asset_group_id=system)
        data = list(action.filter(status=1).order_by('-id').values())
        formatted = [
            {
                'action': '<button type="button" onclick="description_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>  \
                          <button type="button" onclick="description_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></</button>'.format(item['id'], item['id']), 
                'id': index + 1, 
                'name': item['name'], 
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
            } 
             for index, item in enumerate(data)
        ]
        return JsonResponse({'data': formatted})



def description_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = system_description.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def description_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        name = request.POST.get('description')
        asset = request.POST.get('system_id')
        is_active = request.POST.get('is_active')        
        try:
            action = system_description.objects.get(id=uom_id)
            action.description = name
            action.asset_group_id = asset
            action.is_active = is_active
            action.updated_by = user_id
            action.updated_on = timezone.now()
            action.save()
            return JsonResponse({'message': 'success'})
        except system_description.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def description_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            system_description.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except system_description.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})



#```````````````````````````````````ASSET LIBRARY CHECKLIST``````````````````````````````````````````````

def checklist_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':            
            encoded_id = request.GET.get('id', None)
            if encoded_id:
                plan_id = request.GET.get('id')
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                asset = system_table.objects.filter(id=decoded_id)
                frequency = frequency_table.objects.filter(status=1)
                return render(request, 'common/system_checklist.html', {'id': decoded_id,'asset':asset,'frequency':frequency})
            else:
                return HttpResponse("ID parameter is missing")
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def checklist_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session['user_id']
        frm = request.POST
        frequency = frm.get('frequency')
        question = frm.get('question')
        description = frm.get('description')
        asset = frm.get('system_id')
        uom = system_checklist()
        uom.frequency_id=frequency
        uom.question=question
        uom.description=description
        uom.asset_group_id=asset
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})




def checklist_view(request):   
    if request.method == 'POST':
        system = request.POST.get('system')
        action = system_checklist.objects.filter(asset_group_id=system)
        data = list(action.filter(status=1).order_by('-id').values())
        formatted = []
        for index,item in enumerate(data):
            frequency_id = item['frequency_id']
            frequency = frequency_table.objects.get(id=frequency_id)
            formatted.append({
                'action': '<button type="button" onclick="checklist_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                          <button type="button" onclick="checklist_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
                'id': index + 1, 
                'frequency': frequency.name,  
                'question': item['question'], 
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
            })
        return JsonResponse({'data': formatted})




def checklist_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = system_checklist.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def checklist_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        frequency = request.POST.get('frequency')
        question = request.POST.get('question')
        name = request.POST.get('description')
        asset = request.POST.get('system_id')
        is_active = request.POST.get('is_active')        
        try:
            action = system_checklist.objects.get(id=uom_id)
            action.description = name
            action.frequency_id = frequency
            action.question = question
            action.asset_group_id = asset
            action.is_active = is_active
            action.updated_by = user_id
            action.updated_on = timezone.now()
            action.save()
            return JsonResponse({'message': 'success'})
        except system_checklist.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def checklist_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            system_checklist.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except system_checklist.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})




#```````````````````````````````````CUSTOMER``````````````````````````````````````````````

def customer(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            employee = employee_table.objects.filter(company_id=1,is_superadmin=0,status=1)

            return render(request, 'common/customer.html',{'employee':employee})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def customer_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":  
        user_id = request.session['user_id']
        frm = request.POST
        uname = frm.get('name')
        desc = frm.get('description')
        emp = frm.getlist('employee')
        uom = customer_table()
        uom.name=uname
        uom.description=desc
        uom.employee_id = ','.join(emp)
        uom.created_on=timezone.now()
        uom.created_by=user_id
        uom.updated_on=timezone.now()
        uom.updated_by=user_id
        uom.save()
        res = "Success"
        return JsonResponse({"data": res})





from django.http import JsonResponse

from django.http import JsonResponse
from .models import customer_table, employee_table  # Ensure you have the correct imports

def customer_view(request):
    # Fetch the customers with active status
    data = list(customer_table.objects.filter(status=1).order_by('-id').values())

    employee_id_list = []
    for item in data:
        # Split employee IDs, remove empty strings, and extend the list
        employee_ids = [emp_id for emp_id in item['employee_id'].split(',') if emp_id.strip()]
        employee_id_list.extend(employee_ids)

    # Remove duplicates and convert to integers for the query
    employee_id_list = list(set(map(int, employee_id_list)))

    # Fetch employee names based on the employee IDs
    employees = employee_table.objects.filter(id__in=employee_id_list).values('id', 'name')
    employee_dict = {employee['id']: employee['name'] for employee in employees}

    # Format the response data
    formatted = [
        {
            'action': '<button type="button" onclick="customer_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>\
                       <button type="button" onclick="customer_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']),
            'id': index + 1,
            'name': item['name'] if item['name'] else '-',
            'employee': ' '.join(f'<span class="badge text-bg-success p-1" style="font-size:10pt;">{employee_dict.get(int(emp_id), "-")}</span>' for emp_id in item['employee_id'].split(',') if emp_id.strip()) if item['employee_id'] else '-',
            'description': item['description'] if item['description'] else '-',
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'
        }
        for index, item in enumerate(data)
    ]

    return JsonResponse({'data': formatted})


def customer_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = customer_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])



def customer_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        name = request.POST.get('name')
        desc = request.POST.get('description')
        is_active = request.POST.get('is_active')
        emp = request.POST.getlist('employee')
        
        try:
            uom = customer_table.objects.get(id=uom_id)
            uom.name = name
            uom.description = desc
            uom.employee_id = ','.join(emp)
            uom.is_active = is_active
            uom.updated_by = user_id
            uom.updated_on = timezone.now()
            uom.save()
            return JsonResponse({'message': 'success'})
        except customer_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def customer_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            customer_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except customer_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})




#`````````````````````````````````````````VENDOR````````````````````````````````````````````````````````````

def vendor(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            company = company_table.objects.filter(id=1).first()
            return render(request, 'common/vendor.html',{'company':company})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



import hashlib
from django.http import JsonResponse
from django.utils import timezone
from django.shortcuts import get_object_or_404
from .models import vendor_table, employee_table, company_table
from django.db import IntegrityError

from django.http import JsonResponse
from django.utils import timezone
import hashlib
from .models import vendor_table, employee_table, company_table





def generate_vendor_code(company_id, vendor_prefix):
    try:
        company = company_table.objects.get(id=company_id)
        company_prefix = company.prefix  # Adjust according to your model field
    except company_table.DoesNotExist:
        raise ValueError("Invalid company ID")

    last_vendor = vendor_table.objects.filter(company_code__startswith=company_prefix).aggregate(Max('company_code'))
    
    if last_vendor['company_code__max']:
        last_code = last_vendor['company_code__max']
        last_number = int(last_code.split('-')[-1])  # Extract the numeric part
        new_number = last_number + 1
    else:
        new_number = 1  

    
    new_vendor_code = f"{company_prefix}-{vendor_prefix}-{str(new_number).zfill(6)}"  # Zero-pad to 6 digits
    return new_vendor_code


def generate_employee_code(vendor_id, company_id, prefix):
    if company_id != 0 and vendor_id == 0:
        # Generate code using company prefix
        company = company_table.objects.get(id=company_id)
        prefix = company.prefix
    elif vendor_id != 0 and company_id == 0:
        # Generate code using vendor prefix
        vendor = vendor_table.objects.get(id=vendor_id)
        prefix = vendor.customer_prefix

    # Determine the next number series
    last_employee = employee_table.objects.filter(employee_code__startswith=prefix).order_by('-id').first()
    
    if last_employee:
        # Extracting number series
        last_code = last_employee.employee_code
        num_series = int(last_code.split('-')[-1]) + 1
    else:
        num_series = 1  # Start with 1 if no previous entries

    # Format the number series to six digits
    employee_code = f"{prefix}-{num_series:06}"
    return employee_code



def vendor_add(request):
    if request.method == 'POST':
        user_id = request.session['user_id']
        form = VendorForm(request.POST, request.FILES)
        if form.is_valid():
            frm = request.POST
            name = frm.get('name')
            password = frm.get('password')
            city = frm.get('city')
            state = frm.get('state')
            country = frm.get('country')
            mail = frm.get('mail')
            phone = frm.get('phone')
            prefix = frm.get('prefix')
            person = frm.get('person')
            address = frm.get('address')
            description = frm.get('description')

            # Ensure this returns an integer company ID
            company_id = int(frm.get('company'))  # Cast to int to ensure it's a number
            logo = request.FILES.get('logo')

            # Check for duplicate email or phone
            if vendor_table.objects.filter(email=mail, phone=phone).exists() or employee_table.objects.filter(email=mail).exists():
                return JsonResponse({"status": "Failed", "message": "Email already exists"})

            # Check for duplicate name
            if vendor_table.objects.filter(name=name).exists():
                return JsonResponse({"status": "Failed", "message": "Name already exists"})

            vendor_prefix = generate_vendor_code(company_id, prefix)

            customer = vendor_table(
                name=name,
                password=hashlib.md5(password.encode()).hexdigest(),
                city=city,
                postal_code=state,
                country=country,
                email=mail,
                phone=phone,
                customer_prefix=prefix,
                company_code=vendor_prefix,
                contact_person=person,
                address=address,
                description=description,
                created_on=timezone.now(),
                created_by=user_id,
                updated_on=timezone.now(),
                updated_by=user_id,
                company_id=company_id,
                logo=logo,
                is_active=1,
                status=1
            )
            customer.save()
            vendor_id = customer.id

            # Generate employee code
            employee_code = generate_employee_code(vendor_id, company_id, prefix)  # Pass the prefix here

            # Create and save the employee record
            employee = employee_table(
                employee_code=employee_code,
                employee_role='', 
                user_role='',  
                name=person,
                username=person,  
                address_line1=address,
                address_line2='',  # Default value; modify if needed
                password=hashlib.md5(password.encode()).hexdigest(),
                city=city,
                country=country,
                postal_code=state,
                phone=phone,
                mobile='',  
                email=mail,
                certificate='', 
                is_active=1,
                status=1,
                vendor_id=vendor_id,  
                created_on=timezone.now(),
                updated_on=timezone.now(),
                created_by=user_id,
                updated_by=user_id
            )
            employee.save()
            customer.primary_technician = employee.id
            customer.save()

            return JsonResponse({'message': 'success', 'vendor_id': customer.id})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    else:
        form = VendorForm()
    return render(request, 'masters/category.html', {'form': form})







from django.db.models import Count
from django.http import JsonResponse

from django.db.models import Count, Q, Subquery
from django.http import JsonResponse
from .models import vendor_table, employee_table, project_vendor_table

from django.http import JsonResponse
from django.db.models import Count, Q

from django.http import JsonResponse
from django.db.models import Count, Q

def vendor_view(request):
    # Get all active vendor data
    data = list(vendor_table.objects.filter(status=1).order_by('-id').values())

    # Get a dictionary of vendor_id and the total number of active projects for that vendor
    project_count_dict = project_table.objects.filter(
        is_active=1  # Only count active projects
    ).values('vendor_id').annotate(total_projects=Count('id'))

    # Create a dictionary to hold the count of projects for each vendor
    project_count_lookup = {}
    
    for item in project_count_dict:
        # Split the comma-separated vendor IDs
        vendor_ids = item['vendor_id'].split(',')
        for vendor_id in vendor_ids:
            vendor_id = vendor_id.strip()  # Clean up whitespace
            if vendor_id not in project_count_lookup:
                project_count_lookup[vendor_id] = 0
            project_count_lookup[vendor_id] += item['total_projects']

    formatted = [
        {
            'action': '<button type="button" onclick="vendor_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                      <button type="button" onclick="vendor_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button> \
                      <button type="button" onclick="user_page(\'{}\')" class="btn btn-outline-success btn-xs">Employees</button>'.format(item['id'], item['id'], item['id'], item['id']),
            'id': index + 1, 
            'prefix': item['customer_prefix'], 
            'code': item['company_code'], 
            'name': item['name'], 
            'mail': item['email'], 
            'phone': item['phone'], 
            'city': item['city'], 
            'person': item['contact_person'], 
            'primary': getItemNameById(employee_table, item['primary_technician']),
            # Get the total number of projects assigned to this vendor using the lookup dictionary
            # 'project_assigned': project_count_lookup.get(str(item['id']), 0),  # Use str to match vendor ID format
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'
        } 
        for index, item in enumerate(data)
    ]

    return JsonResponse({'data': formatted})







def vendor_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        vendor_id = request.POST.get('id')
        
        vendor = vendor_table.objects.filter(id=vendor_id).first()
        
        employees = employee_table.objects.filter(vendor_id=vendor_id).values('id', 'name')

        if vendor:
            # Create a dictionary to hold vendor data
            vendor_data = {
                'id': vendor.id,
                'name': vendor.name,
                'email': vendor.email,
                'phone': vendor.phone,
                'customer_prefix': vendor.customer_prefix,
                'contact_person': vendor.contact_person,
                'company_code': vendor.company_code,
                'city': vendor.city,
                'state': vendor.postal_code,
                'country': vendor.country,
                'address': vendor.address,
                'description': vendor.description,
                'primary_technician': vendor.primary_technician,
                'is_active': vendor.is_active,
                'employees': list(employees)  
            }
            return JsonResponse(vendor_data)
        else:
            return JsonResponse({'error': 'Vendor not found'}, status=404)




def vendor_update(request):
    if request.method == "POST":
        category_id = request.POST.get('id')
        customer = vendor_table.objects.get(id=category_id)
        form = VendorForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            name = request.POST.get('name')
            city = request.POST.get('city')
            state = request.POST.get('state')
            country = request.POST.get('country')
            prefix = request.POST.get('prefix')
            primary = request.POST.get('primary_technician')
            user_id = request.session.get('user_id')
            logo = request.FILES.get('logo')
            company = request.POST.get('company')
            active = request.POST.get('is_active')

           
            customer.name = name
            customer.city = city
            customer.postal_code = state
            customer.country = country
            customer.customer_prefix = prefix
            customer.primary_technician = primary
            customer.updated_by = user_id
            customer.updated_on = timezone.now()
            customer.is_active = active
            customer.company_id = company
            customer.logo = logo
            customer.save()            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})








def vendor_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            vendor_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except vendor_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'}) 



#`````````````````````````````````````VENDOR CUSTOMER`````````````````````````````````````````````````````

def user_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':            
            encoded_id = request.GET.get('id', None)
            if encoded_id:
                plan_id = request.GET.get('id')
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                customer = vendor_table.objects.filter(id=decoded_id)
                return render(request, 'common/customer_user.html', {'id': decoded_id,'customer':customer})
            else:
                return HttpResponse("ID parameter is missing")
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")







def user_add(request):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            # Extract form data
            category = form.save(commit=False)
            vendor_id = request.POST.get('company_id')
            company_id = request.POST.get('company', 0)
            employee = request.POST.get('employee')
            name = request.POST.get('nick')
            user = request.POST.get('username')
            finger = request.POST.get('finger')
            prefix = request.POST.get('prefix')
            role = request.POST.get('role')
            schd = int(request.POST.get('is_scheduler', 0))
            tech = int(request.POST.get('is_technician', 0))
            superv = int(request.POST.get('is_supervisor', 0))
            foreg = int(request.POST.get('is_foreigner', 0))
            gps = int(request.POST.get('is_gps', 0))
            pht = int(request.POST.get('is_photo', 0))
            qr = int(request.POST.get('is_qr', 0))
            signature = int(request.POST.get('is_signature', 0))
            sign = request.FILES.get('signature')
            mail = request.POST.get('email')
            pwd = request.POST.get('password')            
            phone = request.POST.get('phone')
            mobile = request.POST.get('mobile')
            address1 = request.POST.get('address_line1')
            address2 = request.POST.get('address_line2')
            city = request.POST.get('city')
            country = request.POST.get('country')
            postal = request.POST.get('postal')
            color = request.POST.get('color_code')  
            vehicle = request.POST.get('vehicle')


            if employee_table.objects.filter(email=mail).exists():
                return JsonResponse({'message': 'error', 'error_message': 'Email already exists'}, status=400)

           
            if company_id != 0 and vendor_id == 0:
                prefix = company_table.objects.get(id=company_id).prefix
            elif vendor_id != 0 and company_id == 0:
                prefix = vendor_table.objects.get(id=vendor_id).customer_prefix
            else:
                prefix = '' 
            
            # Generate employee code
            employee_code = generate_employee_code(vendor_id, company_id, prefix)

            # Save new employee record
            category.vendor_id = vendor_id
            category.company_id = 0
            category.employee_role = employee
            category.name = name
            category.username = user
            category.finger_print = finger            
            category.user_role = role
            category.is_scheduler = schd
            category.is_technician = tech
            category.is_supervisor = superv
            category.is_foreigner = foreg
            category.is_gps = gps
            category.is_photo = pht
            category.is_qr = qr
            category.is_signature = signature
            category.certificate = sign  
            category.email = mail
            category.password = hashlib.md5(pwd.encode()).hexdigest()
            category.phone = phone
            category.mobile = mobile 
            category.address_line1 = address1
            category.address_line2 = address2
            category.city = city
            category.country = country
            category.postal_code= postal
            category.vehicle_number = vehicle
            category.color = color  
            category.employee_code = employee_code
            category.created_by = user_id
            category.updated_by = user_id
            category.created_on = timezone.now()
            category.updated_on = timezone.now()
            category.save()
            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    else:
        form = EmployeeForm()
    return render(request, 'common/customer_user.html', {'form': form})






def user_view(request):   
    if request.method == 'POST':
        user = request.POST.get('user')
        action = employee_table.objects.filter(vendor_id=user)
        data = list(action.filter(status=1).order_by('-id').values())
        formatted = []
        for index,item in enumerate(data):
            formatted.append({
                'action': '<button type="button" onclick="user_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                          <button type="button" onclick="user_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
                # 'id': item['id'], 
                'id':index+1,
                'name': item['username'], 
                'address1': item['address_line1'] if item['address_line1'] else '-', 
                'address2': item['address_line2'] if item['address_line2'] else '-', 
                'city': item['city'] if item['city'] else '-', 
                'state': item['postal_code'] if item['postal_code'] else '-', 
                'empcode': item['employee_code'], 
                'phone': item['phone'] if item['phone'] else '-', 
                'mobile': item['mobile'] if item['mobile'] else '-', 
                'email': item['email'] if item['email'] else '-',    
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
            })
        return JsonResponse({'data': formatted})





def user_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = employee_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])




def user_update(request):
    if request.method == "POST":
        category_id = request.POST.get('id')
        try:
            category = employee_table.objects.get(id=category_id)
        except employee_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'User not found'}, status=404)
        
        form = EmployeeForm(request.POST, request.FILES, instance=category)
        if form.is_valid():
            category = form.save(commit=False)
            cpy = request.POST.get('company_id')
            employee = request.POST.get('employee')
            name = request.POST.get('nick')
            user = request.POST.get('username')
            finger = request.POST.get('finger')
            prefix = request.POST.get('prefix')
            role = request.POST.get('role')
            schd = int(request.POST.get('is_scheduler', 0))
            tech = int(request.POST.get('is_technician', 0))
            superv = int(request.POST.get('is_supervisor', 0))
            foreg = int(request.POST.get('is_foreigner', 0))
            gps = int(request.POST.get('is_gps', 0))
            pht = int(request.POST.get('is_photo', 0))
            qr = int(request.POST.get('is_qr', 0))
            signature = int(request.POST.get('is_signature', 0))
            sign = request.FILES.get('signature')
            mail = request.POST.get('email')
            pwd = request.POST.get('password')            
            phone = request.POST.get('phone')
            mobile = request.POST.get('mobile')
            address1 = request.POST.get('address_line1')
            address2 = request.POST.get('address_line2')
            city = request.POST.get('city')
            country = request.POST.get('country')
            postal = request.POST.get('postal')
            color = request.POST.get('color_code')  # Get color code from POST data
            vehicle = request.POST.get('vehicle')  
            user_id = request.session.get('user_id')
            active = request.POST.get('is_active')

            # Check if email already exists for other users
            if employee_table.objects.filter(email=mail).exclude(id=category_id).exists():
                return JsonResponse({'message': 'error', 'error_message': 'Email already exists'}, status=400)

            # Update the employee record
            category.vendor_id = cpy
            category.employee_role = employee
            category.name = name
            category.username = user
            category.finger_print = finger            
            category.user_role = role
            category.is_scheduler = schd
            category.is_technician = tech
            category.is_supervisor = superv
            category.is_foreigner = foreg
            category.is_gps = gps
            category.is_photo = pht
            category.is_qr = qr
            category.is_signature = signature
            if sign:
                category.certificate = sign
            category.email = mail
            if pwd:  
                category.password = hashlib.md5(pwd.encode()).hexdigest()
            category.phone = phone
            category.mobile = mobile 
            category.address_line1 = address1
            category.address_line2 = address2
            category.city = city
            category.country = country
            category.postal_code = postal
            category.vehicle_number = vehicle
            category.color = color  # Store the color code
            category.is_active = active
            category.updated_by = user_id
            category.updated_on = timezone.now()
            category.save()
            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'}, status=400)


def user_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            employee_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except employee_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})



#`````````````````````````````````VENDOR PROJECT```````````````````````````````````````````````


def project_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        user_id = request.session.get('user_id')
        encoded_id = request.GET.get('id', None)
        
        if encoded_id:
            try:
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
            except (binascii.Error, ValueError):
                return HttpResponse("Invalid encoded ID")
                
            vendor = vendor_table.objects.filter(id=decoded_id)
            user_role = employee_table.objects.filter(vendor_id=0, status=1)
            employee = employee_table.objects.filter(status=1)
            package = package_table.objects.filter(status=1)
            
            if user_type == 'superadmin':
                customer = customer_table.objects.filter(status=1)
            
            elif user_type == 'admin':
                customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
                if customer.exists():
                    print('customer', customer)
                else:
                    customer = None
                    vendor = None
                    print('No customer found for this admin')

            
            return render(request, 'common/project.html', {
                'id': decoded_id,
                'employee':employee,
                'vendor': vendor,
                'user_role': user_role,
                'customer': customer,
                'package':package
            })
        else:
            return HttpResponse("ID parameter is missing")
    else:
        return HttpResponseRedirect("/signin")
#`````````````````````````````````PROJECT```````````````````````````````````````````````


# def project(request):
#     if 'user_id' in request.session:
#         user_id = request.session.get('user_id')
#         print('User',user_id)
#         user_type = request.session.get('user_type')
#         print(user_type)
        
#         vendor = vendor_table.objects.filter(status=1)
#         user_role = employee_table.objects.filter(vendor_id=0, status=1)
#         employee = employee_table.objects.filter(company_id=1,status=1)


#         if user_type == 'superadmin':
#             customer = customer_table.objects.filter(status=1)
        
#         elif user_type == 'admin':
#             customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
#             print('customer',customer)

#         elif user_type == 'admin':
#             customer = customer_table.objects.filter(status=1, employee_id__contains!=str(user_id))
#             vendor = vendor_table.objects.filter(status=1)
#             print('customer',customer)

#         else:
#             return HttpResponseRedirect("/signin")
        
#         return render(request, 'common/project.html', {'vendor': vendor, 'user_role': user_role, 'customer': customer,'employee':employee})

#     else:
#         return HttpResponseRedirect("/signin")
def project(request):
    if 'user_id' in request.session:
        user_id = request.session.get('user_id')
        print('User', user_id)
        user_type = request.session.get('user_type')
        print(user_type)

        vendor = vendor_table.objects.filter(status=1)
        user_role = employee_table.objects.filter(vendor_id=0, status=1)
        employee = employee_table.objects.filter(company_id=1, status=1)
        package = package_table.objects.filter(status=1)

        if user_type == 'superadmin':
            customer = customer_table.objects.filter(status=1)

        elif user_type == 'admin':
            # Filter customers by user_id
            customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
            if customer.exists():
                print('customer', customer)
            else:
                customer = None
                vendor = None
                print('No customer found for this admin')

        else:
            return HttpResponseRedirect("/signin")

        return render(request, 'common/project.html', {
            'vendor': vendor,
            'user_role': user_role,
            'customer': customer,
            'employee': employee,
            'package':package
        })

    else:
        return HttpResponseRedirect("/signin")



from django.http import JsonResponse

def fetch_employees(request):
    customer_id = request.GET.get('customer_id')

    if customer_id:
        # Fetch the customer based on the ID
        customer = customer_table.objects.filter(id=customer_id).first()
        if customer and customer.employee_id:
            employee_ids = map(int, customer.employee_id.split(','))
            employees = employee_table.objects.filter(id__in=employee_ids).values('id', 'name')

            # Return the employee names and IDs in JSON format
            return JsonResponse({'employees': list(employees)})
    
    return JsonResponse({'employees': []})  # Return an empty list if no employees found


def fetch_vendor_employee(request):
    vendor_id = request.GET.get('vendor_id')
    print('vendor_id',vendor_id)

    employees = employee_table.objects.filter(vendor_id=vendor_id, is_active=1, company_id=0).values('id', 'name')

    employee_list = list(employees)
    
    return JsonResponse({'employees': employee_list})


from django.db.models import Max


def project_num_series():
    max_num = project_table.objects.aggregate(Max('num_series'))['num_series__max']
    if max_num is None:
        new_num = 1
    else:
        new_num = max_num + 1    
    return f"{new_num:06d}", new_num

def project_add(request):
    # Check if the request is AJAX and method is POST
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST": 
        user_id = request.session.get('user_id')  # Get the user ID from session
        frm = request.POST
        
        # Directly set the prefix to 'PR'
        common = 'PR'  

        prefix = frm.get('prefix')
        title = frm.get('title')
        start = frm.get('start') or None  
        end = frm.get('end') or None     
        proj = frm.get('project')
        number = frm.get('number')
        technical = frm.get('technical') or 0  
        package = frm.get('package')
        description = frm.get('description')
        mail = frm.get('mail')
        vendor = frm.getlist('vendor[0][vendorId]') or []  
        customer = frm.get('customer') 
        employee = frm.getlist('employee') 

        # Check if project name already exists
        if project_table.objects.filter(name=title).exists():
            return JsonResponse({"status": "Failed", "message": "Project name already exists"})

        try:
            # Get customer record and its employees
            customer_record = customer_table.objects.get(id=customer)
            customer_employees = customer_record.employee_id.split(',')  # Split the employee IDs
        except customer_table.DoesNotExist:
            return JsonResponse({"status": "Failed", "message": "Customer does not exist"})

        # Check if package exists and get its name
        package_name = package_table.objects.filter(id=package).first()
        name = package_name.name if package_name else "-"

        # Generate the new project number using num_series
        project_number_str, project_number_int = project_num_series()  # Get both formatted string and integer

        # Create project code by concatenating the prefix with the zero-padded num series
        project_code = f"{common}{project_number_str}"  # Example: PR000001

        # Create the project record
        project = project_table(
            vendor_id=','.join(vendor),  
            customer_employee_id=','.join(employee), 
            customer_id=customer,
            prefix=prefix,
            name=title,
            start_date=start,  
            end_date=end,      
            project_value=proj,
            incharge_phone=number,
            technician_id=technical,
            package_id=package,
            package=name,
            incharge_email=mail,
            description=description,
            project_code=project_code,  # Assign the generated project code
            created_on=timezone.now(),
            created_by=user_id,
            updated_on=timezone.now(),
            updated_by=user_id,
            num_series=project_number_int  # Store the integer value
        )
        project.save()

        # Loop through vendors and save project vendor records
        for i in range(len(vendor)):
            vendor_id = frm.get(f'vendor[{i}][vendorId]')
            incharge_id = frm.get(f'vendor[{i}][inchargeId]')

            if vendor_id and incharge_id:
                project_vendor = project_vendor_table(
                    project_id=project.id,  
                    vendor_id=vendor_id,
                    incharge_id=incharge_id,
                    created_on=timezone.now(),
                    updated_on=timezone.now(),
                    created_by=user_id,
                    updated_by=user_id
                )
                project_vendor.save()

        return JsonResponse({"data": "Success"})
    
    return JsonResponse({"error": "Invalid request"}, status=400)




from django.db.models import Q, OuterRef, Subquery

def project_view(request):
    if request.method == 'POST':
        customer_id = request.POST.get('customer_id')  
        vendor_id = request.POST.get('vendor_id')  

        if customer_id in [None, '0', '']:
            return JsonResponse({'data': []})

        query = Q(status=1)  
        query &= Q(customer_id=customer_id)

        # Subquery to get project IDs from project_vendor_table based on vendor_id
        if vendor_id not in [None, '0', '']:
            subquery = project_vendor_table.objects.filter(vendor_id=vendor_id, project_id=OuterRef('id')).values('project_id')
            query &= Q(id__in=Subquery(subquery))

        # Get the filtered projects
        action = project_table.objects.filter(query).order_by('-id')
        data = list(action.values())

        # Format the data for the response
        formatted = [
            {
                'action': '<button type="button" onclick="project_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                           <button type="button" onclick="project_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button> \
                           <button type="button" onclick="ad_asset_page(\'{}\')" class="btn btn-outline-success btn-xs">Asset</button>'.format(item['id'], item['id'], item['id']),
                'id': index + 1,
                'code': item['project_code'],
                'package': item['package'],
                'prefix': item['prefix'],
                'head': item['name'],
                'description': item['description'] if item['description'] else '-',
                'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'
            }
            for index, item in enumerate(data)
        ]

        return JsonResponse({'data': formatted})


from django.shortcuts import get_object_or_404

def project_edit(request):
    project_id = request.POST.get('id')
    project = get_object_or_404(project_table, id=project_id)

    # Fetch associated vendor data
    vendors = project_vendor_table.objects.filter(project_id=project_id)

    vendor_data = []
    for vendor in vendors:
        # Assuming Vendor model has a method to get the vendor name
        vendor_name = vendor_table.objects.get(id=vendor.vendor_id).name
        incharge_name = employee_table.objects.get(id=vendor.incharge_id).name  # Assuming UserRole has name field

        vendor_data.append({
            'vendor_id': vendor.vendor_id,
            'vendor_name': vendor_name,
            'incharge_id': vendor.incharge_id,
            'incharge_name': incharge_name
        })

    response_data = {
        'id': project.id,
        'name': project.name,
        'prefix': project.prefix,
        'customer_id': project.customer_id,
        'customer_employee_id': project.customer_employee_id,
        'start_date': project.start_date,
        'end_date': project.end_date,
        'project_value': project.project_value,
        'project_incharge': project.project_incharge,
        'incharge_phone': project.incharge_phone,
        'technician_id': project.technician_id,
        'incharge_email': project.incharge_email,
        'package': project.package_id,
        'is_active': project.is_active,
        'vendor_data': vendor_data  # Add this line
    }

    return JsonResponse(response_data)




import json

# def project_update(request):
#     if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
#         frm = request.POST
#         user_id = request.session.get('user_id')
#         uom_id = frm.get('id')
#         print('uom_id', uom_id)

#         print(f"Attempting to update project with ID: {uom_id}")

#         try:
#             project = project_table.objects.get(id=uom_id)
#             print(f"Found project: {project.name}")

#             vendor_data_json = frm.get('vendor_data') 
#             print('vendor_data_json',vendor_data_json)
#             vendor = json.loads(vendor_data_json)  
#             prefix = frm.get('prefix')
#             title = frm.get('title')
#             start = frm.get('start')
#             end = frm.get('end')
#             proj = frm.get('project')
#             number = frm.get('number')
#             package = frm.get('package')
#             mail = frm.get('mail')
#             description = frm.get('description')
#             is_active = frm.get('is_active')
#             customer = frm.get('customer')
#             employee = frm.getlist('employee')  # Assuming you're passing employee as a list
#             print('Employee:', employee)


#             # Handle vendors in project_vendor_table
#             existing_vendors = project_vendor_table.objects.filter(project_id=uom_id)

#             package_name = package_table.objects.filter(id=package).first()
#             name = package_name.name if package_name else "-"

#             for vendor_entry in existing_vendors:
#                 if vendor_entry.vendor_id not in [v['vendor_id'] for v in vendor]:
#                     pending_tickets = ticket_table.objects.filter(vendor_id=vendor_entry.vendor_id, project_id=uom_id, ticket_status='pending')
#                     if pending_tickets.exists():
#                         return JsonResponse({
#                             'message': 'error',
#                             'error_message': 'Cannot remove vendor as there are pending tickets associated with this project.'
#                         })
#                     vendor_entry.delete()

#             for vendor_info in vendor:
#                 vendor_id = vendor_info['vendor_id']
#                 technical = vendor_info['technical_id']
#                 existing_vendor = project_vendor_table.objects.filter(project_id=uom_id, vendor_id=vendor_id).first()
#                 if existing_vendor:
#                     existing_vendor.incharge_id = technical  # Assuming incharge is the same as technical
#                     existing_vendor.updated_on = timezone.now()
#                     existing_vendor.updated_by = user_id
#                     existing_vendor.save()
#                 else:
#                     # Create a new vendor entry if it does not exist
#                     project_vendor_table.objects.create(
#                         project_id=uom_id,
#                         vendor_id=vendor_id,
#                         incharge_id=technical,  # Assuming the incharge is same as technical
#                         created_on=timezone.now(),
#                         updated_on=timezone.now(),
#                         created_by=user_id,
#                         updated_by=user_id
#                     )

#             # Update project fields
#             project.customer_employee_id = ','.join(employee)
#             print("Customer Employee ID:", project.customer_employee_id)
#             project.customer_id = customer
#             project.prefix = prefix
#             project.name = title

#             if start and end:
#                 try:
#                     project.start_date = start if start != '0000-00-00' else None
#                     project.end_date = end if end != '0000-00-00' else None
#                 except ValidationError:
#                     return JsonResponse({'message': 'error', 'errors': "Invalid date format for warranty start or end date."}, status=400)

#             project.project_value = proj
#             project.incharge_phone = number
#             project.technician_id = 0
#             project.package = name
#             project.package_id = package
#             project.incharge_email = mail
#             project.description = description
#             project.is_active = is_active
#             project.updated_by = user_id
#             project.updated_on = timezone.now()
#             project.save()

#             return JsonResponse({'message': 'success'})
#         except project_table.DoesNotExist:
#             print(f"Project with ID {uom_id} does not exist.")
#             return JsonResponse({'message': 'error', 'error_message': 'Project not found'})
#     else:
#         return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def project_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        frm = request.POST
        user_id = request.session.get('user_id')
        uom_id = frm.get('id')

        print('uom_id', uom_id)
        print(f"Attempting to update project with ID: {uom_id}")

        try:
            project = project_table.objects.get(id=uom_id)
            print(f"Found project: {project.name}")

            # Parse vendor data from JSON
            vendor_data_json = frm.get('vendor_data')
            print('vendor_data_json', vendor_data_json)
            vendor = json.loads(vendor_data_json)
            
            # Collect form data
            prefix = frm.get('prefix')
            title = frm.get('title')
            start = frm.get('start')
            end = frm.get('end')
            proj = frm.get('project')
            number = frm.get('number')
            package = frm.get('package')
            mail = frm.get('mail')
            description = frm.get('description')
            is_active = frm.get('is_active')
            customer = frm.get('customer')

            # Parse employee_ids from the form data (which should be a JSON string)
            employee_ids_json = frm.get('employee_ids')
            if employee_ids_json:
                employee_ids = json.loads(employee_ids_json)
                print('Employee IDs:', employee_ids)  # Make sure this is a list now
            else:
                employee_ids = []

            # Handle vendor logic (same as your existing logic)
            existing_vendors = project_vendor_table.objects.filter(project_id=uom_id)
            package_name = package_table.objects.filter(id=package).first()
            name = package_name.name if package_name else "-"

            # Remove vendors not in the updated list if they have no pending tickets
            for vendor_entry in existing_vendors:
                if vendor_entry.vendor_id not in [v['vendor_id'] for v in vendor]:
                    pending_tickets = ticket_table.objects.filter(
                        vendor_id=vendor_entry.vendor_id, 
                        project_id=uom_id, 
                        ticket_status='pending'
                    )
                    if pending_tickets.exists():
                        return JsonResponse({
                            'message': 'error',
                            'error_message': 'Cannot remove vendor as there are pending tickets associated with this project.'
                        })
                    vendor_entry.delete()

            # Update or create vendor entries
            for vendor_info in vendor:
                vendor_id = vendor_info['vendor_id']
                technical = vendor_info['technical_id']
                existing_vendor = project_vendor_table.objects.filter(
                    project_id=uom_id, vendor_id=vendor_id
                ).first()
                
                if existing_vendor:
                    existing_vendor.incharge_id = technical
                    existing_vendor.updated_on = timezone.now()
                    existing_vendor.updated_by = user_id
                    existing_vendor.save()
                else:
                    project_vendor_table.objects.create(
                        project_id=uom_id,
                        vendor_id=vendor_id,
                        incharge_id=technical,
                        created_on=timezone.now(),
                        updated_on=timezone.now(),
                        created_by=user_id,
                        updated_by=user_id
                    )

            # Update project fields
            project.customer_employee_id = ','.join(employee_ids)  # Ensure this is a list of employee IDs
            project.customer_id = customer
            project.prefix = prefix
            project.name = title

            # Validate and update dates
            if start and end:
                try:
                    project.start_date = start if start != '0000-00-00' else None
                    project.end_date = end if end != '0000-00-00' else None
                except ValidationError:
                    return JsonResponse({
                        'message': 'error',
                        'errors': "Invalid date format for start or end date."
                    }, status=400)

            project.project_value = proj
            project.incharge_phone = number
            project.package = name
            project.package_id = package
            project.incharge_email = mail
            project.description = description
            project.is_active = is_active
            project.updated_by = user_id
            project.updated_on = timezone.now()
            project.save()

            return JsonResponse({'message': 'success'})
        except project_table.DoesNotExist:
            print(f"Project with ID {uom_id} does not exist.")
            return JsonResponse({'message': 'error', 'error_message': 'Project not found'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})



def project_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            project_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except project_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#``````````````````````````````````````ASSET`````````````````````````````````````````````````````````


def get_vendors_for_project(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'GET':
        project_id = request.GET.get('project_id')
        vendors = project_vendor_table.objects.filter(project_id=project_id, is_active=1).values('vendor_id')
        vendor_ids = [vendor['vendor_id'] for vendor in vendors]
        
        vendor_data = vendor_table.objects.filter(id__in=vendor_ids).values('id', 'name')
        
        return JsonResponse(list(vendor_data), safe=False)
    return JsonResponse({'error': 'Invalid request'}, status=400)


def get_projects_for_vendor(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'GET':
        vendor_id = request.GET.get('vendor_id')
        
        if not vendor_id:
            return JsonResponse({'error': 'Vendor ID not provided'}, status=400)
        
        projects = project_vendor_table.objects.filter(vendor_id=vendor_id, is_active=1).values('project_id')
        project_ids = [project['project_id'] for project in projects]
                                                                                                                                                                               
        # Fetch project details
        project_data = project_table.objects.filter(id__in=project_ids).values('id', 'name')
        
        return JsonResponse(list(project_data), safe=False)
    return JsonResponse({'error': 'Invalid request'}, status=400)



def fetch_projects(request):
    vendor_id = request.GET.get('vendor_id')
    if vendor_id == 'Select':
            return JsonResponse({'data': []})
    projects = project_table.objects.filter(vendor_id=vendor_id, status=1)
    project_list = [{'id': proj.id, 'name': proj.name ,'code':proj.project_code} for proj in projects]
    return JsonResponse({'projects': project_list})




def load_employee(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'GET':
        vendor_id = request.GET.get('vendor_id')
        
        technicians = employee_table.objects.filter(vendor_id=vendor_id).values('id', 'name','employee_code')
        
        return JsonResponse(list(technicians), safe=False)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)


# ````````````````````````````````````````````````````````````````````````````````````````````````````````````````
from django.http import FileResponse, HttpResponseNotFound
from django.conf import settings
import os

def download_file(request):
    # Use STATIC_ROOT instead of STATIC_URL to get the correct filesystem path
    file_path = os.path.join(settings.STATIC_ROOT, 'assets/excel/facility_sample.xlsx')  # Adjust if necessary
    print(f"File path: {file_path}")  # Debugging line

    # Check if the file exists
    if os.path.exists(file_path):
        return FileResponse(open(file_path, 'rb'), as_attachment=True, filename='facility_sample.xlsx')
    else:
        return HttpResponseNotFound("File not found.")

def asset(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        user_id = request.session.get('user_id')
        vendor = vendor_table.objects.filter(status=1)
        project = project_table.objects.filter(status=1)
        asset = asset_table.objects.filter(status=1)
        system = system_table.objects.filter(status=1)
        frequency = frequency_table.objects.filter(status=1)
        brand = brand_table.objects.filter(status=1)
        category = category_table.objects.filter(status=1)
        if user_type == 'superadmin':
            customer = customer_table.objects.filter(status=1)
        
        elif user_type == 'admin':
            customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))

        else:
            return HttpResponseRedirect("/signin")

        return render(request, 'common/asset.html',{"vendor":vendor,'project':project,'asset':asset,'system':system,'frequency':frequency,'brand':brand,
                'category':category,'customer':customer})
    else:
        return HttpResponseRedirect("/signin")



from django.http import JsonResponse
from django.db.models import Q

# def get_vendors_by_project(request):
#     if request.method == 'POST':
#         project_id = request.POST.get('project_id')
#         print('project_id',project_id)
        
#         try:
#             project = project_table.objects.get(id=project_id)
#             vendor_ids = project.vendor_id.split(',')  # Assuming vendor_id is comma-separated
            
#             # Get vendors that match the vendor IDs
#             vendors = vendor_table.objects.filter(id__in=vendor_ids).values('id', 'name')

#             return JsonResponse({'vendors': list(vendors)})
#         except project_table.DoesNotExist:
#             return JsonResponse({'vendors': []})  # Return empty if project not found

#     return JsonResponse({'vendors': []})  # Return empty for non-POST requests



# def get_vendors_by_project(request, project_id):
#     try:
#         project = project_table.objects.get(id=project_id)
#         print('project',project)
#         project_vendor = project_vendor_table.objects.filter(project_id=project_id)
#         print('project_vendor',project_vendor)
#         vendor_ids = project_vendor.vendor_id
#         print('vendor_ids',vendor_ids)

#         vendors = vendor_table.objects.filter(id__in=vendor_ids, status=1).values('id', 'name')

#         print('vendors',vendors)
#         return JsonResponse(list(vendors), safe=False)
#     except project_table.DoesNotExist:
#         return JsonResponse({'error': 'Project not found'}, status=404)


def get_vendors_by_project(request, project_id):
    try:
        # Retrieve the project
        project = project_table.objects.get(id=project_id)
        print('project', project)

        # Filter project_vendor records for the given project_id
        project_vendor_qs = project_vendor_table.objects.filter(project_id=project_id)
        print('project_vendor', project_vendor_qs)

        # Extract vendor_id values from the QuerySet
        vendor_ids = [pv.vendor_id for pv in project_vendor_qs]
        print('vendor_ids', vendor_ids)

        # Query the vendor_table using the vendor_ids and filter by status
        vendors = vendor_table.objects.filter(id__in=vendor_ids, status=1).values('id', 'name')
        print('vendors', vendors)

        # Return the list of vendors as JSON response
        return JsonResponse(list(vendors), safe=False)
    
    except project_table.DoesNotExist:
        return JsonResponse({'error': 'Project not found'}, status=404)


def get_all_vendors(request):
    vendors = vendor_table.objects.filter(status=1).values('id', 'name')
    return JsonResponse({'vendors': list(vendors)})



from rest_framework.response import Response
from rest_framework.decorators import api_view

from django.http import JsonResponse

def fetch_technicians(request):
    vendor_id = request.GET.get('vendor_id')
    
    if vendor_id:
        technicians = employee_table.objects.filter(vendor_id=vendor_id).values('id', 'name')
        primary_technician_id = vendor_table.objects.filter(id=vendor_id).values('primary_technician').first().get('primary_technician')
        
        return JsonResponse({
            'technicians': list(technicians),
            'primary_technician_id': primary_technician_id
        })
    
    return JsonResponse({'technicians': [], 'primary_technician_id': None})

def fetch_assets(request):
    project_id = request.GET.get('project_id')
    vendor_id = request.GET.get('vendor_id')
    
    if project_id and vendor_id:
        # Filter asset_vendor based on project_id and vendor_id
        asset_vendors = asset_vendor_table.objects.filter(project_id=project_id, vendor_id=vendor_id)

        # Get all asset_ids associated with the filtered asset_vendor records
        asset_ids = asset_vendors.values_list('asset_id', flat=True)

        # Filter parent assets based on the retrieved asset_ids
        parent_assets = asset_table.objects.filter(id__in=asset_ids, status=1, asset_parent_id=0).values('id', 'name')
    else:
        parent_assets = []

    return JsonResponse({'parent_assets': list(parent_assets)})


def fetch_assets2(request):
    project_id = request.GET.get('project_id')
    vendor_id = request.GET.get('vendor_id')
    
    if project_id and vendor_id:
        # Filter asset_vendor based on project_id and vendor_id
        asset_vendors = asset_vendor_table.objects.filter(project_id=project_id, vendor_id=vendor_id)

        # Get all asset_ids associated with the filtered asset_vendor records
        asset_ids = asset_vendors.values_list('asset_id', flat=True)

        # Filter parent assets based on the retrieved asset_ids
        parent_assets = asset_table.objects.filter(id__in=asset_ids, status=1, asset_parent_id=0).values('id', 'name')
    else:
        parent_assets = []

    return JsonResponse({'parent_assets': list(parent_assets)})





def fetch_asset_parents(request):
    if request.method == 'GET':
        customer_id = request.GET.get('customer_id')
        project_id = request.GET.get('project_id')

        assets = asset_table.objects.filter(
            customer_id=customer_id,
            project_id=project_id,
            asset_parent_id=0,
            status=1
        ).values('id', 'name', 'asset_item_code')  
        print('check',assets.count())

        return JsonResponse({'assets': list(assets)})
    return JsonResponse({'error': 'Invalid request'}, status=400)

# ````````````````````````PROJECT TO ASSET```````````````````````````````````



from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
import base64
import binascii

def ad_asset_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        user_id = request.session.get('user_id')
        encoded_id = request.GET.get('id', None)

        if encoded_id:
            try:
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')

                # Assuming decoded_id is a customer ID, retrieve the item_id
                item_id = project_table.objects.filter(id=decoded_id).values_list('vendor_id', flat=True).first()
                customer_id = project_table.objects.filter(id=decoded_id).values_list('customer_id', flat=True).first()

                # Fetch necessary data for the page
                vendor = vendor_table.objects.filter(status=1)
                project = project_table.objects.filter(status=1)
                asset = asset_table.objects.filter(status=1)
                system = system_table.objects.filter(status=1)
                frequency = frequency_table.objects.filter(status=1)
                brand = brand_table.objects.filter(status=1)
                category = category_table.objects.filter(status=1)
                technician = employee_table.objects.filter(status=1)

                if user_type == 'superadmin':
                    customer = customer_table.objects.filter(status=1)
                elif user_type == 'admin':
                    customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
                else:
                    return HttpResponse("Unauthorized access", status=403)

                return render(request, 'common/asset.html', {
                    'id': decoded_id,
                    "customer": customer,
                    'project': project,
                    'asset': asset,
                    'system': system,
                    'frequency': frequency,
                    'brand': brand,
                    'category': category,
                    'technician': technician,
                    'item_id': item_id,
                    'customer_id':customer_id,
                    'vendor':vendor
                })

            except (binascii.Error, ValueError):
                return HttpResponse("Invalid encoded ID", status=400)

        else:
            return HttpResponse("ID parameter is missing", status=400)

    return HttpResponseRedirect("/signin")  # Redirect if user is not authenticated


#``````````````````````````````````ASSET ADD PAGE```````````````````````````

def asset_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == "superadmin" and "admin":
            decoded_customer_id = 0            

            decoded_project_id = 0

            encoded_customer_id = request.GET.get('customer_id', 0)
            
            encoded_project_id = request.GET.get('project_id', 0)

            if encoded_customer_id:
                try:
                    decoded_customer_id = base64.b64decode(encoded_customer_id).decode('utf-8')
                except Exception as e:
                    return HttpResponse(f"Error decoding customer ID: {str(e)}")

            if encoded_project_id:
                try:
                    decoded_project_id = base64.b64decode(encoded_project_id).decode('utf-8')
                except Exception as e:
                    return HttpResponse(f"Error decoding project ID: {str(e)}")

            # Fetch data from database
            vendor = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            asset = asset_table.objects.filter(status=1)
            system = system_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            brand = brand_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1)

            # Render template with context
            return render(request, 'common/asset_add.html', {
                "vendor": vendor,
                'project': project,
                'asset': asset,
                'system': system,
                'frequency': frequency,
                'brand': brand,
                'category': category,
                'technician': technician,
                'decoded_customer_id': decoded_customer_id,
                'decoded_project_id': decoded_project_id
            })
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")

      




def unique_asset_id(vendor_id, project_id):
    try:
        return asset_table.objects.filter(status=True, vendor_id=vendor_id, project_id=project_id).latest('num_series')
    except asset_table.DoesNotExist:
        return None

def generate_unique_asset_code(vendor_id, project_id):
    while True:
        unique_id = unique_asset_id(vendor_id, project_id)
        
        if unique_id is not None:
            product_code = str(unique_id.num_series)  # Ensure product_code is a string
            number = ''.join(filter(str.isdigit, product_code))
            
            # Increment the code
            if '999' in product_code and len(number) == 3:
                product_code = product_code.replace('999', '1000', 1)
            elif '9999' in product_code and len(number) == 4:
                product_code = product_code.replace('9999', '10000', 1)
            elif '99999' in product_code and len(number) == 5:
                product_code = product_code.replace('99999', '100000', 1)
            elif '999999' in product_code and len(number) == 6:
                product_code = product_code.replace('999999', '1000000', 1)
            else:
                product_code = str(int(product_code) + 1).zfill(6)
        else:
            product_code = '000001'
        
        # Check if the generated product_code is unique for this vendor and project
        if not asset_table.objects.filter(vendor_id=vendor_id, project_id=project_id, num_series=product_code).exists():
            return product_code



#     if request.method == 'POST':
#         user_id = request.session.get('user_id')
#         form = assetForm(request.POST, request.FILES)
        
#         if form.is_valid():
#             try:
#                 asset = form.save(commit=False)
                
#                 # Retrieve form data
#                 frequency = request.POST.getlist('frequency_id')
#                 time = request.POST.getlist('frequency_time')
#                 vendor_id = request.POST.get('vendor_id')
#                 parent = request.POST.get('asset_parent_id')
#                 parent_name = request.POST.get('parent_name')
#                 item = request.POST.get('asset_item_code')
#                 brand = request.POST.get('brand_id')
#                 category = request.POST.get('category_id')
#                 technician = request.POST.get('technician_id')
#                 pmt = request.POST.get('is_pmt')
#                 location = request.POST.get('location')
#                 serial = request.POST.get('serial_number')
#                 sensor = request.POST.get('is_smart_sensor')
#                 stype = request.POST.get('sensor_type')
#                 address = request.POST.get('macAddress')
#                 threshold = request.POST.get('threshold')
#                 camera = request.POST.get('is_camera')
#                 commission = request.POST.get('commissioning_date')
#                 service = request.POST.get('service_start_date')
#                 warranty = request.POST.get('warranty_start_date') 
#                 end = request.POST.get('warranty_end_date')
#                 description = request.POST.get('description')
#                 file = request.FILES.get('file_name')
#                 project_id = request.POST.get('project_id')
#                 estimated_life = request.POST.get('estimated_life ')
                
#                 customer = get_object_or_404(vendor_table, id=vendor_id)
#                 project = get_object_or_404(project_vendor_table, project_id=project_id)
                
#                 customer_prefix = customer.customer_prefix
#                 project_prefix = project.prefix
#                 customer_id = project.customer_id
                
#                 # Generate unique num_series inside an atomic transaction
#                 with transaction.atomic():
#                     num_series = generate_unique_asset_code(vendor_id, project_id)
#                     ticket_no = f"{customer_prefix}-{project_prefix}-{num_series}"

#                     asset.asset_item_code = ticket_no
#                     asset.customer_id = customer_id
#                     asset.num_series = num_series
#                     asset.vendor_id = int(vendor_id) if vendor_id else 0
#                     asset.asset_parent_id = int(parent) if parent else 0
#                     asset.asset_parent_name = parent_name
#                     asset.item_id = 0
#                     asset.asset_group_id = int(item) if item else 0
#                     asset.brand_id = int(brand) if brand else 0
#                     asset.project_id = int(project_id) if project_id else 0
#                     asset.category_id = int(category) if category else 0
#                     asset.technician_id = int(technician) if technician else 0
#                     asset.is_pmt = bool(pmt)  
#                     asset.location = location
#                     asset.serial_number = serial
#                     asset.is_smart_sensor = bool(sensor)  
#                     asset.sensor_type = stype
#                     asset.macAddress = address
#                     asset.threshold = threshold 
#                     asset.is_camera = bool(camera) 
#                     asset.commissioning_date = commission
#                     asset.service_start_date = service
                    
#                     # Handle warranty dates
#                     if warranty and end:
#                         try:
#                             asset.warranty_start_date = warranty if warranty != '0000-00-00' else None
#                             asset.warranty_end_date = end if end != '0000-00-00' else None
#                         except ValidationError:
#                             return JsonResponse({'message': 'error', 'errors': "Invalid date format for warranty start or end date."}, status=400)
                    
#                     asset.description = description
#                     asset.estimated_life = estimated_life if estimated_life else None
#                     asset.floor_plan = file
#                     asset.frequency_time = ','.join(time)
#                     asset.frequency_id = ','.join(frequency)
#                     asset.created_by = user_id
#                     asset.updated_by = user_id
#                     asset.created_on = timezone.now()
#                     asset.updated_on = timezone.now()
                    
#                     # Save the asset
#                     try:
#                         asset.save()
#                     except IntegrityError:
#                         # If duplicate is found, regenerate num_series and retry
#                         num_series = generate_unique_asset_code(vendor_id, project_id)
#                         ticket_no = f"{customer_prefix}-{project_prefix}-{num_series}"
#                         asset.num_series = num_series
#                         asset.asset_item_code = ticket_no
#                         asset.save()
                
#                 return JsonResponse({'message': 'success'})
            
#             except ValueError as ve:
#                 return JsonResponse({'message': 'error', 'errors': str(ve)}, status=400)
        
#         else:
#             errors = form.errors.as_json()
#             return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    
#     else:
#         form = assetForm()
    
#     return render(request, 'common/asset_add.html', {'form': form})

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db import transaction, IntegrityError
import json
# from .models import asset_table, asset_vendor_table, vendor_table, project_vendor_table  # Adjust import based on your app structure
# from .forms import assetForm  # Adjust import based on your app structure

from django.http import JsonResponse
import json
from django.shortcuts import get_object_or_404
from django.db import transaction, IntegrityError
from .models import vendor_table, project_vendor_table, asset_vendor_table
from .forms import assetForm

def asset_add(request):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        form = assetForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                asset = form.save(commit=False)
                frequency = request.POST.getlist('frequency_id')
                time = request.POST.getlist('frequency_time')
                vendor_data = json.loads(request.POST.get('vendor_data', '[]'))  # Changed 'vendors' to 'vendor_data'
                
                print('vendor_data:', vendor_data)
                frequency = request.POST.getlist('frequency_ids')
                project_id = request.POST.get('project_id')
                parent = request.POST.get('asset_parent_id')
                parent_name = request.POST.get('parent_name')
                item = request.POST.get('asset_item_code')
                brand = request.POST.get('brand_id')
                category = request.POST.get('category_id')
                pmt = request.POST.get('is_pmt')
                location = request.POST.get('location')
                serial = request.POST.get('serial_number')
                sensor = request.POST.get('is_smart_sensor')
                stype = request.POST.get('sensor_type')
                address = request.POST.get('macAddress')
                threshold = request.POST.get('threshold')
                camera = request.POST.get('is_camera')
                commission = request.POST.get('commissioning_date')
                service = request.POST.get('service_start_date')
                warranty = request.POST.get('warranty_start_date') 
                end = request.POST.get('warranty_end_date')
                description = request.POST.get('description')
                file = request.FILES.get('file_name')
                estimated_life = request.POST.get('estimated_life')

                for vendor in vendor_data:
                    vendor_id = vendor.get('vendor_id')

                    customer = get_object_or_404(vendor_table, id=vendor_id)
                    project_code = get_object_or_404(project_table, id=project_id)
                    company = company_table.objects.filter(id=1).first()

                    customer_prefix = customer.customer_prefix
                    project_prefix = project_code.prefix
                    customer_id = project_code.customer_id

                    # Generate unique num_series inside an atomic transaction
                    with transaction.atomic():
                        num_series = generate_unique_asset_code(vendor_id, project_id)
                        ticket_no = f"{customer_prefix}-{project_prefix}-{num_series}"

                        # Populate asset fields
                        asset.asset_item_code = ticket_no
                        asset.customer_id = customer_id
                        asset.project_id = project_id
                        asset.num_series = num_series
                        asset.asset_parent_id = int(parent) if parent else 0
                        asset.asset_parent_name = parent_name
                        asset.item_id = 0
                        asset.asset_group_id = int(item) if item else 0
                        asset.brand_id = int(brand) if brand else 0
                        asset.category_id = int(category) if category else 0
                        asset.is_pmt = bool(pmt)
                        asset.location = location
                        asset.serial_number = serial
                        asset.is_smart_sensor = bool(sensor)
                        asset.sensor_type = stype
                        asset.macAddress = address
                        asset.threshold = threshold
                        asset.is_camera = bool(camera)
                        asset.commissioning_date = commission
                        asset.service_start_date = service

                        # Handle warranty dates
                        if warranty and end:
                            try:
                                asset.warranty_start_date = warranty if warranty != '0000-00-00' else None
                                asset.warranty_end_date = end if end != '0000-00-00' else None
                            except ValidationError:
                                return JsonResponse({'message': 'error', 'errors': "Invalid date format for warranty start or end date."}, status=400)
                        
                        asset.description = description
                        asset.estimated_life = estimated_life if estimated_life else None
                        asset.floor_plan = file
                        asset.frequency_time = ','.join(time)
                        asset.frequency_id = ','.join(frequency)
                        asset.created_by = user_id
                        asset.updated_by = user_id
                        asset.created_on = timezone.now()
                        asset.updated_on = timezone.now()
                        
                        # Save the asset
                        asset.save()

                        # Now save the vendor data in asset_vendor_table
                        asset_vendor = asset_vendor_table(
                            customer_id=customer_id,
                            project_id=project_id,  # Ensure it's an integer
                            vendor_id=int(vendor.get('vendor_id')),    # Ensure it's an integer
                            technician_id=int(vendor.get('technician_id')),  # Ensure it's an integer
                            frequency_id=int(vendor.get('frequency_ids')),  # Ensure it's an integer
                            asset_id=asset.id,
                            created_by=user_id,
                            company_id = company.id,
                            updated_by=user_id,
                            created_on=timezone.now(),
                            updated_on=timezone.now()
                        )
                        asset_vendor.save()

                return JsonResponse({'message': 'success'})

            except ValueError as ve:
                return JsonResponse({'message': 'error', 'errors': str(ve)}, status=400)
            except IntegrityError as e:
                return JsonResponse({'message': 'error', 'errors': str(e)}, status=400)
        
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)
    
    else:
        form = assetForm()
    
    return render(request, 'common/asset_add.html', {'form': form})


# def asset_view(request):
#     vendor_id = request.POST.get('vendor')
#     project_id = request.POST.get('project')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     customer_id = request.POST.get('customer')

#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     query = Q(status=1, asset_parent_id=0) 

#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)

#     if vendor_id and vendor_id.isdigit():
#         query &= Q(vendor_id=vendor_id)

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)

#     if system_id and system_id.isdigit():
#         query &= Q(asset_group_id=system_id)

#     assets = asset_table.objects.filter(query).order_by('-id')

#     category_map = {cat.id: cat.name for cat in category_table.objects.all()}
#     brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
#     project_map = {proj.id: proj.name for proj in project_table.objects.all()}
#     system_map = {sys.id: sys.name for sys in system_table.objects.all()}
#     vendor_map = {sys.id: sys.name for sys in vendor_table.objects.all()}
#     technician_map = {sys.id: sys.name for sys in employee_table.objects.exclude(tec_reference_id=0)}

#     total_asset_count = assets.count()
#     print('total_asset_count',total_asset_count)

#     data = []
#     index = 1  
#     for item in assets:

#         frequency_names = []
#         frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

#         for freq_id in frequency_ids:
#             if freq_id.isdigit():
#                 try:
#                     freq_name = frequency_table.objects.get(id=int(freq_id)).name
#                     frequency_names.append(freq_name)
#                 except frequency_table.DoesNotExist:
#                     print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

#         frequency_str = ', '.join(frequency_names)

#         completed_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, ticket_status="Completed", status=1).count()
#         total_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, status=1).count()


#         formatted_item = {
#             'empty': '',
#             # 'id': index,  # Use the manual index
#             'id': item.id,  # Use the manual index
#             'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
#                       '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
#                       '</div>',
#             'category': category_map.get(item.category_id, '-'),
#             'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
#             'qr': item.asset_item_code if item.asset_item_code else '-',
#             'code': system_map.get(item.asset_group_id, '-'),
#             'project': project_map.get(item.project_id, '-'),
#             'technician': technician_map.get(item.technician_id, '-'),
#             'vendor': vendor_map.get(item.vendor_id, '-'),
#             'name': item.name if item.name else '-',
#             'qty': item.quantity if item.quantity else '-',
#             'location': item.location if item.location else '-',
#             'frequency': frequency_str,
#             'serial': item.serial_number if item.serial_number else '-',
#             'estimate': item.estimated_life if item.estimated_life else '-',
#             'brand': brand_map.get(item.brand_id, '-'),
#             'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
#             'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
#             'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
#             'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
#         }

#         data.append(formatted_item)
    

#         index += 1  # Increment index manually

   
#     return JsonResponse({'data': data, 'total_asset_count': total_asset_count})


# def asset_view(request):
#     vendor_id = request.POST.get('vendor')
#     project_id = request.POST.get('project')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     customer_id = request.POST.get('customer')

#     # Check for valid customer and project IDs
#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     vendor_query = Q(status=1)

#     if customer_id.isdigit():
#         vendor_query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         vendor_query &= Q(project_id=project_id)
#         print('vendor_query project_id',vendor_query)

#     if vendor_id and vendor_id.isdigit():
#         vendor_query &= Q(vendor_id=vendor_id)
#         print('vendor_query vendor_id',vendor_query)


#     asset_vendor_ids = asset_vendor_table.objects.filter(vendor_query).values_list('asset_id', flat=True)
#     print('asset_vendor_ids', asset_vendor_ids)

#     query = Q(status=1, asset_parent_id=0, id__in=asset_vendor_ids)
#     print('query', query)

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)

#     if system_id and system_id.isdigit():
#         query &= Q(asset_group_id=system_id)

#     assets = asset_table.objects.filter(query).order_by('-id')
#     print('assets', assets.count())

#     # Maps for categories, brands, projects, systems, vendors, and technicians
#     category_map = {cat.id: cat.name for cat in category_table.objects.all()}
#     brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
#     project_map = {proj.id: proj.name for proj in project_table.objects.all()}
#     system_map = {sys.id: sys.name for sys in system_table.objects.all()}
#     vendor_map = {ven.id: ven.name for ven in vendor_table.objects.all()}
#     technician_map = {tec.id: tec.name for tec in employee_table.objects.exclude(tec_reference_id=0)}

#     total_asset_count = assets.count()
#     print('total_asset_count', total_asset_count)

#     data = []
#     for index, item in enumerate(assets, start=1):  # Automatically index from 1
#         frequency_names = []
#         frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

#         for freq_id in frequency_ids:
#             if freq_id.isdigit():
#                 try:
#                     freq_name = frequency_table.objects.get(id=int(freq_id)).name
#                     frequency_names.append(freq_name)
#                 except frequency_table.DoesNotExist:
#                     print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

#         frequency_str = ', '.join(frequency_names)

#         # Retrieve details from asset_vendor_table
#         asset_vendor_details = asset_vendor_table.objects.filter(asset_id=item.id).first()
        
#         if asset_vendor_details:
#             customer_name = vendor_map.get(asset_vendor_details.customer_id, '-')
#             project_name = project_map.get(asset_vendor_details.project_id, '-')
#             technician_name = technician_map.get(asset_vendor_details.technician_id, '-')
#             vendor_name = vendor_map.get(asset_vendor_details.vendor_id, '-')
#         else:
#             customer_name = project_name = technician_name = vendor_name = '-'

#         completed_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, ticket_status="Completed", status=1).count()
#         total_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, status=1).count()

#         formatted_item = {
#             'empty': '',
#             'id': item.id,
#             'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
#                       '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
#                       '</div>',
#             'category': category_map.get(item.category_id, '-'),
#             'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
#             'qr': item.asset_item_code if item.asset_item_code else '-',
#             'code': system_map.get(item.asset_group_id, '-'),
#             'project': project_name,
#             'technician': technician_name,
#             'vendor': vendor_name,
#             'name': item.name if item.name else '-',
#             'qty': item.quantity if item.quantity else '-',
#             'location': item.location if item.location else '-',
#             'frequency': frequency_str,
#             'serial': item.serial_number if item.serial_number else '-',
#             'estimate': item.estimated_life if item.estimated_life else '-',
#             'brand': brand_map.get(item.brand_id, '-'),
#             'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
#             'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
#             'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
#             'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
#         }

#         data.append(formatted_item)

#     return JsonResponse({'data': data, 'total_asset_count': total_asset_count})


def asset_view(request):
    # Retrieve POST parameters
    vendor_id = request.POST.get('vendor')
    project_id = request.POST.get('project')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    customer_id = request.POST.get('customer')

    # Return empty data if customer or project IDs are invalid
    if customer_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  
    if project_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    # Build a base query for the asset_vendor_table
    vendor_query = Q(status=1)

    # Apply filters based on POST parameters
    if customer_id and customer_id.isdigit():
        vendor_query &= Q(customer_id=customer_id)

    if project_id and project_id.isdigit():
        vendor_query &= Q(project_id=project_id)
        print('vendor_query project_id:', vendor_query)

    if vendor_id and vendor_id.isdigit():
        vendor_query &= Q(vendor_id=vendor_id)
        print('vendor_query vendor_id:', vendor_query)

    # Filter asset IDs from asset_vendor_table using the constructed vendor_query
    asset_vendor_ids = asset_vendor_table.objects.filter(vendor_query).values_list('asset_id', flat=True)
    print('asset_vendor_ids:', asset_vendor_ids)

    # Build the main query for assets based on the filtered asset IDs
    query = Q(status=1, asset_parent_id=0, id__in=asset_vendor_ids)
    print('query:', query)

    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)

    if system_id and system_id.isdigit():
        query &= Q(asset_group_id=system_id)

    # Query the assets based on the constructed filters
    assets = asset_table.objects.filter(query).order_by('-id')
    print('assets count:', assets.count())

    # Retrieve mapping dictionaries for categories, brands, projects, systems, vendors, and technicians
    category_map = {cat.id: cat.name for cat in category_table.objects.all()}
    brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
    project_map = {proj.id: proj.name for proj in project_table.objects.all()}
    system_map = {sys.id: sys.name for sys in system_table.objects.all()}
    vendor_map = {ven.id: ven.name for ven in vendor_table.objects.all()}
    technician_map = {tec.id: tec.name for tec in employee_table.objects.exclude(tec_reference_id=0)}

    total_asset_count = assets.count()
    print('total_asset_count:', total_asset_count)

    # Prepare the data for the response
    data = []
    for index, item in enumerate(assets, start=1):
        frequency_names = []
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

        # Fetch frequency names
        for freq_id in frequency_ids:
            if freq_id.isdigit():
                try:
                    freq_name = frequency_table.objects.get(id=int(freq_id)).name
                    frequency_names.append(freq_name)
                except frequency_table.DoesNotExist:
                    print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

        frequency_str = ', '.join(frequency_names)

        # Retrieve all vendor details for the current asset
        asset_vendor_details = asset_vendor_table.objects.filter(asset_id=item.id)
        
        # Gather all vendor names as a comma-separated string
        vendor_names = ', '.join([vendor_map.get(details.vendor_id, '-') for details in asset_vendor_details])
        customer_name = project_name = technician_name = '-'

        if asset_vendor_details.exists():
            first_detail = asset_vendor_details.first()
            customer_name = vendor_map.get(first_detail.customer_id, '-')
            project_name = project_map.get(first_detail.project_id, '-')
            technician_name = technician_map.get(first_detail.technician_id, '-')

        # Calculate completed and total ticket counts
        completed_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, ticket_status="Completed", status=1).count()
        total_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, status=1).count()

        # Format each asset item for the response
        formatted_item = {
            'empty': '',
            'id': item.id,
            'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
                      '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
                      '</div>',
            'category': category_map.get(item.category_id, '-'),
            'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
            'qr': item.asset_item_code if item.asset_item_code else '-',
            'code': system_map.get(item.asset_group_id, '-'),
            'project': project_name,
            'technician': technician_name,
            'vendor': vendor_names,  # Use the comma-separated vendor names
            'name': item.name if item.name else '-',
            'qty': item.quantity if item.quantity else '-',
            'location': item.location if item.location else '-',
            'frequency': frequency_str,
            'serial': item.serial_number if item.serial_number else '-',
            'estimate': item.estimated_life if item.estimated_life else '-',
            'brand': brand_map.get(item.brand_id, '-'),
            'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
            'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
            'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
            'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
        }

        data.append(formatted_item)

    return JsonResponse({'data': data, 'total_asset_count': total_asset_count})



# def qar_view(request):
#     customer_id = request.POST.get('customer')
#     vendor_id = request.POST.get('vendor')
#     project_id = request.POST.get('project')

#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

    
#     query = Q(status=1)

#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)

    
    

#     print('query', query)   

#     assets = qar_table.objects.filter(query).order_by('-id')
#     print('assets', assets.count())

#     category_map = {cat.id: cat.name for cat in category_table.objects.all()}
#     brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
#     project_map = {proj.id: proj.name for proj in project_table.objects.all()}
#     system_map = {sys.id: sys.name for sys in system_table.objects.all()}
#     vendor_map = {ven.id: ven.name for ven in vendor_table.objects.all()}
#     technician_map = {tec.id: tec.name for tec in employee_table.objects.exclude(tec_reference_id=0)}   
   

#     data = []
#     for index, item in enumerate(assets):    

#         formatted_item = {
#             'id': index + 1,           
#             'year': item.year,
#             'month': item.month,
#             'customer':getItemNameById(customer_table, item.customer_id) if item.customer_id else '-',
#             'project': getItemNameById(project_table, item.project_id) if item.project_id else '-',
#             # 'vendor':item.project_id,
#             'asset':getItemNameById(asset_table, item.asset_id) if item.asset_id else '-',
#             'group':getItemNameById(system_table, item.asset_group_id) if item.asset_group_id else '-',
#             'frequency':getItemNameById(frequency_table, item.frequency_id) if item.frequency_id else '-',
#             'status':item.qar_status           
#         }

#         data.append(formatted_item)

#     return JsonResponse({'data': data})




        

# ``````````````````````````````````````````GENERATE ASSET QR````````````````````````````````````

@csrf_exempt
def generate_qr(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        selected_ids = request.POST.get('selected_ids', '').strip()
        print('selected_ids', selected_ids)
        ids_list = list(map(int, selected_ids.split(',')))  # Convert to integers
        print('ids_list', ids_list)

        qr_codes = []

        
        # print('Querying assets with IDs:', ids_list)
        
        assets = asset_table.objects.filter(id__in=ids_list)
        print('assets', assets)

        for asset in assets:
            data = f"Asset Item Code: {asset.asset_item_code}"

            try:
                system_entry = system_table.objects.get(id=asset.asset_group_id)
                print('system_entry',system_entry)
                asset_group_name = system_entry.name  
            except system_table.DoesNotExist:
                asset_group_name = '-'

            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=5,
                border=4,
            )
            qr.add_data(data)
            qr.make(fit=True)

            img = qr.make_image(fill='black', back_color='white')
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()

            qr_codes.append({
                'qrcode_url': 'data:image/png;base64,' + img_str,
                'asset_item_code': asset.asset_item_code if asset.asset_item_code else '-',
                'name': asset.name if asset.name else '-',
                'location': asset.location if asset.location else '-',
                'asset_group_name': asset_group_name,  # Assign the retrieved name here
            })

        request.session['qr_codes'] = qr_codes
        request.session['ids_list'] = ids_list
        return JsonResponse({'success': True, 'qr_codes': qr_codes})

    return JsonResponse({'error': 'Invalid request'})



@csrf_exempt
def display_qr_codes(request):
    qr_codes = request.session.get('qr_codes', [])
    
    qr_list = request.session.get('ids_list', [])
    
    # Fetch assets based on the IDs in qr_list
    assets = asset_table.objects.filter(id__in=qr_list)
    asset_count = assets.count()
    print('assets',assets)
    
    tot_data = assets.count()
    print('tot_data',tot_data)
    
    context = {
        'qr_codes': qr_codes,
        'qrcode_list': assets,
        'tot_data': tot_data,
    }
    return render(request, 'qr_code.html', context)


# ```````````````````````````````````ASSET EDIT PAGE (TAB BASE)````````````````````````````````````````````````````
def asset_edit(request):
    if 'user_id' in request.session:
        user_id = request.session['user_id']
        encoded_id = request.GET.get('id', None)
        if encoded_id:
            plan_id = request.GET.get('id')
            decoded_id = base64.b64decode(encoded_id).decode('utf-8')
            asset = asset_table.objects.get(id=decoded_id)  # Use get() instead of filter()
            customer = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            assets = asset_table.objects.filter(status=1)
            system = system_table.objects.filter(status=1)
            # #print(system)
            frequency = frequency_table.objects.filter(status=1)
            brand = brand_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            return render(request, 'tab.html', {'id': decoded_id, 'asset': asset, 'customer': customer, 'project': project, 'assets': assets, 'system': system, 'frequency': frequency, 'brand': brand, 'category': category})


#``````````````````````````````````````````TAB PAGE NAVIGATION``````````````````````````````  

def load_asset(request):
    if request.method == 'POST':
        tab_id = request.POST.get('tab_id')  
        item_id = request.POST.get('item_id')
        print('item_id',item_id)

        if tab_id == 'home':
            asset = get_object_or_404(asset_table, id=item_id)
            asset_vendor = asset_vendor_table.objects.filter(asset_id=item_id).first()
            vendor_id = asset_vendor.vendor_id
            print('vendor_id',vendor_id)
            vendor = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            assets = asset_table.objects.filter(status=1)
            system = system_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            brand = brand_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1)
            print('asset',asset)
            return render(request, 'common/asset_tab.html', {'item_id': item_id,'asset': asset, 'vendor': vendor, 'project': project, 'assets': assets, 'system': system, 'frequency': frequency, 'brand': brand, 'category': category,'technician':technician,'vendor_id':vendor_id})
    
        
        elif tab_id == 'profile':
           
            item_id = request.POST.get('item_id')
            asset = asset_table.objects.filter(id=item_id)        
            return render(request, 'common/asset_view.html', {'item_id': item_id,'asset':asset})

        elif tab_id == 'contact':
            return render(request, 'index.html', {'item_id': item_id})

        else:
            content = "Invalid tab selected"
            return JsonResponse({'content': content})
    else:
        return HttpResponseNotAllowed(['POST'])




def asset_edit_view(request):
    asset_id = request.POST.get('asset_id')
    print('asset_id',asset_id)
    data = list(asset_vendor_table.objects.filter(asset_id=asset_id, status=1).order_by('-id').values())

    formatted = []
    
    for index, item in enumerate(data):
        # Get frequency IDs and their names
        frequency_ids = item['frequency_id'].split(',') if item['frequency_id'] else []
        frequency_names = frequency_table.objects.filter(id__in=frequency_ids).values_list('name', flat=True)  # Assuming the name field in Frequency model is 'name'
        
        # Join frequency names into a string
        frequency_display = ', '.join(frequency_names) if frequency_names else '-'

        formatted.append({
            'action': '<button type="button" onclick="asset_vendor_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button>'.format(item['id'], item['id']), 
            'id': index + 1, 
            'vendor': getItemNameById(vendor_table, item['vendor_id']) if item['vendor_id'] else '-', 
            'technician': getItemNameById(employee_table, item['technician_id']) if item['technician_id'] else '-', 
            'frequency': frequency_display,  
            'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        })

    return JsonResponse({'data': formatted})


def list_view(request):
    asset_id = request.POST.get('asset_id')
    data = list(asset_table.objects.filter(status=1,asset_parent_id=asset_id).order_by('-id').values())
    data = []
    for index, item in enumerate(data, start=1):  # Automatically index from 1
        frequency_names = []
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

        for freq_id in frequency_ids:
            if freq_id.isdigit():
                try:
                    freq_name = frequency_table.objects.get(id=int(freq_id)).name
                    frequency_names.append(freq_name)
                except frequency_table.DoesNotExist:
                    print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

        frequency_str = ', '.join(frequency_names)
        asset_vendor_details = asset_vendor_table.objects.filter(asset_id=asset_id).first()
        if asset_vendor_details:
            customer_name = vendor_map.get(asset_vendor_details.customer_id, '-')
            project_name = project_map.get(asset_vendor_details.project_id, '-')
            technician_name = technician_map.get(asset_vendor_details.technician_id, '-')
            vendor_name = vendor_map.get(asset_vendor_details.vendor_id, '-')
        else:
            customer_name = project_name = technician_name = vendor_name = '-'
    
        formatted_item = {
            'empty': '',
            'id': item.id,
            'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
                      '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
                      '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
                      '</div>',
            'category': category_map.get(item.category_id, '-'),
            'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
            'qr': item.asset_item_code if item.asset_item_code else '-',
            'code': system_map.get(item.asset_group_id, '-'),
            'project': project_name,
            'technician': technician_name,
            'vendor': vendor_name,
            'name': item.name if item.name else '-',
            'qty': item.quantity if item.quantity else '-',
            'location': item.location if item.location else '-',
            'frequency': frequency_str,
            'serial': item.serial_number if item.serial_number else '-',
            'estimate': item.estimated_life if item.estimated_life else '-',
            'brand': brand_map.get(item.brand_id, '-'),
            'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
            'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
            'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
            'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
        }
        data.append(formatted_item)

    return JsonResponse({'data': data})



from django.http import JsonResponse
from django.utils import timezone
from .models import asset_vendor_table, uom_table  # Import your models

from django.http import JsonResponse
from django.utils import timezone
from .models import asset_vendor_table

def asset_vendor_add(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":  
        user_id = request.session['user_id']
        frm = request.POST
        project = frm.get('project_id')
        vendor = frm.get('vendor_id')
        technician = frm.get('technician_id')
        frequency = frm.getlist('frequency_id')
        asset = frm.get('asset_id')
        company_id = company_table.objects.filter(id=1).first()

        # Check if the same vendor is already associated with the project
        if asset_vendor_table.objects.filter(project_id=project, vendor_id=vendor, asset_id=asset).exists():
            return JsonResponse({'message': 'error', 'error_message': 'Vendor already added for this project.'})

        project_code = get_object_or_404(project_table, id=project)
        customer_id = project_code.customer_id

        # Create new asset vendor entry
        uom = asset_vendor_table()
        uom.frequency_id = ','.join(frequency)
        uom.company_id = company_id.id
        uom.customer_id = customer_id
        uom.project_id = project if project else 0
        uom.vendor_id = vendor
        uom.technician_id = technician
        uom.asset_id = asset
        uom.created_on = timezone.now()
        uom.created_by = user_id
        uom.updated_on = timezone.now()
        uom.updated_by = user_id
        uom.save()

        # Return success message
        return JsonResponse({'message': 'success'})
    
    # Return error for invalid requests
    return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})

def asset_vendor_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        user_id = request.session.get('user_id')
        uom_id = request.POST.get('id')
        frm = request.POST  
        print('uom_id',uom_id)
        project = frm.get('project_id')
        vendor = frm.get('vendor_ids')
        technician = frm.get('technician_id')
        frequency = frm.getlist('frequency_id')
        asset = frm.get('asset_id')
        active = frm.get('is_active')
        project_code = get_object_or_404(project_table, id=project)
        company_id = company_table.objects.filter(id=1).first()
        customer_id = project_code.customer_id
          
        
        
        try:
            uom = asset_vendor_table.objects.get(id=uom_id)
            print('asset_vendor_table',uom)

            

            uom.frequency_id = ','.join(frequency)
            uom.company_id = company_id.id
            uom.project_id = project
            uom.customer_id = customer_id
            uom.vendor_id = vendor
            uom.technician_id = technician
            uom.asset_id = asset
            uom.is_active = active
            uom.updated_by = user_id
            uom.updated_on = timezone.now()
            uom.save()
            return JsonResponse({'message': 'success'})
        except asset_vendor_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'UOM not found'})
    return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


def asset_vendor_edit(request):
    asset_id = request.POST.get('id')  
    print('asset_id',asset_id)
    data = list(asset_vendor_table.objects.filter(id=asset_id, status=1).order_by('-id').values())
    print('data',data)

    if not data:
        return JsonResponse({'error': 'Asset not found'}, status=404)

    item = data[0]  # Assuming you only want the most recent entry

    # Get frequency IDs and their names
    frequency_ids = item['frequency_id'].split(',') if item['frequency_id'] else []
    frequency_names = frequency_table.objects.filter(id__in=frequency_ids).values_list('name', flat=True)
    frequency_display = ', '.join(frequency_names) if frequency_names else '-'

    response_data = {
        'id': item['id'],
        'project_id': item['project_id'],
        'vendor_id': item['vendor_id'],
        'technician_id': item['technician_id'],
        'frequency_id': frequency_display,
        'frequency_ids': frequency_ids  ,
        'asset_id': item['asset_id'] ,
        'is_active':item['is_active']
    }
    print('response_data',response_data)

    return JsonResponse(response_data)


def asset_update(request):
    if request.method == "POST":
        category_id = request.POST.get('asset_id')
        asset = asset_table.objects.get(id=category_id)
        user_id = request.session['user_id']
        form = assetForm(request.POST, request.FILES, instance=asset)
        if form.is_valid():
            asset = form.save(commit=False)
            frequency = request.POST.getlist('frequency_ids')
            time = request.POST.getlist('frequency_time')
            parent = request.POST.get('asset_parent_id')
            parent_name = request.POST.get('parent_name')
            item = request.POST.get('asset_item_code')
            brand = request.POST.get('brand_id')
            category = request.POST.get('category_id')
            technician = request.POST.get('technician_id')
            pmt = request.POST.get('is_pmt')
            location = request.POST.get('location')
            serial = request.POST.get('serial_number')
            sensor = request.POST.get('is_smart_sensor')
            stype = request.POST.get('sensor_type')
            address = request.POST.get('macAddress')
            threshold = request.POST.get('threshold')
            camera = request.POST.get('is_camera')
            commission = request.POST.get('commissioning_date')
            service = request.POST.get('service_start_date')
            warranty = request.POST.get('warranty_start_date')
            end = request.POST.get('warranty_end_date')
            description = request.POST.get('description')
            file = request.FILES.get('file_name')
            print('file',file)
            project_id = request.POST.get('project_id')
            asset.asset_parent_id = parent
            asset.parent_name = parent_name
            asset.item_id = item
            asset.brand_id = brand
            asset.project_id = project_id
            asset.category_id = category
            asset.technician_id = technician
            asset.is_pmt = pmt
            asset.location = location
            asset.serial_number = serial
            asset.is_smart_sensor = sensor
            asset.sensor_type = stype
            asset.macAddress = address
            asset.macAddress = threshold
            asset.is_camera = camera
            asset.commissioning_date = commission
            asset.service_start_date = service

            if warranty and end:
                try:
                    asset.warranty_start_date = warranty if warranty != '0000-00-00' else None
                    asset.warranty_end_date = end if end != '0000-00-00' else None
                except ValidationError:
                    return JsonResponse({'message': 'error', 'errors': "Invalid date format for warranty start or end date."}, status=400)
            
            asset.description = description
            asset.floor_plan = file
            print( asset.floor_plan )
            asset.frequency_time = ','.join(time)
            asset.frequency_id = ','.join(frequency)
            asset.updated_by = user_id
            asset.updated_on = timezone.now()
            form.save()            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})


def asset_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            asset_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except asset_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


# ``````````````````````````````````ASSET QAR``````````````````````

def generate_qar(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        frm = request.POST
        test = request.POST.get('id')
        print('test', test)
        assets = asset_table.objects.filter(id=test)
        if assets.exists():
            check = assets.first().asset_group_id
            print('check', check)
            system = system_checklist.objects.filter(asset_group_id=check)
            print('system',system)
        
        data = asset_table.objects.filter(id=test)
        if data.exists():
            return JsonResponse(data.values().first())
        else:
            return JsonResponse({'error': 'No data found'}, status=404)
    else:
        return JsonResponse({'error': 'Invalid request'}, status=400)





# ```````````````````````````ASSET TO TICKET PAGE``````````````````````````````````````````
def ticket_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        user_id = request.session.get('user_id')
        encoded_id = request.GET.get('id', None)
        
        print(f"User ID: {request.session.get('user_id')}, User Type: {user_type}, Encoded ID: {encoded_id}")  # Debug info

        if encoded_id:
            try:
                decoded_id = base64.b64decode(encoded_id).decode('utf-8')
                print(f"Decoded ID: {decoded_id}")  # Debug info
            except (binascii.Error, ValueError):
                return HttpResponse("Invalid encoded ID")

            asset = asset_table.objects.filter(id=decoded_id).first()
            print('asset',asset)
            if not asset:
                print("Asset not found")  # Debug info
                return HttpResponse("Asset not found", status=404)

            # Extracting details from the asset
            asset_id = asset.id
            vendor_id = asset.vendor_id
            project_id = asset.project_id
            customer_id = asset.customer_id
            technician_id = asset.technician_id


            # Querying the necessary tables
            asset2 = asset_table.objects.filter(status=1)
            vendor = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1).exclude(vendor_id=0).order_by('-id')
            system = system_table.objects.filter(status=1)

            # Fetch customers based on user type
            if user_type == 'superadmin':
                customer = customer_table.objects.filter(status=1)
            elif user_type == 'admin':
                customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
            else:
                print("Unauthorized access attempt")  # Debug info
                return HttpResponse("Unauthorized access", status=403)

            # Log the number of records fetched
            print(f"Fetched records - Vendors: {vendor.count()}, Projects: {project.count()}, Categories: {category.count()}, Frequencies: {frequency.count()}, Technicians: {technician.count()}, Systems: {system.count()}, Customers: {customer.count()}")  # Debug info

            # Render the ticket page with the necessary context
            return render(request, 'common/tickets.html', {
                'id': decoded_id,
                'asset': asset,
                'vendor_id': vendor_id,
                'project_id': project_id,
                'technician_id': technician_id,
                'customer_id': customer_id,
                'vendor': vendor,
                'project': project,
                'asset2': asset2,
                'category': category,
                'frequency': frequency,
                'technician': technician,
                'system': system,
                'customer': customer, 
                'asset_id':asset_id # Ensure customer is passed to the template
            })
        else:
            print("ID parameter is missing")  # Debug info
            return HttpResponse("ID parameter is missing", status=400)
    else:
        print("User not signed in")  # Debug info
        return HttpResponseRedirect("/signin")


#`````````````````````TICKET GENERATE````````````````````````````` 



def generate_schedule(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        asset_id = request.POST.get('id')
        asset = asset_table.objects.filter(id=asset_id).first()
        vendor_id = asset.vendor_id
        technicians = employee_table.objects.filter(vendor_id=vendor_id)  # Fetch all technicians for this vendor
        
        technician_list = [{'id': tech.id, 'name': tech.name} for tech in technicians]
        
        if asset:
            selected_technician_id = asset.technician_id  # The selected technician's ID, if any
            
            data = {
                'id': asset.id,
                'asset_item_code': asset.asset_item_code,
                'frequency_id': asset.frequency_id,
                'technicians': technician_list,  # Send the list of technicians
                'selected_technician_id': selected_technician_id,
                'vendor_id': asset.vendor_id
            }
            return JsonResponse(data)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)




















def unique_ticket_id(vendor_id, project_id):
    try:
        print('ticket',vendor_id,project_id)
        return ticket_table.objects.filter(status=True, vendor_id=vendor_id, project_id=project_id).latest('num_series')
    except ticket_table.DoesNotExist:
        return None
 
def generate_unique_ticket_code(vendor_id, project_id):
    unique_id = unique_ticket_id(vendor_id, project_id)
    print('unique_id', unique_id)

    if unique_id is not None:
        product_code = str(unique_id.num_series)  # Ensure product_code is a string
        number = ''.join(filter(str.isdigit, product_code))
        print('number', number)
        print('product_code', product_code)

        if '999' in product_code and len(number) == 3:
            product_code = product_code.replace('999', '1000', 1)
        elif '9999' in product_code and len(number) == 4:
            product_code = product_code.replace('9999', '10000', 1)
        elif '99999' in product_code and len(number) == 5:
            product_code = product_code.replace('99999', '100000', 1)
        elif '999999' in product_code and len(number) == 6:
            product_code = product_code.replace('999999', '1000000', 1)
        else:
            product_code = str(int(product_code) + 1).zfill(6)
    else:
        product_code = '000001'

    return product_code




def generate_unique_color():
    return "#{:06x}".format(random.randint(0, 0xFFFFFF))

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
import json
from .models import asset_table, vendor_table, project_table, frequency_table, ticket_table  # Import your models as needed
from datetime import datetime
from django.utils import timezone

def ticket_save(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=400)
    
    try:
        data = json.loads(request.body)
        asset_id = data.get('asset_id')
        technician_id = data.get('technician_id')  # Get technician ID from data
        vendor_id = data.get('vendor_id')  # Get technician ID from data
        tickets = data.get('tickets')
        user_id = request.session['user_id']

        if not asset_id or not technician_id or not tickets:
            return JsonResponse({'error': 'Missing required parameters'}, status=400)

        asset = get_object_or_404(asset_table, id=asset_id)

        category_id = asset.category_id
        category = asset_table.objects.filter(id=asset_id).values_list('category_id', flat=True).first()
        system = asset_table.objects.filter(id=asset_id).values_list('item_id', flat=True).first()
        
        # Fetch customer and project details
        customer = get_object_or_404(vendor_table, id=asset.vendor_id)
        project = get_object_or_404(project_table, id=asset.project_id)
        
        customer_prefix = customer.customer_prefix.strip()  # Remove any leading/trailing spaces
        project_prefix = project.prefix.strip()  # Remove any leading/trailing spaces

        for ticket_data in tickets:
            frequency = get_object_or_404(frequency_table, name=ticket_data['frequency'])
            num_series = generate_unique_ticket_code(asset.vendor_id, asset.project_id)

            # Construct ticket number without spaces and special characters
            ticket_no = f"{customer_prefix}{project_prefix}{num_series}"
            
            # Generate a unique color for this ticket
            unique_color = generate_unique_color()

            ticket = ticket_table.objects.create(
                num_series=num_series,
                vendor_id=vendor_id,
                category_id=category,
                project_id=asset.project_id,
                customer_id=asset.customer_id,
                system_id=system,
                technician_id=technician_id,
                ticket_date=ticket_data['ticket_date'],
                schedule_date=ticket_data['ticket_date'],
                name=ticket_data['frequency'],
                asset_item_id=asset_id,
                frequency_id=frequency.id,
                ticket_time=datetime.now(),
                created_by=user_id, 
                updated_by=user_id,
                created_on=timezone.now(), 
                updated_on=timezone.now(),
                ticket_status='Pending',
                ticket_no=ticket_no,
                color=unique_color 
            )

        return JsonResponse({'message': 'success'})
    
    except json.JSONDecodeError as e:
        return JsonResponse({'error': f'Invalid JSON: {e}'}, status=400)
    except frequency_table.DoesNotExist:
        return JsonResponse({'error': 'Frequency name does not exist'}, status=400)



def ticket_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = ticket_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])




from datetime import datetime
from django.http import JsonResponse
from django.utils import timezone
from .models import ticket_table



from datetime import timedelta

def ticket_update(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
        try:
            user_id = request.session.get('user_id')
            req_id = request.POST.get('id')
            rdate = request.POST.get('request_date')
            rtime = request.POST.get('request_time')
            frequency = request.POST.getlist('frequency')
            customer = request.POST.get('customer')
            project = request.POST.get('project')
            asset = request.POST.get('asset')
            technician = request.POST.get('technician')
            rtype = request.POST.get('request_type')
            rstatus = request.POST.get('request_status')

            hour = request.POST.get('hours')
            priority = request.POST.get('priority')
            action = request.POST.get('action')
            findings = request.POST.get('findings')
            description = request.POST.get('description')
            is_active = request.POST.get('is_active')

            ticket = ticket_table.objects.get(id=req_id)

            # Check the current status
            current_status = ticket.ticket_status

            # Condition 3: Prevent changing status if already 'partial'
            if current_status == 'partial' and rstatus in ['pending', 'open', 'hold']:
                return JsonResponse({'message': 'error', 'error_message': 'Cannot change status from partial to pending, open, or hold.'})

            # Condition 1: Save start date when changing from 'pending' to 'open'
            if current_status == 'pending' and rstatus == 'open':
                ticket.start_date = timezone.now()

            # Condition 2: Save end date when status changes to 'partial'
            if rstatus == 'partial':
                ticket.end_date = timezone.now()

                # Calculate total hours between start and end date
                if ticket.start_date and ticket.end_date:
                    time_difference = ticket.end_date - ticket.start_date
                    total_seconds = time_difference.total_seconds()
                    total_hours = total_seconds // 3600
                    total_minutes = (total_seconds % 3600) // 60
                    ticket.total_hrs = f"{int(total_hours)}:{int(total_minutes):02d}"  # Format as hour:minute

            # Update other ticket fields
            ticket.ticket_date = rdate
            ticket.ticket_time = rtime
            ticket.frequency_id = ','.join(frequency)
            ticket.vendor_id = customer
            ticket.project_id = project
            ticket.asset_item_id = asset
            ticket.technician_id = technician
            ticket.ticket_type = rtype
            ticket.ticket_status = rstatus

            ticket.priority = priority
            ticket.action = action
            ticket.findings = findings
            ticket.description = description
            ticket.is_active = is_active
            ticket.updated_by = user_id
            ticket.updated_on = timezone.now()

            ticket.save()

            return JsonResponse({'message': 'success'})
        except ticket_table.DoesNotExist:
            return JsonResponse({'message': 'error', 'error_message': 'Ticket not found'})
        except ValueError:
            return JsonResponse({'message': 'error', 'error_message': 'Invalid datetime format'})
    else:
        return JsonResponse({'message': 'error', 'error_message': 'Invalid request'})


# ```````````````````````````ATTACH FILE```````````````````````````

def attachment_file(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = ticket_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])

            
            


from PyPDF2 import PdfReader, PdfWriter
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import os

def attach_update(request):
    if request.method == "POST":
        req_id = request.POST.get('id')
        print('req_id', req_id)
        
        # Fetch the existing ticket
        brand = ticket_table.objects.get(id=req_id)
        print('brand', brand)

        # Form processing
        form = TicketForm(request.POST, request.FILES, instance=brand)
        if form.is_valid():
            user_id = request.session.get('user_id')
            new_file = request.FILES.get('file_name')
            print('new_file', new_file)

            # If there's an existing file, we need to append
            if brand.file_name:
                # Get the path to the existing PDF
                existing_file_path = brand.file_name.path
                
                # Create a PDF writer to combine PDFs
                pdf_writer = PdfWriter()

                # Read the existing PDF
                with open(existing_file_path, 'rb') as existing_file:
                    existing_pdf = PdfReader(existing_file)
                    # Append all pages from the existing PDF
                    for page in existing_pdf.pages:
                        pdf_writer.add_page(page)

                # Read the new PDF
                with new_file.open('rb') as new_pdf_file:
                    new_pdf = PdfReader(new_pdf_file)
                    # Append all pages from the new PDF
                    for page in new_pdf.pages:
                        pdf_writer.add_page(page)

                # Create a new file path
                new_file_path = os.path.join(default_storage.location, f'combined_{req_id}.pdf')
                
                # Write the combined PDF to a new file
                with open(new_file_path, 'wb') as combined_pdf_file:
                    pdf_writer.write(combined_pdf_file)

                # Save the new file reference in the database
                brand.file_name = f'combined_{req_id}.pdf'  # Update to the new file's path
            else:
                # If no existing file, just save the new one
                brand.file_name = new_file
            
            # Update the ticket details
            brand.updated_by = user_id
            brand.updated_on = timezone.now()
            form.save()  # Save the form instance

            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})



# `````````````````````````````````````````PRINT ```````````````````````````````````````````````````

def print_btn(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = ticket_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])


def print_page(request):
    if 'user_id' in request.session:
        user_id = request.session['user_id']
        return render(request, 'common/print.html')
    else:
        return HttpResponseRedirect("/signin")


# `````````````````````````````````````````TRANSFER TICKETS````````````````````````````````````````
def transfer_btn(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = ticket_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])


# def transfer_tickets(request):
#     if request.method == 'POST':
#         from_vendor = request.POST.get('from_vendor')
#         to_vendor = request.POST.get('to_vendor')
#         from_technician = request.POST.get('from_technician')
#         to_technician = request.POST.get('to_technician')
#         transfer_ids = request.POST.getlist('TransferId[]')  
        
#         if not transfer_ids or not to_id or not from_id:
#             return JsonResponse({'success': False, 'message': 'Missing some ids'}, status=400)

#         try:
#             from_technician = get_object_or_404(employee_table, id=from_technician)
#             to_technician = get_object_or_404(employee_table, id=to_technician)
#             from_vendor = get_object_or_404(vendor_table, id=from_vendor)
#             to_vendor = get_object_or_404(vendor_table, id=to_vendor)

#             # Ensure both technicians belong to the same vendor
#             if from_technician.vendor_id != to_technician.vendor_id:
#                 return JsonResponse({'success': False, 'message': 'Technicians must belong to the same vendor'}, status=400)

#             for transfer_id in transfer_ids:
#                 parent_ticket = get_object_or_404(ticket_table, id=transfer_id)
                
#                 if parent_ticket.ticket_status == 'Pending':
#                     ticket_table.objects.filter(id=transfer_id).update(technician_id=to_id)
#                 elif parent_ticket.ticket_status == 'Completed':
#                     return JsonResponse({'success': False, 'message': 'Completed tickets cannot be transferred'}, status=400)
#                 else:
#                     return JsonResponse({'success': False, 'message': 'Invalid ticket status for transfer'}, status=400)
            
#             return JsonResponse({'success': True, 'message': 'Tickets transferred successfully'}, status=200)
#         except ticket_table.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'One or more parent tickets not found'}, status=404)
#         except employee_table.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'Technician not found'}, status=404)
#         except Exception as e:
#             return JsonResponse({'success': False, 'message': str(e)}, status=500)
#     else:
#         return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=400)



from django.http import JsonResponse
from django.shortcuts import get_object_or_404

def transfer_tickets(request):
    if request.method == 'POST':
        from_vendor = request.POST.get('from_vendor')
        to_vendor = request.POST.get('to_vendor')
        from_technician = request.POST.get('from_technician')
        to_technician = request.POST.get('to_technician')
        transfer_ids = request.POST.getlist('TransferId[]')  
        
        # Assign to_vendor and to_technician if not provided
        if not to_vendor:
            to_vendor = from_vendor
        if not to_technician:
            to_technician = from_technician

        if not transfer_ids or not to_vendor or not from_vendor:
            return JsonResponse({'success': False, 'message': 'Missing some ids'}, status=400)

        try:
            from_technician = get_object_or_404(employee_table, id=from_technician)
            to_technician = get_object_or_404(employee_table, id=to_technician)
            from_vendor = get_object_or_404(vendor_table, id=from_vendor)
            to_vendor = get_object_or_404(vendor_table, id=to_vendor)

            # Ensure both technicians belong to the same vendor
           

            for transfer_id in transfer_ids:
                parent_ticket = get_object_or_404(ticket_table, id=transfer_id)
                
                if parent_ticket.ticket_status == 'pending':
                    ticket_table.objects.filter(id=transfer_id).update(technician_id=to_technician.id)
                elif parent_ticket.ticket_status == 'completed':
                    return JsonResponse({'success': False, 'message': 'Completed tickets cannot be transferred'}, status=400)
                else:
                    return JsonResponse({'success': False, 'message': 'Invalid ticket status for transfer'}, status=400)
            
            return JsonResponse({'success': True, 'message': 'Tickets transferred successfully'}, status=200)
        except ticket_table.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'One or more parent tickets not found'}, status=404)
        except employee_table.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Technician not found'}, status=404)
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)}, status=500)
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=400)


# ```````````````````````BULK UPLOAD``````````````````````````````````

# def bulk_upload_assets(request):
#     if request.method == 'POST' and request.FILES.get('excel_file'):
#         excel_file = request.FILES['excel_file']
#         customer = int(request.POST.get("vendor_id"))
#         user_id = request.session.get('user_id')
#         if not excel_file.name.endswith('.xlsx'):
#             return JsonResponse({'success': False, 'error': 'Please upload a file with .xlsx extension only.'})
        
#         try:
#             df = pd.read_excel(excel_file, header=1)
#             df.columns = df.columns.str.lower()
            
#             date_columns = [
#                 'commission date', 
#                 'warranty start date', 
#                 'warranty end date'
#             ]
#             for col in date_columns:
#                 if col in df.columns:
#                     df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%Y-%m-%d')

#             for index, row in df.iterrows():
#                 category_name = row['category']
#                 category = get_object_or_404(category_table, name=category_name)

#                 item_name = row['asset library code']
#                 items = get_object_or_404(system_table, name=item_name)

#                 item_id = None
#                 if not pd.isna(item_name):
#                     items = get_object_or_404(system_table, name=item_name)
#                     item_id = items.id


#                 project_name = row['project']
#                 project = get_object_or_404(project_table, name=project_name)


#                 technician_name = row['technician']
#                 technician = get_object_or_404(employee_table, name=technician_name)


#                 item_name = row['item name']
#                 if pd.isna(item_name):
#                     item_name = None

#                 quantity = row['quantity']
#                 if pd.isna(quantity):
#                     quantity = None

#                 location = row['location']
#                 if pd.isna(location):
#                     location = None

#                 frequency_names = row['frequency'].split(',')
#                 frequency_ids = []
#                 for frequency_name in frequency_names:
#                     frequency_name = frequency_name.strip()
#                     if frequency_name:
#                         frequency = get_object_or_404(frequency_table, name=frequency_name)
#                         frequency_ids.append(str(frequency.id))

#                 serial_number = row['serial number']
#                 if pd.isna(serial_number):
#                     serial_number = None

#                 estimate = row['estimate']
#                 if pd.isna(estimate):
#                     estimate = None

#                 brand_name = row['brand']
#                 brand = get_object_or_404(brand_table, name=brand_name)

#                 commission_date = row['commission date']
#                 if pd.isna(commission_date):
#                     commission_date = None

#                 warranty_start_date = row['warranty start date']
#                 if pd.isna(warranty_start_date):
#                     warranty_start_date = None

#                 warranty_end_date = row['warranty end date']
#                 if pd.isna(warranty_end_date):
#                     warranty_end_date = None

#                 status = row['status']
#                 if pd.isna(status):
#                     status = None

#                 vendor_id = get_object_or_404(vendor_table, id=customer)
#                 project_id = get_object_or_404(project_table, id=project.id)
#                 customer_prefix = vendor_id.customer_prefix
#                 project_prefix = project_id.prefix
#                 customer_id = project.customer_id

#                 num_series = generate_unique_asset_code(customer, project.id)
#                 ticket_no = f"{customer_prefix}-{project_prefix}-{num_series}"

#                 asset = asset_table(
#                     vendor_id=customer,
#                     customer_id=customer_id,
#                     num_series=num_series,
#                     asset_item_code=ticket_no,
#                     name=item_name,
#                     category_id=category.id,
#                     technician_id=technician.id,
#                     item_id=item_id,
#                     name=item_name,
#                     quantity=quantity,
#                     location=location,
#                     frequency_id=','.join(frequency_ids),
#                     serial_number=serial_number,
#                     estimated_life=estimate,
#                     brand_id=brand.id,
#                     project_id=project.id,
#                     commissioning_date=commission_date,
#                     warranty_start_date=warranty_start_date,
#                     warranty_end_date=warranty_end_date,
#                     created_by=user_id,
#                     updated_by=user_id,
#                     created_on=timezone.now(),
#                     updated_on=timezone.now()
#                 )
#                 asset.save()
#             return JsonResponse({'success': True})
#         except Exception as e:
#             return JsonResponse({'success': False, 'error': str(e)})
#     return JsonResponse({'success': False, 'error': 'No file provided'})


from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
import pandas as pd
import logging

# Configure logging
logger = logging.getLogger(__name__)

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
import pandas as pd
import logging

# Configure logging
logger = logging.getLogger(__name__)

def bulk_upload_assets(request):
    if request.method == 'POST' and request.FILES.get('excel_file'):
        excel_file = request.FILES['excel_file']
        customer = int(request.POST.get("vendor_id"))
        print('Customer ID:', customer)
        user_id = request.session.get('user_id')
        
        if not excel_file.name.endswith('.xlsx'):
            print('Invalid file extension:', excel_file.name)
            return JsonResponse({'success': False, 'error': 'Please upload a file with .xlsx extension only.'})
        
        try:
            df = pd.read_excel(excel_file, header=1)
            df.columns = df.columns.str.lower()
            print('DataFrame columns:', df.columns.tolist())

            # Date conversion
            date_columns = ['commission date', 'warranty start date', 'warranty end date']
            for col in date_columns:
                if col in df.columns:
                    df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%Y-%m-%d')
                    print(f'Converted dates in column: {col}')

            assets_to_create = []  # List to hold asset instances for bulk creation

            for index, row in df.iterrows():
                print(f'Processing row {index + 1}:', row.to_dict())  # Print the current row data
                try:
                    # Fetch necessary objects from the database
                    category_name = row['category']
                    print(f'Fetching category: {category_name}')
                    category = get_object_or_404(category_table, name=category_name)

                    item_name = row['asset library code']
                    print(f'Fetching item: {item_name}')
                    items = get_object_or_404(system_table, name=item_name) if item_name else None
                    print('items',items)
                    item_id = items.id if items else None

                    project_name = row['project']
                    print(f'Fetching project: {project_name}')
                    project = get_object_or_404(project_table, name=project_name)

                    technician_name = row['technician']
                    print(f'Fetching technician: {technician_name}')
                    technician = get_object_or_404(employee_table, name=technician_name)

                    frequency_names = row['frequency'].split(',') if 'frequency' in row else []
                    frequency_ids = []
                    for freq in frequency_names:
                        freq = freq.strip()
                        if freq:
                            print(f'Fetching frequency: {freq}')
                            try:
                                frequency = get_object_or_404(frequency_table, name=freq)
                                frequency_ids.append(str(frequency.id))  # Convert to string
                                print(f'Found frequency ID: {frequency.id}')
                            except Exception as e:
                                logger.warning(f"Frequency not found for '{freq}': {str(e)}")
                                frequency_ids.append('')  # Default or skip

                    brand_name = row['brand']
                    print(f'Fetching brand: {brand_name}')
                    try:
                        brand = get_object_or_404(brand_table, name=brand_name)
                        brand_id = brand.id
                        print(f'Found brand ID: {brand_id}')
                    except Exception as e:
                        logger.warning(f"Brand not found for '{brand_name}': {str(e)}")
                        brand_id = None  # Default value if not found

                    vendor_id = get_object_or_404(vendor_table, id=customer)
                    project_id = get_object_or_404(project_table, id=project.id)
                    customer_prefix = vendor_id.customer_prefix
                    project_prefix = project_id.prefix
                    customer_id = project.customer_id

                    num_series = generate_unique_asset_code(customer, project.id)
                    ticket_no = f"{customer_prefix}-{project_prefix}-{num_series}"
                    print(f'Generated ticket number: {ticket_no}')

                    # Prepare the asset instance
                    asset = asset_table(
                        vendor_id=customer,
                        customer_id=customer_id,
                        num_series=num_series,
                        asset_item_code=ticket_no,
                        name=row.get('item name'),
                        category_id=category.id,
                        technician_id=technician.id,
                        item_id=item_id,
                        asset_group_id=item_id ,
                        quantity=row.get('quantity'),
                        location=row.get('location'),
                        frequency_id=','.join(filter(None, frequency_ids)),  # Remove empty strings
                        serial_number=row.get('serial number'),
                        estimated_life=row.get('estimate'),
                        brand_id=brand_id,
                        project_id=project.id,
                        commissioning_date=row.get('commission date'),
                        warranty_start_date=row.get('warranty start date'),
                        warranty_end_date=row.get('warranty end date'),
                        created_by=user_id,
                        updated_by=user_id,
                        created_on=timezone.now(),
                        updated_on=timezone.now()
                    )

                    assets_to_create.append(asset)
                    # Print statement to debug the asset data
                    print(f'Final data for asset {index + 1}:', asset.__dict__)  # Print the asset's dictionary representation

                except Exception as e:
                    print(f"Error processing row {index + 1}: {str(e)}")  # Print error details
                    continue  # Skip to the next row if there's an error

            # Bulk create all assets after processing
            if assets_to_create:
                asset_table.objects.bulk_create(assets_to_create)
                print(f'Created {len(assets_to_create)} assets.')
            return JsonResponse({'success': True})

        except Exception as e:
            print(f"Error in bulk upload: {str(e)}")  # Print error details
            return JsonResponse({'success': False, 'error': str(e)})
    
    print('No file provided in request.')
    return JsonResponse({'success': False, 'error': 'No file provided'})




#````````````````````````````````````MOVE ASSET``````````````````````````````

def load_movelist(request):
    vendor_id = request.GET.get('vendor_id')
    projects = asset_table.objects.filter(vendor_id=vendor_id,asset_parent_id=0, status=1)
    project_list = [{'id': proj.id, 'name': proj.name ,'code':proj.asset_item_code} for proj in projects]
    return JsonResponse({'projects': project_list})

def load_movelist2(request):
    vendor_id = request.GET.get('vendor_id')
    projects = asset_table.objects.filter(vendor_id=vendor_id, status=1)
    project_list = [{'id': proj.id, 'name': proj.name ,'code':proj.asset_item_code} for proj in projects]
    return JsonResponse({'projects': project_list})

def move_assets(request):
    if request.method == 'POST':
        asset_ids = request.POST.getlist('asset_ids[]')
        parent_id = request.POST.get('parent_id')

        if not asset_ids or not parent_id:
            return JsonResponse({'success': False, 'message': 'Missing asset_ids or parent_id'}, status=400)

        try:
            parent_asset = get_object_or_404(asset_table, id=parent_id)  
            ##print("parent_asset found:", parent_asset)

            asset_table.objects.filter(id__in=asset_ids).update(asset_parent_id=parent_asset.id)
            #print("Assets updated successfully")

            return JsonResponse({'success': True, 'message': 'Assets moved successfully'}, status=200)
        except asset_table.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Parent asset not found'}, status=404)
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)}, status=500)
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=400)



# `````````````````````````````````````````COMPLAINTS```````````````````````````````````````````

def complaints(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'common/complaints.html')
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



def complaint_view(request):
    data = list(complaint_table.objects.filter(status=1).order_by('-id').values())
    formatted = [
        {
            'action': '<button type="button" onclick="complaint_show(\'{}\')" class="btn  btn-outline-primary btn-xs" ><i class="feather icon-eye"></button>'.format(item['id']), 
            # 'id': item['id'],
            'id':index + 1, 
            'asset': item['asset_id'], 
            'subject': item['subject'], 
            'details': item['remarks'], 
            'status': item['complaint_status']

            # 'status': '<span class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field
        } 
        for index,item in enumerate(data)
    ]
    
    return JsonResponse({'data': formatted})


def complaint_show(request):
    if 'user_id' in request.session:
        user_id = request.session['user_id']
        encoded_id = request.GET.get('id', None)
        if encoded_id:
            plan_id = request.GET.get('id')
            decoded_id = base64.b64decode(encoded_id).decode('utf-8')
            asset = complaint_table.objects.filter(id=decoded_id)
            #print(asset)
            return render(request, 'common/complaints_show.html', {'id': decoded_id,'asset':asset})
        else:
            return HttpResponse("ID parameter is missing")
    else:
        return HttpResponseRedirect("/signin")



#```````````````````````````````````````````ADD NEW TICKETS(SERVICE REQUEST)```````````````````````````````````````````````````

def service_request(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':            
            vendor = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            asset = asset_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            library = system_table.objects.filter(status=1)
            asset = asset_table.objects.filter(status=1)
            return render(request, 'request/service.html',{'vendor':vendor,'project':project,'asset':asset,'technician':technician,'frequency':frequency,'library':library,'asset':asset})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def fetch_details(request):
    vendor_id = request.GET.get('vendor_id')
    projects = project_table.objects.filter(vendor_id=vendor_id).values('id', 'name', 'project_code')
    assets = asset_table.objects.filter(vendor_id=vendor_id).values('id', 'name', 'asset_item_code')
    technician = employee_table.objects.filter(vendor_id=vendor_id).values('id','name','employee_code')
    print(technician)
    return JsonResponse({'projects': list(projects), 'assets': list(assets)})



def request_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            ticket_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except ticket_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})



#`````````````````````````````````SUMMARY TICKET`````````````````````````````````````````

def request_summary(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':            
            customer = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            asset2 = asset_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            
            # Render the template with the required data
            return render(request, 'common/tickets.html', {            
                'customer': customer,
                'project': project,
                'asset2': asset2,
                'category': category,
                'frequency': frequency,
            })
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


#``````````````````````````````````CMT TICKETS (NEW TICKETS)``````````````````````````````````````````

def pre_schedule(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            return render(request, 'request/schedule.html',{'customer':customer,'project':project,'category':category,'frequency':frequency})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


import base64


def assets_manager(request, encoded_vendor_id=None, encoded_project_id=None, encoded_asset_id=None):
    # Initialize IDs as None
    vendor_id = None
    project_id = None
    asset_id = None

    # Decode the IDs if they are provided
    if encoded_vendor_id:
        try:
            vendor_id = base64.b64decode(encoded_vendor_id).decode('utf-8')
        except Exception as e:
            print(f"Error decoding customer ID: {e}")
    
    if encoded_project_id:
        try:
            project_id = base64.b64decode(encoded_project_id).decode('utf-8')
        except Exception as e:
            print(f"Error decoding project ID: {e}")

    if encoded_asset_id:
        try:
            asset_id = base64.b64decode(encoded_asset_id).decode('utf-8')
        except Exception as e:
            print(f"Error decoding asset ID: {e}")

    # Fetch the data
    vendor = vendor_table.objects.filter(status=1)
    project = project_table.objects.filter(status=1)
    asset = category_table.objects.filter(status=1)
    system = system_table.objects.filter(status=1)
    frequency = frequency_table.objects.filter(status=1)
    brand = brand_table.objects.filter(status=1)
    category = category_table.objects.filter(status=1)
    technician = employee_table.objects.filter(status=1)
    frequency = frequency_table.objects.filter(status=1)

    return render(request, 'common/asset_add.html', {
        'vendor_id': vendor_id,
        'project_id': project_id,
        'asset_id': asset_id,
        'vendor': vendor,
        'project': project,
        'asset': asset,
        'system':system,
        'frequency':frequency,
        'brand':brand,
        'category':category,
        'technician':technician,
        'frequency':frequency

    })

# def schedule_view(request):
#     vendor_id = request.POST.get('vendor')
#     project_id = request.POST.get('project')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     customer_id = request.POST.get('customer')

#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     query = Q(status=1, asset_parent_id=0) 

#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)

#     if vendor_id and vendor_id.isdigit():
#         query &= Q(vendor_id=vendor_id)

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)

#     if system_id and system_id.isdigit():
#         query &= Q(asset_group_id=system_id)

#     assets = asset_table.objects.filter(query,asset_parent_id=0).order_by('-id')

#     category_map = {cat.id: cat.name for cat in category_table.objects.all()}
#     brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
#     project_map = {proj.id: proj.name for proj in project_table.objects.all()}
#     system_map = {sys.id: sys.name for sys in system_table.objects.all()}
#     technician_map = {sys.id: sys.name for sys in employee_table.objects.exclude(tec_reference_id=0)}

#     total_asset_count = assets.count()
#     print('total_asset_count',total_asset_count)

#     data = []
#     index = 1  
#     for item in assets:

#         frequency_names = []
#         frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

#         for freq_id in frequency_ids:
#             if freq_id.isdigit():
#                 try:
#                     freq_name = frequency_table.objects.get(id=int(freq_id)).name
#                     frequency_names.append(freq_name)
#                 except frequency_table.DoesNotExist:
#                     print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

#         frequency_str = ', '.join(frequency_names)

#         completed_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, ticket_status="Completed", status=1).count()
#         total_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, status=1).count()


#         formatted_item = {
#             'empty': '',
#             # 'id': index,  # Use the manual index
#             'id': item.id,  # Use the manual index
#             'action': '<div class="btn-group" role="group" aria-label="Action buttons">' + \
#                       '<button type="button" onclick="asset_edit(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-edit"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id) + \
#                       '<button type="button" onclick="generate_qar(\'{}\')" class="btn btn-outline-success btn-xs"><i class="feather icon-printer"></i></button>'.format(item.id) + \
#                       '</div>',
#             'category': category_map.get(item.category_id, '-'),
#             'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
#             'qr': item.asset_item_code if item.asset_item_code else '-',
#             'code': system_map.get(item.asset_group_id, '-'),
#             'project': project_map.get(item.project_id, '-'),
#             'technician': technician_map.get(item.technician_id, '-'),
#             # 'technician': item.technician_id if item.technician_id else '-',
#             'name': item.name if item.name else '-',
#             'qty': item.quantity if item.quantity else '-',
#             'location': item.location if item.location else '-',
#             'frequency': frequency_str,
#             'frequency_split': ,
#             'serial': item.serial_number if item.serial_number else '-',
#             'estimate': item.estimated_life if item.estimated_life else '-',
#             'brand': brand_map.get(item.brand_id, '-'),
#             'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
#             'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
#             'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
#             'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
#         }

#         data.append(formatted_item)
    

#         index += 1  # Increment index manually

   
#     return JsonResponse({'data': data, 'total_asset_count': total_asset_count})

from django.db.models import Q

def schedule_view(request):
    vendor_id = request.POST.get('vendor')
    project_id = request.POST.get('project')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    customer_id = request.POST.get('customer')

    if customer_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    if project_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    query = Q(status=1, asset_parent_id=0) 

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)

    if vendor_id and vendor_id.isdigit():
        query &= Q(vendor_id=vendor_id)

    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)

    if system_id and system_id.isdigit():
        query &= Q(asset_group_id=system_id)

    assets = asset_table.objects.filter(query, asset_parent_id=0).order_by('-id')

    # Mapping tables
    category_map = {cat.id: cat.name for cat in category_table.objects.all()}
    brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}
    project_map = {proj.id: proj.name for proj in project_table.objects.all()}
    system_map = {sys.id: sys.name for sys in system_table.objects.all()}
    technician_map = {tech.id: tech.name for tech in employee_table.objects.exclude(tec_reference_id=0)}

    total_asset_count = assets.count()
    print('total_asset_count', total_asset_count)

    data = []
    index = 1
    for item in assets:
        frequency_names = []
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

        frequency_split_data = []
        
        # Calculate pending tickets for each frequency ID
        for freq_id in frequency_ids:
            if freq_id.isdigit():
                try:
                    frequency = frequency_table.objects.get(id=int(freq_id))
                    freq_name = frequency.name
                    frequency_names.append(freq_name)

                    # Filter for pending tickets based on frequency ID and other criteria
                    pending_tickets_count = ticket_table.objects.filter(
                        Q(asset_item_id=item.id),
                        Q(frequency_id=int(freq_id)),
                        Q(ticket_status="pending"),
                        Q(customer_id=item.customer_id),
                        Q(project_id=item.project_id),
                        Q(vendor_id=item.vendor_id),
                        Q(system_id=item.asset_group_id),
                        status=1  # Ensure ticket is active
                    ).count()

                    # frequency_split_data.append(f"{freq_name}: {pending_tickets_count} <br>")
                    frequency_split_data.append(
                        f"{freq_name}-->: <span class='badge text-bg-warning'>{pending_tickets_count}</span> <br>"
                    )

                except frequency_table.DoesNotExist:
                    print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

        frequency_str = ','.join(frequency_names)
        frequency_split_str = ''.join(frequency_split_data)

        completed_ticket_count = ticket_table.objects.filter(
            asset_item_id=item.id, ticket_status="pending", status=1
        ).count()
        total_ticket_count = ticket_table.objects.filter(asset_item_id=item.id, status=1, ticket_status="completed").count()
        frequency_badge_str = ', '.join(
            f'<span class="badge text-bg-success" style="font-size:9pt;">{name}</span><br>' for name in frequency_names
        )

        formatted_item = {
            # 'empty': '',
            # 'id': item.id,
            'action': '<button type="button" onclick="generate_schedule(\'{}\')" class="btn btn-outline-secondary btn-xs"><i class="feather icon-calendar"></i></button>'.format(item.id),      
            'category': category_map.get(item.category_id, '-'),
            'service': '<button type="button" onclick="ticket_page(\'{}\')" class="btn btn-outline-info btn-xs">Appointments ({}/{})</button>'.format(item.id, completed_ticket_count, total_ticket_count),
            'qr': item.asset_item_code if item.asset_item_code else '-',
            'code': system_map.get(item.asset_group_id, '-'),
            'project': project_map.get(item.project_id, '-'),
            'technician': technician_map.get(item.technician_id, '-'),
            'name': item.name if item.name else '-',
            'qty': item.quantity if item.quantity else '-',
            'location': item.location if item.location else '-',
            'frequency': frequency_badge_str,
            'frequency_split': frequency_split_str,
            'serial': item.serial_number if item.serial_number else '-',
            'estimate': item.estimated_life if item.estimated_life else '-',
            'brand': brand_map.get(item.brand_id, '-'),
            'commission': item.commissioning_date.strftime('%d-%m-%Y') if item.commissioning_date else '-',
            'start': item.warranty_start_date.strftime('%d-%m-%Y') if item.warranty_start_date else '-',
            'end': item.warranty_end_date.strftime('%d-%m-%Y') if item.warranty_end_date else '-',
            'status': '<span class="badge text-bg-success">Active</span>' if item.is_active else '<span class="badge text-bg-danger">Inactive</span>'
        }

        data.append(formatted_item)
        index += 1  # Increment index manually

    return JsonResponse({'data': data, 'total_asset_count': total_asset_count})


#````````````````````````````````MONTHLY SUMMARY``````````````````````````````````````````

def monthwise_summary(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            return render(request, 'report/monthly_report.html',{'customer':customer,'category':category})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



from django.http import JsonResponse
from django.db.models import Q
from datetime import datetime
import calendar

# def month_wise_report(request):
#     year = request.POST.get('year')
#     customer_id = request.POST.get('customer')
#     project_id = request.POST.get('project')
#     vendor_id = request.POST.get('vendor')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     status_id = request.POST.get('status')

#     # Set default year to current if not provided
#     if not year:
#         year = datetime.now().year 

#     # Build the base query
#     query = Q(status=1) 

#     # Validate inputs
#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     # Append filters to query
#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)

#     if status_id:
#         query &= Q(ticket_status=status_id)

#     if system_id:
#         query &= Q(ticket_type=system_id)


    
    

#     # Prepare the response data
#     formatted_data = [
#         {
#             'category_id': ,
#             'ticket_type': ,
#             'ticket_status': ,
#             'JAN': ,
#             'FEB': ,
#             'MAR': ,
#             'APR': ,
#             'MAY': ,
#             'JUN': ,
#             'JUL': ,
#             'AUG': ,
#             'SEP': ,
#             'OCT': ,
#             'NOV': ,
#             'DEC': ,
#         }
#         for row in rows
#     ]

#     return JsonResponse({'data': formatted_data})

from django.db.models import Q, Count
from django.http import JsonResponse
from datetime import datetime

from django.db.models import Q, Count
from datetime import datetime
from django.http import JsonResponse
from .models import ticket_table  # Adjust the import according to your project structure

from django.http import JsonResponse
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404
from datetime import datetime

def month_wise_report(request):
    year = request.POST.get('year')
    customer_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    status_id = request.POST.get('status')

    # Set default year to current if not provided
    if not year:
        year = datetime.now().year 

    # Build the base query
    query = Q(status=1)  # Active status, adjust as necessary

    if customer_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    if project_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    # Append filters to query
    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)

    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)

    if status_id:
        query &= Q(ticket_status=status_id)

    if system_id:
        query &= Q(ticket_type=system_id)

    # Query tickets for the specific year
    rows = (
        ticket_table.objects.filter(query, ticket_date__year=year)
        .values('system_id', 'ticket_status', 'ticket_type')  # Group by these fields
        .annotate(
            jan=Count('id', filter=Q(ticket_date__month=1)),
            feb=Count('id', filter=Q(ticket_date__month=2)),
            mar=Count('id', filter=Q(ticket_date__month=3)),
            apr=Count('id', filter=Q(ticket_date__month=4)),
            may=Count('id', filter=Q(ticket_date__month=5)),
            jun=Count('id', filter=Q(ticket_date__month=6)),
            jul=Count('id', filter=Q(ticket_date__month=7)),
            aug=Count('id', filter=Q(ticket_date__month=8)),
            sep=Count('id', filter=Q(ticket_date__month=9)),
            oct=Count('id', filter=Q(ticket_date__month=10)),
            nov=Count('id', filter=Q(ticket_date__month=11)),
            dec=Count('id', filter=Q(ticket_date__month=12)),
        )
    )

    # Prepare the response data with incremental IDs
    formatted_data = [
        {
            'id': index + 1,  
            'category': getCodeNameById(system_table, row['system_id']),
            'type': row['ticket_type'],
            'status': row['ticket_status'],
            'jan': row['jan'],
            'feb': row['feb'],
            'mar': row['mar'],
            'apr': row['apr'],
            'may': row['may'],
            'jun': row['jun'],
            'jul': row['jul'],
            'aug': row['aug'],
            'sep': row['sep'],
            'oct': row['oct'],
            'nov': row['nov'],
            'dec': row['dec'],
        }
        for index, row in enumerate(rows)  # Use enumerate to get both index and row
    ]

    return JsonResponse({'data': formatted_data})


def prepare_chart_data(formatted_data):
    projects_data = {}
    categories_data = {}
    priorities_data = {}

    for entry in formatted_data:
        project_id = entry['type']
        if project_id not in projects_data:
            projects_data[project_id] = {'jan': 0, 'feb': 0, 'mar': 0, 'apr': 0, 'may': 0, 'jun': 0,
                                          'jul': 0, 'aug': 0, 'sep': 0, 'oct': 0, 'nov': 0, 'dec': 0}
        for month in ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']:
            projects_data[project_id][month] += entry[month]

        # Process data for "By Category" chart
        category_name = entry['category']
        if category_name not in categories_data:
            categories_data[category_name] = 0
        categories_data[category_name] += entry['jan'] + entry['feb'] + entry['mar'] + \
                                             entry['apr'] + entry['may'] + entry['jun'] + \
                                             entry['jul'] + entry['aug'] + entry['sep'] + \
                                             entry['oct'] + entry['nov'] + entry['dec']

        # Process data for "By Priority" chart
        priority_status = entry['status']
        if priority_status not in priorities_data:
            priorities_data[priority_status] = 0
        priorities_data[priority_status] += 1  # Count total entries per priority

    return projects_data, categories_data, priorities_data



def getCodeNameById(tbl, cat_id):
    try:
        category = tbl.objects.get(id=cat_id).parent_code
    except tbl.DoesNotExist:
        return '-'  # or return a default value, e.g., "Unknown"
    
    return category

#````````````````````````````````TICKET SUMMARY```````````````````````````````````````````
def ticket_summary(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'report/ticket.html')
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")

#````````````````````````````````OUTSTANDING SUMMARY```````````````````````````````````````````
def outstanding_summary(request):
    if 'user_id' in request.session: 
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            return render(request, 'report/outstanding.html',{'customer':customer,'frequency':frequency})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



from django.http import JsonResponse
from django.db.models import Q

def outstanding_report_summary(request):
    customer_id = request.POST.get('customer')
    frequency_id = request.POST.get('frequency')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    ticket_type = request.POST.get('request')
    from_date = request.POST.get('from_date')
    to_date = request.POST.get('to_date')
    logged_user_id = request.session.get('user_id') 

    print('logged_user_id', logged_user_id)

    if customer_id in [None, '0', 'Select', '']:
        print("No customer selected.")
        return JsonResponse({'data': []})

    if project_id in [None, '0', 'Select', '']:
        print("No project selected.")
        return JsonResponse({'data': []})

    query = Q(status=1)

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
        print(f"Filtering by customer_id: {customer_id}")

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
        print(f"Filtering by project_id: {project_id}")

    if vendor_id and vendor_id.isdigit():
        query &= Q(vendor_id=vendor_id)
        print(f"Filtering by vendor_id: {vendor_id}")    

    if ticket_type:  # Ensure ticket_type is checked
        query &= Q(ticket_type=ticket_type)

    if frequency_id and frequency_id.isdigit():  #
        query &= Q(frequency_id=frequency_id)

    if from_date and to_date:
        query &= Q(ticket_date__range=[from_date, to_date])
        print(f"Filtering by date range: {from_date} to {to_date}")

    assets = ticket_table.objects.filter(query,ticket_status='pending').order_by('-id')
    asset_name_map = {asset.id: asset.asset_item_code for asset in asset_table.objects.all()}

    data = []
    
    for index, item in enumerate(assets):           
        formatted_item = {
             'id': index + 1, 
            'priority': item.ticket_type, 
            'customer': getItemNameById(customer_table, item.customer_id),
            'project': getItemNameById(project_table, item.project_id),
            'vendor': getItemNameById(vendor_table, item.vendor_id),
            'code': getItemNameById(system_table, item.system_id) or '-', 
            'asset': asset_name_map.get(item.asset_item_id, '-'), 
            'technician': getItemNameById(employee_table, item.technician_id) if item.technician_id else '-',
            'frequency': getItemNameById(frequency_table, item.frequency_id) if item.technician_id else '-',
            'reqno': item.ticket_no, 
            'reqdate': item.ticket_date,  
           'status': f'<span class="badge text-bg-{get_status_colors(item.ticket_status)}">{item.ticket_status}</span>',
        }

        data.append(formatted_item)

    final_data_count = len(data) 
    print('Final data count:', final_data_count)  

    return JsonResponse({'data': data, 'total_asset_count': final_data_count})  # Fixed to return final data count

def get_status_colors(status):
    status = status.lower()
    if status == 'pending':
        return 'danger'
    elif status == 'open':
        return 'info'
    elif status == 'hold':
        return 'secondary'
    elif status == 'partial':
        return 'primary'
    elif status == 'completed':
        return 'success'
    elif status == 'cancelled':
        return 'danger'
    else:
        return 'secondary'

#````````````````````````````````COMPLETED SUMMARY````````````````````````````````````````````
def completed_summary(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            frequency = frequency_table.objects.filter(status=1)
            return render(request, 'report/completed_report.html',{'customer':customer,'frequency':frequency})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



def completed_report_summary(request):
    customer_id = request.POST.get('customer')
    frequency_id = request.POST.get('frequency')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    ticket_type = request.POST.get('request')
    from_date = request.POST.get('from_date')
    to_date = request.POST.get('to_date')
    logged_user_id = request.session.get('user_id') 

    print('logged_user_id', logged_user_id)

    if customer_id in [None, '0', 'Select', '']:
        print("No customer selected.")
        return JsonResponse({'data': []})

    if project_id in [None, '0', 'Select', '']:
        print("No project selected.")
        return JsonResponse({'data': []})

    query = Q(status=1)

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
        print(f"Filtering by customer_id: {customer_id}")

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
        print(f"Filtering by project_id: {project_id}")

    if vendor_id and vendor_id.isdigit():
        query &= Q(vendor_id=vendor_id)
        print(f"Filtering by vendor_id: {vendor_id}")

    if frequency_id and frequency_id.isdigit():
        query &= Q(frequency_id=frequency_id)

    if ticket_type:  # Ensure ticket_type is checked
        query &= Q(ticket_type=ticket_type)

    if from_date and to_date:
        query &= Q(ticket_date__range=[from_date, to_date])
        print(f"Filtering by date range: {from_date} to {to_date}")

    assets = ticket_table.objects.filter(query,ticket_status='completed').order_by('-id')
    asset_name_map = {asset.id: asset.asset_item_code for asset in asset_table.objects.all()}

    data = []
    
    for index, item in enumerate(assets):           
        formatted_item = {
             'id': index + 1, 
            'priority': item.ticket_type, 
            'customer': getItemNameById(customer_table, item.customer_id),
            'project': getItemNameById(project_table, item.project_id),
            'vendor': getItemNameById(vendor_table, item.vendor_id),
            'code': getItemNameById(system_table, item.system_id) or '-', 
            'asset': asset_name_map.get(item.asset_item_id, '-'), 
            'technician': getItemNameById(employee_table, item.technician_id) if item.technician_id else '-',
            'frequency': getItemNameById(frequency_table, item.frequency_id) if item.technician_id else '-',
            'reqno': item.ticket_no, 
            'reqdate': item.ticket_date,  
           'status': f'<span class="badge text-bg-{get_status_colors(item.ticket_status)}">{item.ticket_status}</span>',
        }

        data.append(formatted_item)

    final_data_count = len(data) 
    print('Final data count:', final_data_count)  

    return JsonResponse({'data': data, 'total_asset_count': final_data_count})  # Fixed to return final data count



#```````````````````````````````WORK REPORT```````````````````````````````````````````
def work_report(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            category = category_table.objects.filter(status=1)
            return render(request, 'report/work_report.html',{'customer':customer,'category':category})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")

from django.db.models import Sum

# def work_hour_report(request):
#     year = request.POST.get('year')
#     customer_id = request.POST.get('customer')
#     project_id = request.POST.get('project')
#     vendor_id = request.POST.get('vendor')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     status_id = request.POST.get('status')

#     # Set default year to current if not provided
#     if not year:
#         year = datetime.now().year 

#     # Build the base query
#     query = Q(status=1)  # Active status, adjust as necessary

#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     # Append filters to query
#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)

#     if status_id:
#         query &= Q(ticket_status=status_id)

#     if system_id:
#         query &= Q(ticket_type=system_id)

#     # Query tickets for the specific year and sum the total hours
#     rows = (
#         ticket_table.objects.filter(query, ticket_date__year=year)
#         .values('system_id', 'ticket_status', 'ticket_type')  # Group by these fields
#         .annotate(
#             jan=Sum('total_hrs', filter=Q(ticket_date__month=1)),
#             feb=Sum('total_hrs', filter=Q(ticket_date__month=2)),
#             mar=Sum('total_hrs', filter=Q(ticket_date__month=3)),
#             apr=Sum('total_hrs', filter=Q(ticket_date__month=4)),
#             may=Sum('total_hrs', filter=Q(ticket_date__month=5)),
#             jun=Sum('total_hrs', filter=Q(ticket_date__month=6)),
#             jul=Sum('total_hrs', filter=Q(ticket_date__month=7)),
#             aug=Sum('total_hrs', filter=Q(ticket_date__month=8)),
#             sep=Sum('total_hrs', filter=Q(ticket_date__month=9)),
#             oct=Sum('total_hrs', filter=Q(ticket_date__month=10)),
#             nov=Sum('total_hrs', filter=Q(ticket_date__month=11)),
#             dec=Sum('total_hrs', filter=Q(ticket_date__month=12)),
#         )
#     )

#     # Prepare the response data with incremental IDs
#     formatted_data = [
#         {
#             'id': index + 1,  
#             'category': getCodeNameById(system_table, row['system_id']),
#             'type': row['ticket_type'],
#             'status': row['ticket_status'],
#             'jan': row['jan'] if row['jan'] is not None else '00:00',  # Ensure no None values
#             'feb': row['feb'] if row['feb'] is not None else '00:00',
#             'mar': row['mar'] if row['mar'] is not None else '00:00',
#             'apr': row['apr'] if row['apr'] is not None else '00:00',
#             'may': row['may'] if row['may'] is not None else '00:00',
#             'jun': row['jun'] if row['jun'] is not None else '00:00',
#             'jul': row['jul'] if row['jul'] is not None else '00:00',
#             'aug': row['aug'] if row['aug'] is not None else '00:00',
#             'sep': row['sep'] if row['sep'] is not None else '00:00',
#             'oct': row['oct'] if row['oct'] is not None else '00:00',
#             'nov': row['nov'] if row['nov'] is not None else '00:00',
#             'dec': row['dec'] if row['dec'] is not None else '00:00',
#         }
#         for index, row in enumerate(rows)  # Use enumerate to get both index and row
#     ]

#     return JsonResponse({'data': formatted_data})

from django.db.models import Sum, Q
from django.http import JsonResponse
from datetime import datetime

from django.db.models import Sum, Q
from django.http import JsonResponse
from datetime import datetime

def work_hour_report(request):
    year = request.POST.get('year')
    customer_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    status_id = request.POST.get('status')

    # Set default year to current if not provided
    if not year:
        year = datetime.now().year 

    print(f"Year: {year}")  # Debug: check the year being used

    # Build the base query
    query = Q(status=1)  # Active status, adjust as necessary

    # Validate input parameters
    if customer_id in [None, '0', 'Select', ''] or project_id in [None, '0', 'Select', '']:
        print("Invalid customer or project ID.")  # Debug: invalid input
        return JsonResponse({'data': []})

    # Append filters to query
    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)
    if status_id:
        query &= Q(ticket_status=status_id)
    if system_id:
        query &= Q(ticket_type=system_id)

    print(f"Query: {query}")  # Debug: print the final query

    # Query tickets for the specific year and sum the total hours
    rows = (
        ticket_table.objects.filter(query, ticket_date__year=year)
        .values('system_id', 'ticket_status', 'ticket_type')  # Group by these fields
        .annotate(
            jan=Sum('total_hrs', filter=Q(ticket_date__month=1)),
            feb=Sum('total_hrs', filter=Q(ticket_date__month=2)),
            mar=Sum('total_hrs', filter=Q(ticket_date__month=3)),
            apr=Sum('total_hrs', filter=Q(ticket_date__month=4)),
            may=Sum('total_hrs', filter=Q(ticket_date__month=5)),
            jun=Sum('total_hrs', filter=Q(ticket_date__month=6)),
            jul=Sum('total_hrs', filter=Q(ticket_date__month=7)),
            aug=Sum('total_hrs', filter=Q(ticket_date__month=8)),
            sep=Sum('total_hrs', filter=Q(ticket_date__month=9)),
            oct=Sum('total_hrs', filter=Q(ticket_date__month=10)),
            nov=Sum('total_hrs', filter=Q(ticket_date__month=11)),
            dec=Sum('total_hrs', filter=Q(ticket_date__month=12)),
        )
    )

    print(f"Rows: {list(rows)}")  # Debug: print the raw rows fetched from the database

    # Prepare the response data with incremental IDs
    formatted_data = []
    for index, row in enumerate(rows):  # Use enumerate to get both index and row
        jan_hours = format_hours(row['jan'])
        feb_hours = format_hours(row['feb'])
        mar_hours = format_hours(row['mar'])
        apr_hours = format_hours(row['apr'])
        may_hours = format_hours(row['may'])
        jun_hours = format_hours(row['jun'])
        jul_hours = format_hours(row['jul'])
        aug_hours = format_hours(row['aug'])
        sep_hours = format_hours(row['sep'])
        oct_hours = format_hours(row['oct'])
        nov_hours = format_hours(row['nov'])
        dec_hours = format_hours(row['dec'])

        print(f"Formatted Hours for Row {index + 1}: Jan: {jan_hours}, Feb: {feb_hours}, Mar: {mar_hours}, Apr: {apr_hours}, May: {may_hours}, Jun: {jun_hours}, Jul: {jul_hours}, Aug: {aug_hours}, Sep: {sep_hours}, Oct: {oct_hours}, Nov: {nov_hours}, Dec: {dec_hours}")  # Debug: print formatted hours

        formatted_data.append({
            'id': index + 1,
            'category': getCodeNameById(system_table, row['system_id']),
            'type': row['ticket_type'],
            'status': row['ticket_status'],
            'jan': jan_hours,
            'feb': feb_hours,
            'mar': mar_hours,
            'apr': apr_hours,
            'may': may_hours,
            'jun': jun_hours,
            'jul': jul_hours,
            'aug': aug_hours,
            'sep': sep_hours,
            'oct': oct_hours,
            'nov': nov_hours,
            'dec': dec_hours,
        })

    return JsonResponse({'data': formatted_data})

def format_hours(total_hours):
    """
    Convert total_hours to a formatted string 'HH:MM'.
    If total_hours is None or not a valid number, return '00:00'.
    """
    if total_hours is None:
        return '00:00'
    
    try:
        # Assuming total_hours is an integer or can be converted to float
        total_hours = float(total_hours)
        hours = int(total_hours)
        minutes = int((total_hours - hours) * 60)  # Convert remaining fraction to minutes
        return f"{hours:02}:{minutes:02}"
    except (ValueError, TypeError):
        return '00:00'


#``````````````````````````````KPI REPORT``````````````````````````````````````````


def kpi_report(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            return render(request, 'report/kpi_report.html')
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


# `````````````````````````CALENDAR ```````````````````````````````````````


def work_calendar(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1).exclude(vendor_id=0).order_by('-id')
            return render(request, 'calendar.html',{'technician':technician,'customer':customer})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")



def load_technician(request):
    if request.method == 'GET':
        staff_id = request.GET.getlist('technician_id[]')  
        staff_data = employee_table.objects.filter(id__in=staff_id).values('id', 'name')  
        
        return JsonResponse(list(staff_data), safe=False)  
    
    return JsonResponse({'error': 'Invalid request method.'}, status=405)

# def load_schedule(request):
#     if request.method == 'GET':
#         staff_ids = request.GET.getlist('technician_id[]') 
#         from_date = request.GET.get('from_date')
#         to_date = request.GET.get('to_date')
        
#         # Filter schedules for multiple staff within the date range
#         schedule_data = ticket_table.objects.filter(
#             technician_id__in=staff_ids, 
#             ticket_date__range=[from_date, to_date]
#         )
#         schedule_list = []

#         for schedule in schedule_data:
#             trainer_name = employee_table.objects.get(id=schedule.technician_id).name
#             background = employee_table.objects.get(id=schedule.technician_id).color
#             batch_name = asset_table.objects.get(id=schedule.asset_item_id).name
#             schedule_dict = {
#                 'id': schedule.id,
#                 'batch': batch_name,
#                 'log_date': schedule.ticket_date.strftime('%Y-%m-%d'),
#                 'trainer_name': trainer_name,
#                 'color': background,
#                 'technician_id': schedule.technician_id
#             }
#             schedule_list.append(schedule_dict)

#         return JsonResponse(schedule_list, safe=False)
    
#     return JsonResponse({'error': 'Invalid request method.'}, status=405)

from django.http import JsonResponse
from .models import ticket_table, employee_table, asset_table

from django.http import JsonResponse
from .models import ticket_table, employee_table, asset_table, system_table, frequency_table

import random

def generate_random_color():
    """Generate a random color in hexadecimal format."""
    return "#{:06x}".format(random.randint(0, 0xFFFFFF))

# def load_schedule(request):
#     if request.method == 'GET':
#         customer_id = request.GET.get('customer_id')
#         project_id = request.GET.get('project_id')
#         vendor_id = request.GET.get('vendor_id')
#         from_date = request.GET.get('from_date')
#         to_date = request.GET.get('to_date')

#         # Validate customer_id and project_id
#         if customer_id in [None, '0', 'Select', '']:
#             return JsonResponse({'data': []})  

#         if project_id in [None, '0', 'Select', '']:
#             return JsonResponse({'data': []}) 

#         # Filter schedules based on the provided date range
#         schedule_data = ticket_table.objects.filter(
#             ticket_date__range=[from_date, to_date]
#         )

#         # Apply additional filters if provided
#         if customer_id:
#             schedule_data = schedule_data.filter(customer_id=customer_id)
#         if project_id:
#             schedule_data = schedule_data.filter(project_id=project_id)
#         if vendor_id:
#             schedule_data = schedule_data.filter(vendor_id=vendor_id)

#         # Dictionary to keep track of asset groups and their colors
#         asset_group_colors = {}

#         schedule_list = []

#         for schedule in schedule_data:
#             # Handle potential missing objects gracefully
#             try:
#                 asset_group = system_table.objects.get(id=schedule.system_id).name
#             except system_table.DoesNotExist:
#                 asset_group = '-'
            
#             try:
#                 frequency = frequency_table.objects.get(id=schedule.frequency_id).name
#             except frequency_table.DoesNotExist:
#                 frequency = '-'
            
#             technician_id = schedule.technician_id
#             try:
#                 background = employee_table.objects.get(id=technician_id).color
#             except employee_table.DoesNotExist:
#                 background = '#FFFFFF'  # Default color if technician not found

#             # Generate a random color for the asset group if it doesn't exist in the dictionary
#             if asset_group not in asset_group_colors:
#                 asset_group_colors[asset_group] = generate_random_color()

#             # Get the color for the asset group
#             asset_group_color = asset_group_colors[asset_group]

#             schedule_dict = {
#                 'id': schedule.id,
#                 'asset_group': asset_group,
#                 'frequency': frequency,
#                 'log_date': schedule.ticket_date.strftime('%Y-%m-%d'),  # Format the log_date
#                 'technician_id': technician_id,
#                 'color': asset_group_color,  # Use the asset group color
#             }
#             schedule_list.append(schedule_dict)

#         return JsonResponse(schedule_list, safe=False)

#     return JsonResponse({'error': 'Invalid request method.'}, status=405)
def load_schedule(request):
    if request.method == 'GET':
        customer_id = request.GET.get('customer_id')
        project_id = request.GET.get('project_id')
        vendor_id = request.GET.get('vendor_id')
        from_date = request.GET.get('from_date')
        to_date = request.GET.get('to_date')

        # Validate customer_id and project_id
        if customer_id in [None, '0', 'Select', '']:
            return JsonResponse({'data': []})  

        if project_id in [None, '0', 'Select', '']:
            return JsonResponse({'data': []}) 

        # Filter schedules based on the provided date range
        schedule_data = ticket_table.objects.filter(
            ticket_date__range=[from_date, to_date]
        )

        # Apply additional filters if provided
        if customer_id:
            schedule_data = schedule_data.filter(customer_id=customer_id)
        if project_id:
            schedule_data = schedule_data.filter(project_id=project_id)
        if vendor_id:
            schedule_data = schedule_data.filter(vendor_id=vendor_id)

        schedule_list = []

        for schedule in schedule_data:
            # Handle potential missing objects gracefully
            try:
                asset_group = system_table.objects.get(id=schedule.system_id).name
            except system_table.DoesNotExist:
                asset_group = '-'
            
            try:
                frequency_obj = frequency_table.objects.get(id=schedule.frequency_id)
                frequency = frequency_obj.name
                asset_group_color = frequency_obj.color  # Retrieve the color from frequency table
            except frequency_table.DoesNotExist:
                frequency = '-'
                asset_group_color = '#FFFFFF'  # Default color if frequency not found
            
            technician_id = schedule.technician_id
            try:
                background = employee_table.objects.get(id=technician_id).color
            except employee_table.DoesNotExist:
                background = '#FFFFFF'  # Default color if technician not found

            schedule_dict = {
                'id': schedule.id,
                'asset_group': asset_group,
                'frequency': frequency,
                'log_date': schedule.ticket_date.strftime('%Y-%m-%d'),  # Format the log_date
                'technician_id': technician_id,
                'color': asset_group_color,
                'text_color': '#333333'
            }
            schedule_list.append(schedule_dict)

        return JsonResponse(schedule_list, safe=False)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)




@csrf_exempt  # Use this only if you're not using CSRF tokens; otherwise, ensure CSRF token is sent correctly
def update_ticket_date(request):
    if request.method == 'POST':
        event_id = request.POST.get('id')
        new_date = request.POST.get('ticket_date')
        print('event_id',event_id)
        print('new_date',new_date)

        try:
            # Find the ticket in the database
            ticket = ticket_table.objects.get(id=event_id)
            print('ticket',ticket)

            
            ticket.ticket_date = new_date  
            print('ticket.ticket_date',ticket.ticket_date)
            ticket.save()  # Save the changes to the database
            
            return JsonResponse({'status': 'success', 'message': 'Event date updated successfully.'})
        except ticket_table.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Ticket not found.'}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)



#```````````````````````````````EMPLOYEE``````````````````````````````````````````

def employee(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = vendor_table.objects.filter(status=1)
            company = company_table.objects.filter(id=1).first()
            user_role = AdminRoles.objects.filter(status=1)
            return render(request, 'employee.html',{'customer':customer,'company':company,'user_role':user_role})
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")


def employee_view(request):
    data = list(employee_table.objects.filter(vendor_id=0,status=1).values())
    formatted = [
        {
            'action': '<button type="button" onclick="employee_edit(\'{}\')" class="btn btn-outline-primary btn-xs"><i class="feather icon-edit"></i></button> \
                      <button type="button" onclick="employee_delete(\'{}\')" class="btn btn-outline-danger btn-xs"><i class="feather icon-trash-2"></i></button>'.format(item['id'], item['id']), 
            'name': item['name'] if item['name'] else '-', 
            # 'address1': item['address_line1'] if item['address_line1'] else '-', 
            # 'address2': item['address_line2'] if item['address_line2'] else '-', 
            # 'city': item['city'] if item['city'] else '-', 
            # 'state': item['postal_code'] if item['postal_code'] else '-', 
            'empcode': item['employee_code'] if item['employee_code'] else '-', 
            'phone': item['phone'] if item['phone'] else '-', 
            # 'mobile': item['mobile'] if  item['mobile'] else '-', 
            'email': item['email'] if  item['email'] else '-',              
            # 'compnay': getItemNameById(vendor_table,item['company_id']),
            'status': '<span  class="badge text-bg-success">Active</span>' if item['is_active'] else '<span class="badge text-bg-danger">Inactive</span>'  # Assuming is_active is a boolean field

        } 
        for item in data
    ]
    formatted.reverse()
    return JsonResponse({'data': formatted})

def employee_edit(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = employee_table.objects.filter(id=request.POST.get('id'))
    
    return JsonResponse(data.values()[0])








def employee_add(request):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        form = EmployeeForm(request.POST, request.FILES)
        
        # Extract the email from the POST data for validation
        email = request.POST.get('email')

        # Check if the email already exists in the database
        if employee_table.objects.filter(email=email).exists():
            return JsonResponse({'message': 'error', 'errors': {'email': ['This email is already in use.']}}, status=400)

        if form.is_valid():
            category = form.save(commit=False)
            employee = request.POST.get('employee')
            name = request.POST.get('nick')
            user = request.POST.get('username')
            finger = request.POST.get('finger')
            role = request.POST.get('role')
            schd = int(request.POST.get('is_scheduler', 0))
            tech = int(request.POST.get('is_technician', 0))
            superv = int(request.POST.get('is_supervisor', 0))
            foreg = int(request.POST.get('is_foreigner', 0))
            gps = int(request.POST.get('is_gps', 0))
            pht = int(request.POST.get('is_photo', 0))
            qr = int(request.POST.get('is_qr', 0))
            signature = int(request.POST.get('is_signature', 0))
            sign = request.FILES.get('signature')
            pwd = request.POST.get('password')            
            phone = request.POST.get('phone')
            mobile = request.POST.get('mobile')
            address1 = request.POST.get('address_line1')
            address2 = request.POST.get('address_line2')
            city = request.POST.get('city')
            country = request.POST.get('country')
            postal = request.POST.get('postal')
            color = request.POST.get('color_code')  # Get color code from POST data
            vehicle = request.POST.get('vehicle')
            vendor_id = request.POST.get('vendor_id', 0)  
            print('vendor_id',vendor_id) 
            company_id = request.POST.get('company')
            print('company_id',company_id)  
            
            if company_id != 0 and vendor_id == 0:
                prefix = company_table.objects.get(id=company_id).prefix
            elif vendor_id != 0 and company_id == 0:
                prefix = vendor_table.objects.get(id=vendor_id).customer_prefix
            else:
                prefix = '' 
            
            # Generate employee code
            employee_code = generate_employee_code(vendor_id, company_id, prefix)
            print('employee_code', employee_code)

            # Assign values to category object
            category.employee_role = employee
            category.name = name
            category.username = user
            category.finger_print = finger            
            category.user_role = role
            category.is_scheduler = schd
            category.is_technician = tech
            category.is_supervisor = superv
            category.is_foreigner = foreg
            category.is_gps = gps
            category.is_photo = pht
            category.is_qr = qr
            category.is_signature = signature
            category.certificate = sign  
            category.email = email
            category.password = hashlib.md5(pwd.encode()).hexdigest()
            category.phone = phone
            category.mobile = mobile 
            category.address_line1 = address1
            category.address_line2 = address2
            category.city = city
            category.country = country
            category.postal_code = postal
            category.vehicle_number = vehicle
            category.color = color  
            category.company_id = company_id  
            category.employee_code = employee_code
            category.created_by = user_id
            category.updated_by = user_id
            category.created_on = timezone.now()  # Ensure timezone.now() is used
            category.updated_on = timezone.now()  # Ensure timezone.now() is used
            category.save()

            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors}, status=400)

    else:
        form = EmployeeForm()
    
    return render(request, 'employee.html', {'form': form})



def employee_update(request):
    if request.method == "POST":
        category_id = request.POST.get('id')
        category = employee_table.objects.get(id=category_id)
        form = EmployeeForm(request.POST, request.FILES, instance=category)

        if form.is_valid():
            category = form.save(commit=False)
            
            # Extract form data
            employee = request.POST.get('employee')
            name = request.POST.get('nick')
            user = request.POST.get('username')
            finger = request.POST.get('finger')
            prefix = request.POST.get('prefix')
            role = request.POST.get('role')
            schd = int(request.POST.get('is_scheduler', 0))
            tech = int(request.POST.get('is_technician', 0))
            superv = int(request.POST.get('is_supervisor', 0))
            foreg = int(request.POST.get('is_foreigner', 0))
            gps = int(request.POST.get('is_gps', 0))
            pht = int(request.POST.get('is_photo', 0))
            qr = int(request.POST.get('is_qr', 0))
            signature = int(request.POST.get('is_signature', 0))
            sign = request.FILES.get('signature')
            mail = request.POST.get('email')
            pwd = request.POST.get('password')            
            phone = request.POST.get('phone')
            mobile = request.POST.get('mobile')
            address1 = request.POST.get('address_line1')
            address2 = request.POST.get('address_line2')
            city = request.POST.get('city')
            country = request.POST.get('country')
            postal = request.POST.get('postal')
            color = request.POST.get('color_code')  # Get color code from POST data
            vehicle = request.POST.get('vehicle')  
            active = request.POST.get('is_active')  
            user_id = request.session.get('user_id')


            category.employee_role = employee
            category.name = name
            category.username = user
            category.finger_print = finger            
            category.user_role = role
            category.is_scheduler = schd
            category.is_technician = tech
            category.is_supervisor = superv
            category.is_foreigner = foreg
            category.is_gps = gps
            category.is_photo = pht
            category.is_qr = qr
            category.is_signature = signature
            if sign:
                category.certificate = sign
                print('new')
            else:
                print('old')

            category.email = mail
            if pwd:  
                category.password = hashlib.md5(pwd.encode()).hexdigest()
            category.phone = phone
            category.mobile = mobile 
            category.address_line1 = address1
            category.address_line2 = address2
            category.city = city
            category.country = country
            category.postal_code = postal
            category.vehicle_number = vehicle
            category.color = color  # Store the color code
            category.is_active = active
            
            category.updated_by = user_id
            category.updated_on = timezone.now()

            # Save the category object
            category.save()            
            return JsonResponse({'message': 'success'})
        else:
            errors = form.errors.as_json()
            return JsonResponse({'message': 'error', 'errors': errors})


def employee_delete(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        try:
            employee_table.objects.filter(id=data_id).update(status=0)
            return JsonResponse({'message': 'yes'})
        except employee_table.DoesNotExist:
            return JsonResponse({'message': 'no such data'})
    else:
        return JsonResponse({'message': 'Invalid request method'})


#````````````````````````````````********````````````````````````````````````````````





from django.http import JsonResponse
from django.db.models import Q

# def ticket_view(request):
#     customer_id = request.POST.get('customer')
#     project_id = request.POST.get('project')
#     vendor_id = request.POST.get('vendor')
#     asset_id = request.POST.get('asset')
#     technician_id = request.POST.get('technician')
#     status_id = request.POST.get('status')
#     request_id = request.POST.get('request')
#     priority_id = request.POST.get('priority')
#     category_id = request.POST.get('category')
#     system_id = request.POST.get('system')
#     frequency_id = request.POST.get('frequency')
#     from_date = request.POST.get('from_date')
#     to_date = request.POST.get('to_date')

#     if customer_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     if project_id in [None, '0', 'Select', '']:
#         return JsonResponse({'data': []})  

#     query = Q(status=1)  

#     if customer_id.isdigit():
#         query &= Q(customer_id=customer_id)
#         print(f"Filtering by customer_id: {customer_id}")

#     if project_id and project_id.isdigit():
#         query &= Q(project_id=project_id)
#         print(f"Filtering by project_id: {project_id}")

#     if vendor_id and vendor_id.isdigit():
#         query &= Q(vendor_id=vendor_id)
#         print(f"Filtering by vendor_id: {vendor_id}")

#     if asset_id and asset_id.isdigit():
#         query &= Q(asset_item_id=asset_id)
#         print(f"Filtering by asset: {asset_id}")

#     if technician_id and technician_id.isdigit():
#         query &= Q(technician_id=technician_id)
#         print(f"Filtering by technician_id: {technician_id}")

#     if status_id:
#         query &= Q(ticket_status=status_id)
#         print(f"Filtering by ticket status: {status_id}")

#     if request_id:
#         query &= Q(ticket_type=request_id)
#         print(f"Filtering by ticket_type: {request_id}")

#     if priority_id:
#         query &= Q(priority=priority_id)
#         print(f"Filtering by priority: {priority_id}")

#     if category_id and category_id.isdigit():
#         query &= Q(category_id=category_id)
#         print(f"Filtering by category_id: {category_id}")

#     if system_id and system_id.isdigit():
#         query &= Q(system_id=system_id)
#         print(f"Filtering by system_id: {system_id}")

#     if from_date and to_date:
#         query &= Q(ticket_date__range=[from_date, to_date])
#         print(f"Filtering by date range: {from_date} to {to_date}")

#     # Retrieve filtered assets
#     assets = ticket_table.objects.filter(query).order_by('-id')

#     asset_name_map = {asset.id: asset.asset_item_code for asset in asset_table.objects.all()}
#     brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}

#     total_asset_count = assets.count()
#     print('Total asset count (after filtering):', total_asset_count)

#     data = []
    
#     for item in assets:

#         frequency_names = []
#         frequency_ids = item.frequency_id.split(',') if item.frequency_id else []
#         # print(f"Frequency IDs for asset ID {item.id}: {frequency_ids}")

#         for freq_id in frequency_ids:
#             if freq_id.isdigit():
#                 try:
#                     freq_name = frequency_table.objects.get(id=int(freq_id)).name
#                     frequency_names.append(freq_name)
#                 except frequency_table.DoesNotExist:
#                     print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

#         frequency_str = ', '.join(frequency_names)

#         action_buttons = [
#             f'<button type="button" onclick="request_delete(\'{item.id}\')" class="btn btn-outline-danger btn-xs" title="Delete"><i class="feather icon-trash-2"></i></button>',
#             f'<button type="button" onclick="ticket_edit(\'{item.id}\')" class="btn btn-outline-secondary btn-xs" title="Edit"><i class="feather icon-edit-2"></i></button>'
#         ]

#         if item.ticket_status == 'Completed':
#             print_button = f'<button type="button" onclick="print_btn(\'{item.id}\', \'{item.file_name.url if item.file_name else ""}\')" class="btn btn-outline-info btn-xs" title="Print"><i class="feather icon-printer"></i></button>'
#             attachment_button = f'<button type="button" onclick="attachment_file(\'{item.id}\')" class="btn btn-outline-warning btn-xs" title="File Attachments"><i class="feather icon-paperclip"></i></button>'
#             reopen_button = f'<button type="button" onclick="reopen_ticket(\'{item.id}\')" class="btn btn-outline-success btn-xs" title="Reopen Ticket"><i class="fa fa-recycle"></i></button>'

#             action_buttons.extend([print_button, attachment_button, reopen_button])

#         formatted_item = {
#             'action': ' '.join(action_buttons),
#             'empty': '', 
#             'id': item.id, 
#             'customer': getItemNameById(customer_table, item.customer_id),
#             'vendor': getItemNameById(vendor_table, item.vendor_id),
#             'project': getItemNameById(project_table, item.project_id),
#             'code': getItemNameById(system_table, item.system_id) or '-',  # Use asset_name_map for asset code
#             'frequency': frequency_str, 
#             'asset': asset_name_map.get(item.asset_item_id, '-'), 
#             'technician': getItemNameById(employee_table, item.technician_id) if technician_id else '-',
#             'reqno': item.ticket_no, 
#             'reqdate': item.ticket_date,  # Corrected variable name
#             'reqtype': item.ticket_type or '-', 
#             'finding': (item.findings or '') + (item.action or ''),
#             'desc': item.description or '-', 
#             'status': f'<span class="badge text-bg-{get_status_color(item.ticket_status)}">{item.ticket_status}</span>',
#         }

        
#         data.append(formatted_item)
        

#     final_data_count = len(data) 
#     print('Final data count:', final_data_count)  

#     return JsonResponse({'data': data, 'total_asset_count': total_asset_count})


from django.http import JsonResponse
from django.db.models import Q
from django.http import JsonResponse
from django.db.models import Q

def ticket_view(request):
    customer_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    asset_id = request.POST.get('asset')
    technician_id = request.POST.get('technician')
    status_id = request.POST.get('status')
    request_id = request.POST.get('request')
    priority_id = request.POST.get('priority')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    is_signed = request.POST.get('signed')
    from_date = request.POST.get('from_date')
    to_date = request.POST.get('to_date')
    logged_user_id = request.session.get('user_id') 

    print('logged_user_id', logged_user_id)

    if customer_id in [None, '0', 'Select', '']:
        print("No customer selected.")
        return JsonResponse({'data': []})

    if project_id in [None, '0', 'Select', '']:
        print("No project selected.")
        return JsonResponse({'data': []})

    query = Q(status=1)

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
        print(f"Filtering by customer_id: {customer_id}")

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
        print(f"Filtering by project_id: {project_id}")

    if vendor_id and vendor_id.isdigit():
        query &= Q(vendor_id=vendor_id)
        print(f"Filtering by vendor_id: {vendor_id}")

    if asset_id and asset_id.isdigit():
        query &= Q(asset_item_id=asset_id)
        print(f"Filtering by asset: {asset_id}")

    if technician_id and technician_id.isdigit():
        query &= Q(technician_id=technician_id)
        print(f"Filtering by technician_id: {technician_id}")

    if status_id:
        query &= Q(ticket_status=status_id)
        print(f"Filtering by ticket status: {status_id}")

    if request_id:
        query &= Q(ticket_type=request_id)
        print(f"Filtering by ticket_type: {request_id}")

    if priority_id:
        query &= Q(priority=priority_id)
        print(f"Filtering by priority: {priority_id}")

    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)
        print(f"Filtering by category_id: {category_id}")

    if system_id and system_id.isdigit():
        query &= Q(system_id=system_id)
        print(f"Filtering by system_id: {system_id}")

    if is_signed and is_signed.isdigit():
        query &= Q(is_endorsed=is_signed)
        print(f"Filtering by is_signed: {is_signed}")

    if from_date and to_date:
        query &= Q(ticket_date__range=[from_date, to_date])
        print(f"Filtering by date range: {from_date} to {to_date}")

    # Retrieve filtered tickets
    assets = ticket_table.objects.filter(query).order_by('-id')
    asset_name_map = {asset.id: asset.asset_item_code for asset in asset_table.objects.all()}
    brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}

    total_asset_count = assets.count()
    print('Total asset count (after filtering):', total_asset_count)

    data = []
    
    for item in assets:
        frequency_names = []
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []

        for freq_id in frequency_ids:
            if freq_id.isdigit():
                try:
                    freq_name = frequency_table.objects.get(id=int(freq_id)).name
                    frequency_names.append(freq_name)
                except frequency_table.DoesNotExist:
                    print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

        frequency_str = ', '.join(frequency_names)

        action_buttons = [
            f'<button type="button" onclick="request_delete(\'{item.id}\')" class="btn btn-outline-danger btn-xs" title="Delete"><i class="feather icon-trash-2"></i></button>',
            f'<button type="button" onclick="ticket_edit(\'{item.id}\')" class="btn btn-outline-secondary btn-xs" title="Edit"><i class="feather icon-edit-2"></i></button>'
        ]

        # Always add print button for all tickets
        print_button = f'<button type="button" onclick="print_btn(\'{item.id}\', \'{item.file_name.url if item.file_name else ""}\')" class="btn btn-outline-info btn-xs" title="Print"><i class="feather icon-printer"></i></button>'
        action_buttons.append(print_button)

        if item.ticket_status == 'completed':
            attachment_button = f'<button type="button" onclick="attachment_file(\'{item.id}\')" class="btn btn-outline-warning btn-xs" title="File Attachments"><i class="feather icon-paperclip"></i></button>'
            reopen_button = f'<button type="button" onclick="reopen_ticket(\'{item.id}\')" class="btn btn-outline-success btn-xs" title="Reopen Ticket"><i class="fa fa-recycle"></i></button>'
            action_buttons.extend([attachment_button, reopen_button])

        # Customer and Project Checks
        customer = customer_table.objects.filter(id=item.customer_id).first()
        project = project_table.objects.filter(id=item.project_id).first()
        
        if customer:
            employee_ids = customer.employee_id.split(',')
            print(f'Employee IDs for customer: {employee_ids}')
            customer_condition = str(logged_user_id) in employee_ids
        else:
            customer_condition = False

        if project:
            employee_ids = project.customer_employee_id.split(',')
            print(f'Employee IDs for project: {employee_ids}')
            project_condition = str(logged_user_id) in employee_ids
        else:
            project_condition = False

        print(f'logged_user_id: {logged_user_id}, customer_condition: {customer_condition}, project_condition: {project_condition}')

        
        ticket_status_condition = item.ticket_status == "completed" 
        print(f'Ticket Status: {item.ticket_status}, Is Signature: {item.is_signature}, Status Condition Met: {ticket_status_condition}')

        if customer_condition and project_condition and ticket_status_condition:
            approval_button = f'<button type="button" onclick="approve_ticket(\'{item.id}\')" class="btn btn-outline-success btn-xs" title="Approve"><i class="fa fa-check"></i></button>'
            action_buttons.append(approval_button)
            print(f"Approval button added for ticket ID: {item.id}")
        else:
            print(f"Approval button NOT added for ticket ID: {item.id} - conditions not met.")

        formatted_item = {
            'action': ' '.join(action_buttons),
            'empty': '', 
            'id': item.id, 
            'customer': getItemNameById(customer_table, item.customer_id),
            'vendor': getItemNameById(vendor_table, item.vendor_id),
            'project': getItemNameById(project_table, item.project_id),
            'code': getItemNameById(system_table, item.system_id) or '-', 
            'frequency': frequency_str, 
            'asset': asset_name_map.get(item.asset_item_id, '-'), 
            'technician': getItemNameById(employee_table, item.technician_id) if technician_id else '-',
            'reqno': item.ticket_no, 
            'reqdate': item.ticket_date,  
            'reqtype': item.ticket_type or '-', 
            'finding': (item.findings or '') + (item.action or ''), 
            'desc': item.description or '-', 
            'status': f'<span class="badge text-bg-{get_status_color(item.ticket_status)}">{item.ticket_status}</span>',
        }

        data.append(formatted_item)

    final_data_count = len(data) 
    print('Final data count:', final_data_count)  

    return JsonResponse({'data': data, 'total_asset_count': total_asset_count})






def get_status_color(status):
    status = status.lower()  # Normalize status to lower case
    if status == 'pending':
        return 'warning'
    elif status == 'open':
        return 'info'
    elif status == 'hold':
        return 'secondary'
    elif status == 'partial':
        return 'primary'
    elif status == 'completed':
        return 'success'
    elif status == 'cancelled':
        return 'danger'
    else:
        return 'secondary'




from django.http import JsonResponse
from django.views.decorators.http import require_POST
from PyPDF2 import PdfReader, PdfWriter  # Example for handling PDF files
import os

# @require_POST
# def approve_ticket(request):
#     ticket_id = request.POST.get('ticket_id')
#     ticket = ticket_table.objects.filter(id=ticket_id).first()

#     if not ticket:
#         return JsonResponse({'status': 'error', 'message': 'Ticket not found.'})

#     # Path to the existing file
#     existing_file_path = ticket.file_name.path
#     if not os.path.exists(existing_file_path):
#         return JsonResponse({'status': 'error', 'message': 'File not found.'})

#     # Read the existing PDF file
#     reader = PdfReader(existing_file_path)
#     writer = PdfWriter()

#     # Cut the first two pages
#     num_pages = len(reader.pages)
#     if num_pages > 2:
#         for page in reader.pages[2:]:
#             writer.add_page(page)
#     elif num_pages == 2:
#         # If there are only two pages, we can't keep any
#         return JsonResponse({'status': 'error', 'message': 'Not enough pages to cut.'})

#     # Generate new content for the first two pages
#     new_content_pages = create_new_content(ticket)

#     # Add new content pages to the writer
#     for new_content in new_content_pages:
#         writer.add_page(new_content)

#     # Add the third page from the existing document, if it exists
#     if num_pages >= 3:
#         writer.add_page(reader.pages[2])  # This is the third page (index 2)

#     # Save the new PDF to the same location or a new one
#     new_file_path = existing_file_path.replace('.pdf', '_updated.pdf')
#     with open(new_file_path, 'wb') as output_pdf:
#         writer.write(output_pdf)

#     # Update the ticket record if necessary
#     ticket.file_name.name = new_file_path
#     ticket.is_signature = 1  # Example update; adjust as necessary
#     ticket.save()

#     return JsonResponse({'status': 'success', 'message': 'Ticket approved and file updated successfully.'})

# def create_new_content(ticket):
#     """ Create new content pages based on ticket details. """
#     from PyPDF2 import PageObject
#     new_pages = []

#     # Create a new PDF page with ticket details (you might want to customize this)
#     page1 = PageObject.create_blank_page(width=72, height=72)  # Example dimensions
#     # Add content to page1 from the ticket
#     # e.g., page1.insert_text(100, 500, ticket.some_field)

#     page2 = PageObject.create_blank_page(width=72, height=72)  # Example dimensions
#     # Add content to page2 from the ticket
#     # e.g., page2.insert_text(100, 500, ticket.another_field)

#     new_pages.append(page1)
#     new_pages.append(page2)

#     return new_pages

# from django.shortcuts import render
# from django.http import HttpResponse
# from weasyprint import HTML

# from django.shortcuts import render


# def ticket_report(request, ticket_id):
#     # Fetch the ticket and associated checklist items based on the ticket_id
#     ticket = Ticket.objects.get(id=ticket_id)
#     checklist_items = ChecklistItem.objects.filter(ticket=ticket).order_by('id')

#     # Prepare the context for rendering
#     context = {
#         'ticket': ticket,
#         'checklist_items': checklist_items,
#         'total_hours': calculate_total_hours(ticket),  # Assuming you have a function to calculate this
#     }

#     # Render the HTML template
#     html_string = render_to_string('ticket_report.html', context)

#     # Create a PDF from the rendered HTML
#     pdf = HTML(string=html_string).write_pdf()

#     # Return the PDF as a response
#     response = HttpResponse(pdf, content_type='application/pdf')
#     response['Content-Disposition'] = f'attachment; filename="ticket_report_{ticket_id}.pdf"'
#     return response


import os
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.views.decorators.http import require_POST
from xhtml2pdf import pisa
from io import BytesIO

# @require_POST
# def approve_ticket(request):
#     ticket_id = request.POST.get('ticket_id')
#     ticket = ticket_table.objects.filter(id=ticket_id).first()

#     if not ticket:
#         return JsonResponse({'status': 'error', 'message': 'Ticket not found.'})

#     existing_file_path = ticket.file_name.path
#     if not os.path.exists(existing_file_path):
#         return JsonResponse({'status': 'error', 'message': 'File not found.'})

#     # Generate PDF from HTML template
#     pdf_content = create_ticket_report(ticket)

#     # Save the PDF to a file
#     new_file_path = existing_file_path.replace('.pdf', '_updated.pdf')
#     with open(new_file_path, 'wb') as output_pdf:
#         output_pdf.write(pdf_content)

#     # Update ticket record if necessary
#     ticket.file_name.name = new_file_path
#     ticket.is_signature = 1  # Update as necessary
#     ticket.save()

#     return JsonResponse({'status': 'success', 'message': 'Ticket approved and file updated successfully.'})

# def create_ticket_report(ticket):
#     """ Generate a PDF report from the HTML template. """
#     # Render the HTML content from the template
#     html = render_to_string('common/ticket_report.html', {'ticket': ticket})

#     # Create a BytesIO buffer for the PDF
#     buffer = BytesIO()

#     # Create PDF from HTML using xhtml2pdf
#     pisa_status = pisa.CreatePDF(html, dest=buffer)

#     # Check for errors
#     if pisa_status.err:
#         return JsonResponse({'status': 'error', 'message': 'Error generating PDF.'})

#     # Get PDF content from buffer
#     buffer.seek(0)
#     return buffer.read()  # Return PDF bytes


from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.template.loader import render_to_string
from io import BytesIO
from xhtml2pdf import pisa
import os
from PyPDF2 import PdfReader, PdfWriter


import os
from io import BytesIO
from django.http import JsonResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from PyPDF2 import PdfReader, PdfWriter
from .models import ticket_table  # Import your ticket model
import os
from django.http import JsonResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from PyPDF2 import PdfReader, PdfWriter
from io import BytesIO

import os
from django.http import JsonResponse
from PyPDF2 import PdfReader, PdfWriter
from io import BytesIO
from xhtml2pdf import pisa
from django.conf import settings  # Import settings to access MEDIA_ROOT

import os
from django.http import JsonResponse
from PyPDF2 import PdfReader, PdfWriter
from io import BytesIO
from xhtml2pdf import pisa
from django.conf import settings  # Import settings to access MEDIA_ROOT

# def approve_ticket(request):
#     ticket_id = request.POST.get('ticket_id')
#     ticket = ticket_table.objects.filter(id=ticket_id).first()
#     user_id = request.session.get('user_id')

#     if not ticket:
#         return JsonResponse({'status': 'error', 'message': 'Ticket not found.'})

#     # Get the existing file path
#     existing_file_path = ticket.file_name.path
#     if not os.path.exists(existing_file_path):
#         return JsonResponse({'status': 'error', 'message': 'File not found.'})

#     pdf_content = create_ticket_report(request, ticket)  # Pass request here

#     if isinstance(pdf_content, JsonResponse):  # Check if PDF generation failed
#         return pdf_content  # Return the error response

#     new_pdf = PdfReader(BytesIO(pdf_content))
#     writer = PdfWriter()

#     existing_reader = PdfReader(existing_file_path)

#     # Add the first two pages of the new PDF (from the ticket report)
#     for page in new_pdf.pages:
#         writer.add_page(page)

#     for i in range(2, len(existing_reader.pages)):
#         writer.add_page(existing_reader.pages[i])

#     # Create the new file path within the same directory as the original file
#     # Get the directory of the existing file
#     existing_dir = os.path.dirname(existing_file_path)  # Get the directory of the existing file
#     base_name = os.path.basename(existing_file_path)  # Get the file name without the directory
#     base, ext = os.path.splitext(base_name)  # Split the base name into name and extension

#     # Construct the new file path in the same directory
#     new_file_path = os.path.join(existing_dir, f"{base}_approved{ext}")

#     # Save the new PDF to a file
#     with open(new_file_path, 'wb') as output_pdf:
#         writer.write(output_pdf)

#     # Update ticket record
#     ticket.file_name.name = os.path.relpath(new_file_path, settings.MEDIA_ROOT)  # Save relative path
#     ticket.is_signature = 1  
#     ticket.approved_by = user_id  
#     ticket.save()

#     return JsonResponse({'status': 'success', 'message': 'Ticket approved and file updated successfully.'})

def approve_ticket(request):
    ticket_id = request.POST.get('ticket_id')
    ticket = ticket_table.objects.filter(id=ticket_id).first()
    user_id = request.session.get('user_id')
    print('ticket_id',ticket_id)
    print('ticket',ticket)

    if not ticket:
        return JsonResponse({'status': 'error', 'message': 'Ticket not found.'})

    # Check if file_name is empty
    print('ticket.file_name*************',ticket.file_name)
    if not ticket.file_name:
        return JsonResponse({'status': 'error', 'message': 'No file associated with this ticket.'})

    # Get the existing file path
    print('ticket.file_name.path*************',ticket.file_name.path)
    
    existing_file_path = ticket.file_name.path
    if not os.path.exists(existing_file_path):
        return JsonResponse({'status': 'error', 'message': 'File not found.'})

    pdf_content = create_ticket_report(request, ticket)

    if isinstance(pdf_content, JsonResponse):  # Check if PDF generation failed
        return pdf_content  # Return the error response

    new_pdf = PdfReader(BytesIO(pdf_content))
    writer = PdfWriter()

    existing_reader = PdfReader(existing_file_path)

    # Add the first two pages of the new PDF (from the ticket report)
    for page in new_pdf.pages:
        writer.add_page(page)

    for i in range(2, len(existing_reader.pages)):
        writer.add_page(existing_reader.pages[i])

    # Create the new file path within the same directory as the original file
    existing_dir = os.path.dirname(existing_file_path)
    base_name = os.path.basename(existing_file_path)
    base, ext = os.path.splitext(base_name)

    new_file_path = os.path.join(existing_dir, f"{base}_approved{ext}")

    # Save the new PDF to a file
    with open(new_file_path, 'wb') as output_pdf:
        writer.write(output_pdf)

    # Update ticket record
    ticket.file_name.name = os.path.relpath(new_file_path, settings.MEDIA_ROOT)
    ticket.is_endorsed = 1  
    ticket.approved_by = user_id  
    ticket.save()

    return JsonResponse({'status': 'success', 'message': 'Ticket approved and file updated successfully.'})

def create_ticket_report(request, ticket):
    """ Generate a PDF report from the HTML template. """
    
    # Get the full URL for the logo
    logo_url = request.build_absolute_uri('/static/assets/images/logo2.svg')  
    user_id = request.session.get('user_id')

    # Calculate total hours if start and end dates are available
    if ticket.start_date and ticket.end_date:
        total_time = ticket.end_date - ticket.start_date
        total_hrs = str(total_time)  
    else:
        total_hrs = '-'

    signature_url = None
    if ticket.signature:
        signature_path = str(ticket.signature)
        signature_url = request.build_absolute_uri(f"{settings.MEDIA_URL}{signature_path}")

    # Retrieve other necessary information for rendering the report
    project_name = project_table.objects.filter(id=ticket.project_id).values_list('name', flat=True).first() or '-'
    vendor_name = vendor_table.objects.filter(id=ticket.vendor_id).values_list('name', flat=True).first() or '-'
    asset_name = asset_table.objects.filter(id=ticket.asset_item_id).values_list('asset_item_code', flat=True).first() or '-'
    location = asset_table.objects.filter(id=ticket.asset_item_id).values_list('location', flat=True).first() or '-'
    system_name = system_table.objects.filter(id=ticket.system_id).values_list('name', flat=True).first() or '-'
    frequency_name = system_table.objects.filter(id=ticket.frequency_id).values_list('name', flat=True).first() or '-'
    technician_name = employee_table.objects.filter(id=ticket.technician_id).values_list('name', flat=True).first() or '-'
    approved_by = employee_table.objects.filter(id=ticket.approved_by).values_list('name', flat=True).first() or '-'
    today = timezone.now().strftime('%Y-%m-%d')

    # Retrieve checklist items for the ticket
    checklists = TicketChecklistTable.objects.filter(ticket_id=ticket.id, is_active=1)
    checklist_details = []
    
    for checklist_item in checklists:
        checklist_description = system_checklist.objects.filter(id=checklist_item.checklist_id).values_list('question', flat=True).first() or '-'
        is_checked = checklist_item.is_checked
        checklist_details.append({
            'description': checklist_description,
            'is_checked': is_checked
        })

    employee = employee_table.objects.filter(id=user_id).first()
    if employee and employee.certificate:
        aproval_signature_path = str(employee.certificate)
        aproval_signature = request.build_absolute_uri(f"{settings.MEDIA_URL}{aproval_signature_path}")

    # Render the HTML content from the template with the names
    html = render_to_string('common/ticket_report.html', {
        'ticket': ticket, 
        'logo_url': logo_url,
        'project_name': project_name,
        'vendor_name': vendor_name,
        'asset_name': asset_name,
        'system_name': system_name,
        'location': location,
        'frequency_name': frequency_name,
        'total_hrs': total_hrs,
        'technician_name': technician_name,
        'signature_url': signature_url,
        'aproval_signature': aproval_signature,
        'approved_by': approved_by,
        'today': today,
        'checklists': checklist_details  # Pass the checklist details
    })

    # Create a BytesIO buffer for the PDF
    buffer = BytesIO()

    # Create PDF from HTML using xhtml2pdf
    pisa_status = pisa.CreatePDF(html, dest=buffer)

    # Check for errors
    if pisa_status.err:
        return JsonResponse({'status': 'error', 'message': 'Error generating PDF.'})

    # Get PDF content from buffer
    buffer.seek(0)
    return buffer.read()









def service_request(request, encoded_vendor_id, encoded_project_id, encoded_asset_id,encoded_technician_id):
    # Decode the IDs
    vendor_id = base64.b64decode(encoded_vendor_id).decode('utf-8')
    print('vendor_id',vendor_id)
    project_id = base64.b64decode(encoded_project_id).decode('utf-8')
    print('project_id',project_id)
    asset_id = base64.b64decode(encoded_asset_id).decode('utf-8')
    print()
    technician_id = base64.b64decode(encoded_technician_id).decode('utf-8')
   
    
    vendor = vendor_table.objects.filter(status=1)
    project = project_table.objects.filter(status=1)
    asset = asset_table.objects.filter(status=1)
    technician = employee_table.objects.filter(status=1)
    frequency = frequency_table.objects.filter(status=1)
    library = system_table.objects.filter(status=1)

    return render(request, 'request/service.html', {
        'vendor_id': vendor_id,
        'project_id': project_id,
        'asset_id': asset_id,
        'technician_id': technician_id,
        'vendor':vendor,
        'project':project,
        'asset':asset,
        'technician':technician,
        'frequency':frequency,
        'library':library
        
    })




def get_assets_by_vendor(request, vendor_id):
    try:
        print(vendor_id)
        vendor = vendor_table.objects.get(id=vendor_id)
        print('asset vendor',vendor)
        assets = asset_table.objects.filter(vendor_id=vendor.id, status=1).values('id', 'asset_item_code','name')
        print(assets)
        return JsonResponse(list(assets), safe=False)  # Return assets, not vendors
    except vendor_table.DoesNotExist:
        return JsonResponse({'error': 'Vendor not found'}, status=404)



def get_all_assets(request):
    assets = asset_table.objects.filter(status=1).values('id', 'asset_item_code','name')
    print(assets)
    return JsonResponse({'assets': list(assets)})  # Fix key from 'vendors' to 'assets'


def get_projects_by_customer(request, customer_id):
    try:
        projects = project_table.objects.filter(customer_id=customer_id, status=1).values('id', 'name')
        return JsonResponse({'projects': list(projects)}, safe=False)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


# def get_assets_by_vendor(request, vendor_id):
#     assets = asset_table.objects.filter(vendor_id=vendor_id).values('id', 'name')
#     return JsonResponse(list(assets), safe=False)

def get_technicians_by_vendor(request, vendor_id):
    print('vendor_id',vendor_id)
    technicians = employee_table.objects.filter(status=1, vendor_id=vendor_id).values('id', 'name')
    print(technicians)
    return JsonResponse(list(technicians), safe=False)


def service_add(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':            
            vendor = vendor_table.objects.filter(status=1)
            project = project_table.objects.filter(status=1)
            asset = asset_table.objects.filter(status=1)
            technician = employee_table.objects.filter(status=1).exclude(vendor_id=0)
            frequency = frequency_table.objects.filter(status=1)
            library = system_table.objects.filter(status=1)
            return render(request, 'request/service.html',{
            'vendor':vendor,
            'project':project,
            'asset':asset,
            'technician':technician,
            'frequency':frequency,
            'library':library
                })
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")

def new_ticket(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":  
        user_id = request.session.get('user_id')
        frm = request.POST
        date = frm.get('request_date')
        time = frm.get('request_time')
        name = frm.get('name')
        vendor_id = frm.get('vendor')
        project_id = frm.get('project')
        asset_id = frm.get('asset_item')
        technician_id = frm.get('technician')
        request_type = frm.get('request_type')
        priority = frm.get('priority')
        frequency = request.POST.getlist('frequency')
        description = frm.get('description')
        asset_system = frm.get('asset_libaray')

        try:
            customer = vendor_table.objects.get(id=vendor_id)  # Fetch full customer object
            
            project = project_table.objects.get(id=project_id)
            
            asset = asset_table.objects.get(id=asset_id)
            category = asset.category_id
            customer_id = asset.customer_id  # Retrieve customer_id from asset

            customer = vendor_table.objects.get(id=customer_id)  # Fetch full customer object if needed

            technician = employee_table.objects.get(id=technician_id)

        except (vendor_table.DoesNotExist, project_table.DoesNotExist, asset_table.DoesNotExist, employee_table.DoesNotExist) as e:
            print(f"Error: {str(e)}")  # Log the specific error
            return JsonResponse({"error": "One or more objects not found"}, status=400)


        customer_prefix = customer.customer_prefix
        project_prefix = project.prefix

        num_series = generate_unique_ticket_code(vendor_id, project_id)
        ticket_no = f"{customer_prefix}{project_prefix}{num_series}"

        ticket = ticket_table()
        ticket.ticket_date = date
        ticket.customer_id = customer_id
        ticket.schedule_date = date
        ticket.ticket_time = time
        ticket.name = name
        ticket.vendor_id = vendor_id
        ticket.project_id = project_id
        ticket.asset_item_id = asset_id
        ticket.system_id = asset_system
        ticket.category_id = category
        ticket.technician_id = technician_id
        ticket.ticket_type = request_type
        ticket.priority = priority
        ticket.frequency_id = ','.join(frequency)
        ticket.description = description
        ticket.num_series = num_series
        ticket.ticket_no = ticket_no
        ticket.created_on = timezone.now()
        ticket.created_by = user_id
        ticket.updated_on = timezone.now()
        ticket.updated_by = user_id

        ticket.save()
        res = "Success"
        return JsonResponse({"message": res})


def service_page(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        user_id = request.session.get('user_id')

        vendor = vendor_table.objects.filter(status=1)
        project = project_table.objects.filter(status=1)
        asset = asset_table.objects.filter(status=1)
        technician = employee_table.objects.filter(status=1)
        category = category_table.objects.filter(status=1)
        system = system_table.objects.filter(status=1)
        frequency = frequency_table.objects.filter(status=1)

        if user_type == 'superadmin':
            customer = customer_table.objects.filter(status=1)
        elif user_type == 'admin':
            customer = customer_table.objects.filter(status=1, employee_id__contains=str(user_id))
        else:
            print("Unauthorized access attempt")  # Debug info
            return HttpResponse("Unauthorized access", status=403)

        return render(request, 'request/service_request.html', {
            'customer': customer,
            'project': project,
            'asset': asset,
            'technician': technician,
            'category': category,
            'system': system,
            'frequency': frequency,
            'vendor':vendor
        })

    else:  # Corrected indentation here
        return HttpResponseRedirect('/signin')



def getItemNameById(table, item_id):
    try:
        item = table.objects.get(id=item_id)
        return item.name
    except table.DoesNotExist:
        return None






import base64
from io import BytesIO
import qrcode
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt



def service_view(request):
    customer_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    vendor_id = request.POST.get('vendor')
    asset_id = request.POST.get('asset')
    technician_id = request.POST.get('technician')
    status_id = request.POST.get('status')
    request_id = request.POST.get('request')
    priority_id = request.POST.get('priority')
    category_id = request.POST.get('category')
    system_id = request.POST.get('system')
    frequency_id = request.POST.get('frequency')
    from_date = request.POST.get('from_date')
    to_date = request.POST.get('to_date')



    if customer_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    if project_id in [None, '0', 'Select', '']:
        return JsonResponse({'data': []})  

    query = Q(status=1)  

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
        print(f"Filtering by customer_id: {customer_id}")

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
        print(f"Filtering by project_id: {project_id}")

    if vendor_id and vendor_id.isdigit():
        query &= Q(vendor_id=vendor_id)
        print(f"Filtering by vendor_id: {vendor_id}")

    if asset_id and asset_id.isdigit():
        query &= Q(asset_item_id=asset_id)
        print(f"Filtering by asset: {asset_id}")

    if technician_id and technician_id.isdigit():
        query &= Q(technician_id=technician_id)
        print(f"Filtering by technician_id: {technician_id}")

    if status_id:
        query &= Q(ticket_status=status_id)
        print(f"Filtering by ticket status: {status_id}")

    if request_id:
        query &= Q(ticket_type=request_id)
        print(f"Filtering by ticket_type: {request_id}")

    if priority_id:
        query &= Q(priority=priority_id)
        print(f"Filtering by priority: {priority_id}")

    if category_id and category_id.isdigit():
        query &= Q(category_id=category_id)
        print(f"Filtering by category_id: {category_id}")

    if system_id and system_id.isdigit():
        query &= Q(system_id=system_id)
        print(f"Filtering by system_id: {system_id}")

    if from_date and to_date:
        query &= Q(ticket_date__range=[from_date, to_date])
        print(f"Filtering by date range: {from_date} to {to_date}")

    # Retrieve filtered assets
    assets = ticket_table.objects.filter(query).order_by('-id')

    asset_name_map = {asset.id: asset.asset_item_code for asset in asset_table.objects.all()}
    brand_map = {brand.id: brand.name for brand in brand_table.objects.all()}

    total_asset_count = assets.count()
    print('Total asset count (after filtering):', total_asset_count)

    data = []
    
    for index, item in enumerate(tickets, start=1):
        frequency_names = []
        frequency_ids = item.frequency_id.split(',') if item.frequency_id else []
        # print(f"Frequency IDs for asset ID {item.id}: {frequency_ids}")

        for freq_id in frequency_ids:
            if freq_id.isdigit():
                try:
                    freq_name = frequency_table.objects.get(id=int(freq_id)).name
                    frequency_names.append(freq_name)
                except frequency_table.DoesNotExist:
                    print(f"Frequency ID {freq_id} not found for asset ID {item.id}.")

        frequency_str = ', '.join(frequency_names)

        action_buttons = [
            f'<button type="button" onclick="request_delete(\'{item.id}\')" class="btn btn-outline-danger btn-xs" title="Delete"><i class="feather icon-trash-2"></i></button>',
            f'<button type="button" onclick="ticket_edit(\'{item.id}\')" class="btn btn-outline-secondary btn-xs" title="Edit"><i class="feather icon-edit-2"></i></button>'
        ]

        if item.ticket_status == 'Completed':
            print_button = f'<button type="button" onclick="print_btn(\'{item.id}\', \'{item.file_name.url if item.file_name else ""}\')" class="btn btn-outline-info btn-xs" title="Print"><i class="feather icon-printer"></i></button>'
            attachment_button = f'<button type="button" onclick="attachment_file(\'{item.id}\')" class="btn btn-outline-warning btn-xs" title="File Attachments"><i class="feather icon-paperclip"></i></button>'
            reopen_button = f'<button type="button" onclick="reopen_ticket(\'{item.id}\')" class="btn btn-outline-success btn-xs" title="Reopen Ticket"><i class="fa fa-recycle"></i></button>'

            action_buttons.extend([print_button, attachment_button, reopen_button])

        # Create the formatted item

        formatted_item = {
            'action': ' '.join(action_buttons) ,

            'empty': '', 
            'id': item.id, 
            'vendor': getItemNameById(vendor_table, item.vendor_id),
            'code': item_name, 
            'frequency': frequency_str, 
            'asset': asset_name.asset_item_code if asset_name else "-",
            'technician': getItemNameById(employee_table, item.technician_id),
            'reqno': item.ticket_no, 
            'reqdate': item.ticket_date, 
            'reqtype': item.ticket_type, 
            'finding': (item.findings or '-') + item.action or '-',
            'desc': item.description or '-', 
            'status': '<span class="badge text-bg-{}">{}</span>'.format(get_status_color(item.ticket_status), item.ticket_status),
        }

        data.append(formatted_item)
        

    final_data_count = len(data) 
    print('Final data count:', final_data_count)  

    return JsonResponse({'data': data, 'total_asset_count': total_asset_count})




# ```````````````````````````````````````QAR REPORTS````````````````````````````````````````````````````
import os
from datetime import datetime, timedelta
from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponse
from xhtml2pdf import pisa

from datetime import datetime, timedelta
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.conf import settings
import os

from django.http import HttpResponse
from xhtml2pdf import pisa
import os
from django.template.loader import render_to_string
from datetime import datetime, timedelta
from django.conf import settings


def qar_generator(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            return render(request, 'report/qar_generator.html',{'customer':customer})        
        else:
            return HttpResponseRedirect("/signin")
    else:
        return HttpResponseRedirect("/signin")
        

# def store_qar_report(ast_id, frequency_id, customer_id, project_id, asset_group_id, qar_file_name, start_date, end_date, ticket_model):
#     print('ast_id', ast_id)

#     # Prepare date range
#     start = datetime.strptime(start_date, "%Y-%m-%d")
#     end = datetime.strptime(end_date, "%Y-%m-%d")

#     # Check if asset exists
#     if not asset_list_table.objects.filter(id=ast_id).exists():
#         print(f"Asset with id {ast_id} does not exist.")
#         return None  # Or handle as needed

#     # Fetch asset details
#     asset = asset_list_table.objects.get(id=ast_id)
#     data = {
#         'id': ast_id,
#         'start': start.strftime('%Y-%m-%d'),  
#         'end': end.strftime('%Y-%m-%d'),      
#         'asset': asset,
#     }

#     # Initialize content_str here
#     content_str = ''

#     # Prepare date intervals
#     total_interval = (end - start).days + 1
#     page_interval = [start + timedelta(days=day) for day in range(total_interval)]

#     # Construct the content string
#     content_str += '<section class="sheet padding-10mm">'
#     content_str += qar_page_header(data)  # Header
#     content_str += '<div class="content">'  # Start of content division
#     content_str += '<table class="table table-striped table-hover">'
#     content_str += table_heading("#", "Checklist", "Frequency", page_interval) + '<tbody>'

#     # Retrieve QarParent records for the specific asset and frequency
#     qar_entries = qar_parent_table.objects.filter(asset_id=ast_id, frequency_id=frequency_id).values('question', 'frequency').distinct()

#     for idx, entry in enumerate(qar_entries, start=1):
#         print('1', idx, entry['question'], entry['frequency'])
#         content_str += table_rows(idx, entry['question'], entry['frequency'], ast_id, frequency_id, page_interval, ticket_model)

#     content_str += '</tbody></table>'  # End table
#     content_str += '</div>'  # End of content division
#     content_str += qar_page_footer(data)  # Footer
#     content_str += '</section>'  # End section

#     data['result'] = content_str

#     # Render to PDF
#     pdf_file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', qar_file_name)
#     print('data', data)

#     # Load the HTML template and render it
#     html_template = render_to_string('common/qar_report.html', data)

#     # Create PDF in A3 landscape
#     with open(pdf_file_path, 'w+b') as result_file:
#         pisa_status = pisa.CreatePDF(
#             html_template,
#             dest=result_file,
#             encoding='UTF-8',
#             pageSize='A3',
#             landscape=True
#         )

#     if pisa_status.err:
#         print("Error generating PDF")
#         return None

#     return pdf_file_path


import logging

def qar_generator(request):
    if 'user_id' in request.session:
        user_type = request.session.get('user_type')
        logging.info(f"User Type: {user_type}, Session User ID: {request.session.get('user_id')}")
        if user_type == 'superadmin' or user_type == 'admin':
            customer = customer_table.objects.filter(status=1)
            logging.info(f"Fetched {customer.count()} active customers.")
            return render(request, 'report/qar_generator.html', {'customer': customer})        
        else:
            logging.warning("Unauthorized user access attempt")
            return HttpResponseRedirect("/signin")
    else:
        logging.warning("No user session found.")
        return HttpResponseRedirect("/signin")


def store_qar_report(ast_id, frequency_id, customer_id, project_id, asset_group_id, qar_file_name, start_date, end_date, ticket_model):
    logging.info(f"Generating QAR report for Asset ID: {ast_id}, Frequency ID: {frequency_id}, Customer ID: {customer_id}, Project ID: {project_id}")

    # Prepare date range
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    logging.info(f"Processing date range: {start_date} to {end_date}")

    # Check if asset exists
    if not asset_list_table.objects.filter(id=ast_id).exists():
        logging.error(f"Asset with id {ast_id} does not exist.")
        return None  # Or handle as needed

    # Fetch asset details
    asset = asset_list_table.objects.get(id=ast_id)
    logging.info(f"Fetched asset details: {asset.name}, Category: {asset.category}")

    data = {
        'id': ast_id,
        'start': start.strftime('%Y-%m-%d'),
        'end': end.strftime('%Y-%m-%d'),
        'asset': asset,
    }

    # Initialize content_str here
    content_str = ''

    # Prepare date intervals
    total_interval = (end - start).days + 1
    page_interval = [start + timedelta(days=day) for day in range(total_interval)]
    logging.info(f"Generating report for {total_interval} days, Dates: {page_interval}")

    # Construct the content string
    content_str += '<section class="sheet padding-10mm">'
    content_str += qar_page_header(data)  # Header
    content_str += '<div class="content">'  # Start of content division
    content_str += '<table class="table table-striped table-hover">'
    content_str += table_heading("#", "Checklist", "Frequency", page_interval) + '<tbody>'

    # Retrieve QarParent records for the specific asset and frequency
    qar_entries = qar_parent_table.objects.filter(asset_id=ast_id, frequency_id=frequency_id).values('question', 'frequency').distinct()
    logging.info(f"Fetched {qar_entries.count()} QarParent entries for asset {ast_id} and frequency {frequency_id}.")

    for idx, entry in enumerate(qar_entries, start=1):
        logging.debug(f"Processing QAR Entry #{idx}: {entry['question']}, Frequency: {entry['frequency']}")
        content_str += table_rows(idx, entry['question'], entry['frequency'], ast_id, frequency_id, page_interval, ticket_model)

    content_str += '</tbody></table>'  # End table
    content_str += '</div>'  # End of content division
    content_str += qar_page_footer(data)  # Footer
    content_str += '</section>'  # End section

    data['result'] = content_str

    # Render to PDF
    pdf_file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', qar_file_name)
    logging.info(f"Rendering QAR report to PDF at {pdf_file_path}")

    # Load the HTML template and render it
    html_template = render_to_string('common/qar_report.html', data)

    # Create PDF in A3 landscape
    try:
        with open(pdf_file_path, 'w+b') as result_file:
            pisa_status = pisa.CreatePDF(
                html_template,
                dest=result_file,
                encoding='UTF-8',
                pageSize='A3',
                landscape=True
            )

        if pisa_status.err:
            logging.error("Error generating PDF")
            return None
        logging.info(f"PDF generated successfully at {pdf_file_path}")
    except Exception as e:
        logging.error(f"Error saving PDF: {e}")
        return None

    return pdf_file_path


# The rest of the functions can similarly have logging added


def qar_page_header(data):
    asset = data['asset']  # Corrected from 'assets' to 'asset'
    
    header_str = f"""
    <div '> <!-- Add margin for spacing above the header -->
        <div align='center'>
            <h3 style='font-size: 20px; margin-bottom:0px; padding-top: 50px;' ><strong>TOWER TRANSIT SINGAPORE PTE. LTD. - QAR REPORT ({data['start']} - {data['end']})</strong></h3>
            <p style='font-size: 12px; margin-top: 10px;'>
                21 Bulim Drive, 
                Singapore 648170 
                <strong>Tel:</strong> 1800-248-0950; &nbsp;
                <strong>Fax:</strong> +65 1234 5678
            </p>
            <p style='font-size: 11px; margin: 0;margin-top: 10px;'>
                <strong>CUSTOMER:</strong> {asset.customer_name} &nbsp; 
                <strong>PROJECT:</strong> {asset.project} &nbsp; 
                <strong>ASSET GROUP:</strong> {asset.asset_group_name} &nbsp; 
                <strong>LOCATION:</strong> {asset.location}
            </p>
            <p style='font-size: 11px; margin: 0;margin-top: 10px;'>
                <strong>ASSET:</strong> {asset.name} ({asset.asset_item_code}) &nbsp; 
                - <strong>CATEGORY:</strong> {asset.category}
            </p>
            <hr style='margin: 20px 50px; padding: 0; border: 0; border-top: 1px solid #e6e3e3;'>

        </div>
    </div>
    """

    return header_str





def table_heading(checklist, frequency, headings, page_interval):
    header_str = '<thead><tr>'
    header_str += '<th style="width: 30px; font-size: 10px;">#</th>'
    header_str += '<th style="width: 400px; font-size: 10px; white-space: nowrap;">Checklist</th>'
    header_str += '<th style="width: 80px; font-size: 10px;">Frequency</th>'
    
    num_days = len(page_interval)
    
    # Adjust width based on the number of days in the page_interval
    if num_days == 1:
        cell_width = "100%"
    elif num_days <= 31:
        cell_width = f"{100 / num_days:.2f}%"  # Distribute width evenly
    else:
        cell_width = "3%"  # For more than 31 days, keep a fixed small width

    for heading in page_interval:
        header_str += f'<th style="width: {cell_width}; font-size: 10px; word-wrap: break-word;">{heading.strftime("%d %m %Y")}</th>'
    
    header_str += '</tr></thead>'
    return header_str

def table_rows(idx, checklist, frequency, asset_id, frequency_id, page_interval, ticket_model):
    query_params = {
        'asset_item_id': asset_id,
        'frequency_id': frequency_id,
        'ticket_type': 'PMT',
        'is_active': 1,
        'status': 1,
    }

    row_str = f'<tr><td style="font-size: 10px; text-align: center;">{idx}</td>'
    row_str += f'<td style="font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{checklist[:300]}</td>'
    row_str += f'<td style="font-size: 10px; text-align: center;">{frequency}</td>'
    
    num_days = len(page_interval)

    # Adjust each cell's width dynamically based on the number of days
    if num_days == 1:
        cell_width = "100%"
    elif num_days <= 31:
        cell_width = f"{100 / num_days:.2f}%"  # Distribute width evenly
    else:
        cell_width = "3%"  # Fixed small width for more than 31 days

    # Adjust for each date in the interval
    for date in page_interval:
        query_params['ticket_date'] = date.strftime('%Y-%m-%d')
        current_day = date.strftime('%a')  # Abbreviated weekday (e.g., 'Mon', 'Tue', ...)

        if current_day == 'Sun':
            row_str += f'<td style="background: #b1b1b1; font-size: 10px; text-align: center; width: {cell_width};">-</td>'
        else:
            count = ticket_model.objects.filter(**query_params).count()
            if count > 0:
                row_str += f'<td contenteditable="true" style="font-size: 10px; text-align: center; width: {cell_width};">1</td>'
            else:
                row_str += f'<td contenteditable="true" style="font-size: 10px; text-align: center; width: {cell_width};"></td>'

    row_str += '</tr>'
    return row_str





def qar_page_footer(data):
    asset = data['asset']  # Corrected from 'assets' to 'asset'
    
    # Try to get the technician; if not found, set to '-'
    try:
        technician = get_object_or_404(employee_table, id=asset.technician_id)
        technician_name = technician.name
    except:
        technician_name = '-'

    # Build the footer string
    footer_str = f'<p><strong>Serviced By: {technician_name}</strong></p>'
    return footer_str




# ```````correct final code``````````````

import shutil
import zipfile
from zipfile import ZipFile





def generate_qar_report(request):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        qar_report_directory = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports')
        log_directory = os.path.join(settings.MEDIA_ROOT, 'qar_log')
        if not os.path.exists(log_directory):
            os.makedirs(log_directory)

        task_id = f"qar_report_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        log_file_name = f"{task_id}.txt"
        log_file_path = os.path.join(log_directory, log_file_name)

        # Set up logging configuration
        logging.basicConfig(
            filename=log_file_path,
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

        logging.getLogger().handlers = []  # Remove default console handler
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logging.getLogger().addHandler(file_handler)

        
        # Logging example at the start
        logging.info("Starting QAR report generation.")
        

        if not os.path.exists(log_directory):
            os.makedirs(log_directory)

        

        selected_customer_id = request.POST.get('customer_id')
        selected_project_id = request.POST.get('project_id')
        report_start_date = request.POST.get('start_date')
        report_end_date = request.POST.get('end_date')
        month = request.POST.get('month')
        year = request.POST.get('year')
        print('month',month)
        print('year',year)

        projectname = getItemNameById(project_table, selected_project_id)
        projectname = projectname.replace(" ", "")  
       
        customername = getItemNameById(customer_table, selected_customer_id)
        customername = customername.replace(" ", "")  

       
        random_hex = os.urandom(4).hex()  
        task_id = f"{projectname}-{customername}{random_hex}" 

        if not os.path.exists(qar_report_directory):
            os.makedirs(qar_report_directory)
        
        logging.info("QAR report generation started.")
        try:            
            logging.info(f"QAR report generation started. Task ID: {task_id}")  
            generated_on_time = timezone.now().strftime('%H:%M:%S')   

            matching_tickets = ticket_list_table.objects.filter(
                customer_id=selected_customer_id,
                project_id=selected_project_id,
                ticket_date__range=(report_start_date, report_end_date),
                is_active=1,
                status=1,
                is_uploaded=1,
                ticket_status='completed'
            )  

            if not matching_tickets.exists():
                logging.warning("No matching tickets found in `ticket_list_table`. Skipping report generation.")
                qar_report_status_entry = qar_report_status(
                    task_id=task_id,
                    project_id=selected_project_id,
                    customer_id=selected_customer_id,
                    generated_by=user_id,
                    generated_on=timezone.now().strftime('%H:%M:%S'),
                    qar_status='skipped',
                    is_active=1,
                    month=month,
                    year=year,
                    created_on=timezone.now(),
                    updated_on=timezone.now(),
                    created_by=user_id,
                    updated_by=user_id,
                )
                qar_report_status_entry.save()
                return JsonResponse({'status': 'skipped', 'message': 'No matching records found. QAR report generation skipped.'})

            existing_qar_report = qar_report_status.objects.filter(
                month=month,
                year=year,
                project_id=selected_project_id,
                customer_id=selected_customer_id,
                qar_status='completed',                
            ).first()

            if existing_qar_report:
                existing_qar_report.status = 0
                existing_qar_report.save()
                logging.info(f"Updated existing QAR report status to 'inactive' for task_id={existing_qar_report.task_id}")

            qar_report_status_entry = qar_report_status(
                task_id=task_id,
                project_id=selected_project_id,
                customer_id=selected_customer_id,
                generated_by=user_id,
                generated_on=generated_on_time,
                qar_status='generating',
                is_active=1,
                month=month,
                year=year,
                created_on=timezone.now(),
                updated_on=timezone.now(),
                created_by=user_id,
                updated_by=user_id,
            )
            
            qar_report_status_entry.save()    
            logging.info("QAR report status saved.")    

            active_asset_groups = system_table.objects.filter(is_active=1, status=1, id=90).order_by('id')
            logging.info("active_asset_groups",active_asset_groups)
            qar_report_data = []

            for asset_group in active_asset_groups:
                associated_assets = asset_table.objects.filter(
                    asset_group_id=asset_group.id,
                    customer_id=selected_customer_id,
                    project_id=selected_project_id,
                    asset_parent_id=0,
                    status=1,
                ).order_by('id')

                for asset in associated_assets:
                    frequency_list = asset.frequency_id.split(',')

                    for frequency_id in frequency_list:
                        if frequency_id:
                            project_name = getItemNameById(project_table, asset.project_id)
                            asset_group_name = asset_group.name
                            frequency_name = getItemNameById(frequency_table, frequency_id)

                            report_entry = {
                                'frequency_id': frequency_id,
                                'frequency': frequency_name,
                                'asset_id': asset.id,
                                'customer_id': asset.customer_id,
                                'project_id': asset.project_id,
                                'project_name': project_name,
                                'asset_group_id': asset_group.id,
                                'asset_group_name': asset_group_name,
                                'year': parse_date(report_start_date).year if report_start_date else None,
                                'month': parse_date(report_start_date).month if report_start_date else None,
                            }
                            qar_report_data.append(report_entry)
                            logging.debug(f"Added report entry for asset_id={asset.id}")

            saved_records = []
            for report_entry in qar_report_data:
                new_record = {
                    'frequency_id': report_entry['frequency_id'],
                    'asset_id': report_entry['asset_id'],
                    'customer_id': report_entry['customer_id'],
                    'project_id': report_entry['project_id'],
                    'asset_group_id': report_entry['asset_group_id'],
                    'year': report_entry['year'],
                    'month': report_entry['month'],
                    'file_name': f"qar-{report_entry['project_name'].replace(' ', '')}-{report_entry['asset_group_name'].replace(' ', '')}-{report_entry['frequency'].replace(' ', '')}-{report_entry['month']}-{report_entry['year']}-{os.urandom(4).hex()}.pdf",
                    'created_on': timezone.now(),
                    'updated_on': timezone.now(),
                    'created_by': user_id,
                    'updated_by': user_id,
                    'task_id': task_id,
                    'qar_status':'generating',
                }
                logging.debug(f"Entry made in qr_track table")
                

                file_name_with_random = new_record['file_name']
                print(f"Generated file name with random hex: {file_name_with_random}")

                
                base_file_name = "-".join(file_name_with_random.split('-')[:-1]) + ".pdf"
                print(f"Base file name (without random part): {base_file_name}")

               
                for filename in os.listdir(qar_report_directory):
                    # Check if the file matches the base file name (ignore random part)
                    if filename.startswith(base_file_name[:-4]):  # Match the file prefix (ignores the random part)
                        existing_file_path = os.path.join(qar_report_directory, filename)
                        print(f"Existing file path: {existing_file_path}")

                        # Check if the file exists and remove it
                        if os.path.exists(existing_file_path):
                            print('***** FILE EXISTS')
                            os.remove(existing_file_path)
                            logging.info(f"Existing QAR file found and removed: {existing_file_path}")


                existing_count = qar_table.objects.filter(
                    frequency_id=report_entry['frequency_id'],
                    asset_id=report_entry['asset_id'],
                    asset_group_id=report_entry['asset_group_id'],
                    customer_id=report_entry['customer_id'],
                    project_id=report_entry['project_id'],
                    year=report_entry['year'],
                    month=report_entry['month'],
                    task_id =task_id,
                    qar_status='generating',
                    is_active=1,
                    status=1
                ).count()

                if existing_count > 0:
                    qar_table.objects.filter(
                        frequency_id=report_entry['frequency_id'],
                        asset_id=report_entry['asset_id'],
                        asset_group_id=report_entry['asset_group_id'],
                        customer_id=report_entry['customer_id'],
                        project_id=report_entry['project_id'],
                        year=report_entry['year'],
                        month=report_entry['month'],
                        task_id=task_id,
                        qar_status='generating'
                    ).update(is_active=0, status=0)
                    logging.info(f"Deactivated {existing_count} existing records for task_id={task_id}")

                created_record = qar_table.objects.create(**new_record)
                saved_records.append(created_record)
                logging.debug(f"Created new QAR record: {created_record.id}")

                store_qar_report(report_entry['asset_id'], report_entry['frequency_id'], report_entry['customer_id'], report_entry['project_id'], report_entry['asset_group_id'], new_record['file_name'], report_start_date, report_end_date, ticket_table)
                logging.info("store_qar_report called.")

                qar_tracks = qar_table.objects.filter(
                    is_active=1,
                    status=1,
                    customer_id=selected_customer_id,
                    project_id=selected_project_id,
                    year=report_entry['year'],
                    month=report_entry['month']
                ).values(
                    'year', 'month', 'customer_id', 'project_id', 'asset_group_id', 'frequency_id'
                ).order_by('asset_group_id').distinct()

                logging.info(f"Found {len(qar_tracks)} QAR tracks for the given filters.")

                for qar in qar_tracks:
                    asset_ids = qar_table.objects.filter(
                        year=qar['year'],
                        month=qar['month'],
                        customer_id=qar['customer_id'],
                        project_id=qar['project_id'],
                        asset_group_id=qar['asset_group_id'],
                        frequency_id=qar['frequency_id'],
                    ).values_list('asset_id', flat=True).order_by('asset_group_id')
                    logging.info(f"Found {len(asset_ids)} assets for asset group {qar['asset_group_id']}.")


                    project = project_table.objects.get(id=qar['project_id']).name.replace(' ', '')
                    
                    # Format month and year as "oct-2024"
                    month_year = parse_date(report_start_date).strftime('%b-%Y').lower()  # Get abbreviated month and year in lower case

                    datadir = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project, month_year)
                    os.makedirs(datadir, exist_ok=True)

                    asset_group = system_table.objects.get(id=qar['asset_group_id']).name.replace(' ', '')
                    
                    # Create directory for asset group
                    asset_group_dir = os.path.join(datadir, asset_group)
                    os.makedirs(asset_group_dir, exist_ok=True)

                    frequency = frequency_table.objects.get(id=qar['frequency_id']).name.replace(' ', '')
                    
                    # Create directory for frequency
                    frequency_dir = os.path.join(asset_group_dir, frequency)
                    os.makedirs(frequency_dir, exist_ok=True)

                    output_file_name = f"TTS_{asset_group}_{frequency}.pdf"
                    output_file_path = os.path.join(frequency_dir, output_file_name)

                    # Initialize PDF merger
                    merger = PdfMerger()
                    added_files = set()  # Track added files to avoid duplicates

                    # Fetch all relevant QAR records in one query
                    qar_tracks = qar_table.objects.filter(
                        frequency_id=qar['frequency_id'],
                        asset_group_id=qar['asset_group_id'],
                        customer_id=qar['customer_id'],
                        project_id=qar['project_id'],
                        is_active=1,
                        status=1
                    )
                    logging.info(f"Found {len(qar_tracks)} QAR tracks to merge.")

                        # Process all records matching the query for QAR files
                    for qar_track in qar_tracks:
                        file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', qar_track.file_name)
                        logging.info(f"Checking file: {file_path}")
                        if os.path.exists(file_path):
                            try:
                                with open(file_path, 'rb') as f:
                                    PdfReader(f)  # Validate if it's a PDF
                                merger.append(file_path)  # Append valid file
                                added_files.add(file_path) 
                                logging.info(f"Appended file {file_path} to the merger.")
                            except Exception as e:
                                logging.error(f"Failed to read or append PDF file {file_path}: {e}")
                        else:
                            logging.warning(f"File does not exist: {file_path}")

                
                    tickets = ticket_list_table.objects.filter(
                        frequency_id=qar['frequency_id'],
                        asset_group_id=qar['asset_group_id'],
                        customer_id=qar['customer_id'],
                        project_id=qar['project_id'],
                        is_active=1,
                        status=1,
                        is_uploaded=1,
                        ticket_status='completed',
                        ticket_date__range=(report_start_date, report_end_date)
                    ).order_by('ticket_date')
                    logging.info(f"Found {len(tickets)} tickets for the given date range.")

                        
                    

                    for ticket in tickets:
                        logging.info(f"Processing ticket file: {ticket.file_name}")
                        if ticket.file_name:  # Check if file name exists
                            ticket_file_path = os.path.join(settings.MEDIA_ROOT, ticket.file_name.name)
                            print('*****************ticket_file_path**************',ticket_file_path)
                            logging.info(f"Checking ticket file path: {ticket_file_path}")
                            
                            # Ensure the file exists in the specified path
                            if os.path.exists(ticket_file_path):
                                print('*************************************  CONDITION MET')
                                try:
                                    with open(ticket_file_path, 'rb') as f:
                                        PdfReader(f) 
                                    merger.append(ticket_file_path) 
                                    added_files.add(ticket_file_path)
                                    logging.info(f"Appended ticket file {ticket_file_path} to the merger.")
                                    print(f"Appended ticket file {ticket_file_path} to the merger.")
                                except Exception as e:
                                    logging.error(f"Failed to read or append ticket file {ticket_file_path}: {e}")
                            else:
                                logging.warning(f"File does not exist: {ticket_file_path}")
                        else:
                            logging.warning(f"Ticket has no associated file name.")

                    try:
                        with open(output_file_path, 'wb') as output_pdf:
                            merger.write(output_pdf)
                            logging.info(f"Saved merged PDF at {output_file_path}")                        
                            print(f"**********************Saved merged PDF at {output_file_path}")                        
                    except Exception as e:
                        logging.info(f"Failed to save merged PDF: {output_file_path}, Error: {e}")

                    merger.close()
                    updated_rows = qar_table.objects.filter(
                        frequency_id=qar['frequency_id'],
                        asset_group_id=qar['asset_group_id'],
                        customer_id=qar['customer_id'],
                        project_id=qar['project_id'],
                        is_active=1,
                        status=1
                    ).update(qar_status="completed")
                    logging.info(f"Updated {updated_rows} QAR tracks to 'completed' status.")

            month_year = datetime.strptime(report_start_date, "%Y-%m-%d").strftime('%b-%Y').lower()
            project_name = project_table.objects.get(id=selected_project_id).name.replace(' ', '')
            month_year_directory = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, month_year)
            zip_file_name = f"{project_name}{month_year}.zip"
            zip_file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, zip_file_name)
            with ZipFile(zip_file_path, 'w') as zipf:
                for root, _, files in os.walk(month_year_directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zipf.write(file_path, os.path.relpath(file_path, os.path.join(month_year_directory, '..')))
            shutil.rmtree(month_year_directory)

            zip_file_url = os.path.join(settings.MEDIA_URL, 'uploads', 'qar_reports', project_name, zip_file_name)
            qar_report_status_entry.qar_status = 'completed'
            qar_report_status_entry.updated_by = user_id
            qar_report_status_entry.updated_on = timezone.now()
            qar_report_status_entry.file = zip_file_url
            qar_report_status_entry.save()


            return JsonResponse({
                "message": "QAR report generated successfully.",
                "zip_file_path": zip_file_url,  # Include the path to the zip file
            })

        except Exception as e:
            qar_report_status_entry.qar_status = "interrupted"
            # qar_report_status_entry.status = 0
            qar_report_status_entry.save()
            logging.error(f"Error during QAR report generation: {e}")
            print(f"Error during QAR report generation: {e}")
            return JsonResponse({'status': 'error', 'message': 'An error occurred during QAR report generation.'})



import os
import logging
from datetime import datetime
from django.conf import settings
from django.utils import timezone
from django.http import JsonResponse
from PyPDF2 import PdfMerger
import shutil

# def generate_qar_report(request):
#     if request.method == 'POST':
#         # Set up logging to file, not the console
#         log_directory = os.path.join(settings.MEDIA_ROOT, 'qar_log')
#         if not os.path.exists(log_directory):
#             os.makedirs(log_directory)

#         # Generate a unique log file name with task ID
#         task_id = f"qar_report_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
#         log_file_name = f"{task_id}.txt"
#         log_file_path = os.path.join(log_directory, log_file_name)

#         # Set up logging configuration
#         logging.basicConfig(
#             filename=log_file_path,
#             level=logging.DEBUG,
#             format='%(asctime)s - %(levelname)s - %(message)s'
#         )

#         try:
#             logging.info(f"QAR report generation started. Task ID: {task_id}")
#             user_id = request.session.get('user_id')
#             qar_report_directory = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports')

#             if not os.path.exists(qar_report_directory):
#                 os.makedirs(qar_report_directory)

#             selected_customer_id = request.POST.get('customer_id')
#             selected_project_id = request.POST.get('project_id')
#             report_start_date = request.POST.get('start_date')
#             report_end_date = request.POST.get('end_date')
#             month = request.POST.get('month')
#             year = request.POST.get('year')
#             logging.debug(f"Received parameters: month={month}, year={year}")

#             # Fetch project and customer names
#             projectname = getItemNameById(project_table, selected_project_id).replace(" ", "")
#             customername = getItemNameById(customer_table, selected_customer_id).replace(" ", "")

#             random_hex = os.urandom(4).hex()
#             task_id = f"{projectname}-{customername}{random_hex}"
            
#             # Save the initial QAR report status
#             qar_report_status_entry = qar_report_status(
#                 task_id=task_id,
#                 project_id=selected_project_id,
#                 customer_id=selected_customer_id,
#                 generated_by=user_id,
#                 generated_on=timezone.now(),
#                 qar_status='generating',
#                 is_active=1,
#                 month=month,
#                 year=year,
#                 created_on=timezone.now(),
#                 updated_on=timezone.now(),
#                 created_by=user_id,
#                 updated_by=user_id
#             )
#             qar_report_status_entry.save()
#             logging.info("QAR report status saved.")

#             # Collecting QAR report data
#             active_asset_groups = system_table.objects.filter(is_active=1, status=1, id=24).order_by('id')
#             qar_report_data = []

#             for asset_group in active_asset_groups:
#                 associated_assets = asset_table.objects.filter(
#                     asset_group_id=asset_group.id,
#                     customer_id=selected_customer_id,
#                     project_id=selected_project_id,
#                     asset_parent_id=0,
#                     status=1,
#                 ).order_by('id')

#                 for asset in associated_assets:
#                     frequency_list = asset.frequency_id.split(',')

#                     for frequency_id in frequency_list:
#                         if frequency_id:
#                             project_name = getItemNameById(project_table, asset.project_id)
#                             asset_group_name = asset_group.name
#                             frequency_name = getItemNameById(frequency_table, frequency_id)

#                             report_entry = {
#                                 'frequency_id': frequency_id,
#                                 'frequency': frequency_name,
#                                 'asset_id': asset.id,
#                                 'customer_id': asset.customer_id,
#                                 'project_id': asset.project_id,
#                                 'project_name': project_name,
#                                 'asset_group_id': asset_group.id,
#                                 'asset_group_name': asset_group_name,
#                                 'year': parse_date(report_start_date).year if report_start_date else None,
#                                 'month': parse_date(report_start_date).month if report_start_date else None,
#                             }
#                             qar_report_data.append(report_entry)
#                             logging.debug(f"Added report entry for asset_id={asset.id}")

#             # Save report data to the database and handle QAR records
#             saved_records = []
#             for report_entry in qar_report_data:
#                 new_record = {
#                     'frequency_id': report_entry['frequency_id'],
#                     'asset_id': report_entry['asset_id'],
#                     'customer_id': report_entry['customer_id'],
#                     'project_id': report_entry['project_id'],
#                     'asset_group_id': report_entry['asset_group_id'],
#                     'year': report_entry['year'],
#                     'month': report_entry['month'],
#                     'file_name': f"qar-{report_entry['project_name'].replace(' ', '')}-{report_entry['asset_group_name'].replace(' ', '')}-{report_entry['frequency'].replace(' ', '')}-{report_entry['month']}-{report_entry['year']}-{os.urandom(4).hex()}.pdf",
#                     'created_on': timezone.now(),
#                     'updated_on': timezone.now(),
#                     'created_by': user_id,
#                     'updated_by': user_id,
#                     'task_id': task_id,
#                     'qar_status': 'generating',
#                 }

#                 # Check for existing records and deactivate them if necessary
#                 existing_count = qar_table.objects.filter(
#                     frequency_id=report_entry['frequency_id'],
#                     asset_id=report_entry['asset_id'],
#                     asset_group_id=report_entry['asset_group_id'],
#                     customer_id=report_entry['customer_id'],
#                     project_id=report_entry['project_id'],
#                     year=report_entry['year'],
#                     month=report_entry['month'],
#                     task_id=task_id,
#                     qar_status='generating',
#                     is_active=1,
#                     status=1
#                 ).count()

#                 if existing_count > 0:
#                     qar_table.objects.filter(
#                         frequency_id=report_entry['frequency_id'],
#                         asset_id=report_entry['asset_id'],
#                         asset_group_id=report_entry['asset_group_id'],
#                         customer_id=report_entry['customer_id'],
#                         project_id=report_entry['project_id'],
#                         year=report_entry['year'],
#                         month=report_entry['month'],
#                         task_id=task_id,
#                         qar_status='generating'
#                     ).update(is_active=0, status=0)
#                     logging.info(f"Deactivated {existing_count} existing records for task_id={task_id}")

#                 created_record = qar_table.objects.create(**new_record)
#                 saved_records.append(created_record)
#                 logging.debug(f"Created new QAR record: {created_record.id}")

#                 store_qar_report(report_entry['asset_id'], report_entry['frequency_id'], report_entry['customer_id'], report_entry['project_id'], report_entry['asset_group_id'], new_record['file_name'], report_start_date, report_end_date, ticket_table)
#                 logging.info("store_qar_report called.")

#                 qar_tracks = qar_table.objects.filter(
#                     is_active=1,
#                     status=1,
#                     customer_id=selected_customer_id,
#                     project_id=selected_project_id,
#                     year=report_entry['year'],
#                     month=report_entry['month']
#                 ).values(
#                     'year', 'month', 'customer_id', 'project_id', 'asset_group_id', 'frequency_id'
#                 ).order_by('asset_group_id').distinct()

#                 logging.info(f"Found {len(qar_tracks)} QAR tracks for the given filters.")


#                 for qar in qar_tracks:
#                     logging.info(f"Processing QAR track: {qar}")

#                     asset_ids = qar_table.objects.filter(
#                         year=qar['year'],
#                         month=qar['month'],
#                         customer_id=qar['customer_id'],
#                         project_id=qar['project_id'],
#                         asset_group_id=qar['asset_group_id'],
#                         frequency_id=qar['frequency_id'],
#                     ).values_list('asset_id', flat=True).order_by('asset_group_id')
#                     logging.info(f"Found {len(asset_ids)} assets for asset group {qar['asset_group_id']}.")

#                 project = project_table.objects.get(id=qar['project_id']).name.replace(' ', '')
                
#                 month_year = parse_date(report_start_date).strftime('%b-%Y').lower()
                
#                 datadir = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project, month_year)
                
#                 os.makedirs(datadir, exist_ok=True)
                
#                 asset_group = system_table.objects.get(id=qar['asset_group_id']).name.replace(' ', '')
                
#                 asset_group_dir = os.path.join(datadir, asset_group)
                
#                 os.makedirs(asset_group_dir, exist_ok=True)

#                 frequency = frequency_table.objects.get(id=qar['frequency_id']).name.replace(' ', '')
                
#                 frequency_dir = os.path.join(asset_group_dir, frequency)
                
#                 os.makedirs(frequency_dir, exist_ok=True)

#                 output_file_name = f"PM_{asset_group}_{frequency}.pdf"

#                 output_file_path = os.path.join(frequency_dir, output_file_name)

#                 merger = PdfMerger()
#                 added_files = set() 

#                 qar_tracks = qar_table.objects.filter(
#                     frequency_id=qar['frequency_id'],
#                     asset_group_id=qar['asset_group_id'],
#                     customer_id=qar['customer_id'],
#                     project_id=qar['project_id'],
#                     is_active=1,
#                     status=1
#                 )
#                 logging.info(f"Found {len(qar_tracks)} QAR tracks to merge.")

#                 for qar_track in qar_tracks:
#                     file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', qar_track.file_name)
#                     logging.info(f"Checking file: {file_path}")
#                     if os.path.exists(file_path):
#                         try:
#                             with open(file_path, 'rb') as f:
#                                 PdfReader(f)  # Validate if it's a PDF
#                             merger.append(file_path)  # Append valid file
#                             added_files.add(file_path)  # Mark this file as added
#                             logging.info(f"Appended file {file_path} to the merger.")
#                         except Exception as e:
#                             logging.error(f"Failed to read or append PDF file {file_path}: {e}")
#                     else:
#                         logging.warning(f"File does not exist: {file_path}")

#                 tickets = ticket_list_table.objects.filter(
#                     frequency_id=qar['frequency_id'],
#                     asset_group_id=qar['asset_group_id'],
#                     customer_id=qar['customer_id'],
#                     project_id=qar['project_id'],
#                     is_active=1,
#                     status=1,
#                     is_uploaded=1,
#                     ticket_status='completed',
#                     ticket_date__range=(report_start_date, report_end_date)
#                 ).order_by('ticket_date')

#                 logging.info(f"Found {len(tickets)} tickets for the given date range.")



#                 for ticket in tickets:
#                     ticket_file_path = os.path.join(settings.MEDIA_ROOT, 'file', ticket.file_name)
#                     logging.info(f"Checking ticket file: {ticket_file_path}")
#                     if ticket.file_name and os.path.exists(ticket_file_path):
#                         try:
#                             with open(ticket_file_path, 'rb') as f:
#                                 PdfReader(f)  # Validate if it's a PDF
#                             merger.append(ticket_file_path)  # Append valid file
#                             added_files.add(ticket_file_path)  # Mark this file as added
#                             logging.info(f"Appended ticket file {ticket_file_path} to the merger.")
#                         except Exception as e:
#                             logging.error(f"Failed to read or append ticket file {ticket_file_path}: {e}")
#                     else:
#                         logging.warning(f"Ticket file not found or not valid: {ticket_file_path}")


#                 try:
#                     with open(output_file_path, 'wb') as output_pdf:
#                         merger.write(output_pdf)
#                     logging.info(f"Saved merged PDF at {output_file_path}")
#                 except Exception as e:
#                     logging.error(f"Failed to save merged PDF: {output_file_path}, Error: {e}")

#                 merger.write(output_file_path)
#                 merger.close()

#                 updated_rows = qar_table.objects.filter(
#                     frequency_id=qar['frequency_id'],
#                     asset_group_id=qar['asset_group_id'],
#                     customer_id=qar['customer_id'],
#                     project_id=qar['project_id'],
#                     is_active=1,
#                     status=1
#                 ).update(qar_status="completed")

#                 logging.info(f"Updated {updated_rows} QAR tracks to 'completed' status.")

#             month_year = datetime.strptime(report_start_date, "%Y-%m-%d").strftime('%b-%Y').lower()
#             project_name = project_table.objects.get(id=selected_project_id).name.replace(' ', '')
#             month_year_directory = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, month_year)
#             zip_file_name = f"{month_year}.zip"
#             zip_file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, zip_file_name)
            
#             with ZipFile(zip_file_path, 'w') as zipf:
#                 for root, _, files in os.walk(month_year_directory):
#                     for file in files:
#                         file_path = os.path.join(root, file)
#                         zipf.write(file_path, os.path.relpath(file_path, os.path.join(month_year_directory, '..')))
            
#             shutil.rmtree(month_year_directory)

#             zip_file_url = os.path.join(settings.MEDIA_URL, 'uploads', 'qar_reports', project_name, zip_file_name)
#             qar_report_status_entry.qar_status = 'completed'
#             qar_report_status_entry.file = zip_file_url
#             qar_report_status_entry.save()

#             logging.info("QAR report generation completed successfully.")

#             return JsonResponse({
#                 'status': 'success',
#                 'message': 'QAR report generation started.'
#             })

#         except Exception as e:
#             logging.error(f"Error during QAR report generation: {e}")
#             return JsonResponse({'status': 'error', 'message': 'An error occurred during QAR report generation.'})


def qar_view(request):
    customer_id = request.POST.get('customer')
    project_id = request.POST.get('project')
    month = request.POST.get('month')
    year = request.POST.get('year')

    

    query = Q(status=1)

    if customer_id.isdigit():
        query &= Q(customer_id=customer_id)
        print('query', query)

    if project_id and project_id.isdigit():
        query &= Q(project_id=project_id)
        print('query', query)

    if month:
        query &= Q(month=month)
        print('query', query)

    if year:
        query &= Q(year=year)
        print('query', query)

    assets = qar_report_status.objects.filter(query).order_by('-id')
    print('assets', assets.count())

    data = []
    files_available = False  
    for index, item in enumerate(assets):        
        file_name = item.file if item.file else None
        print('file_name', file_name)

        # Check if file_name exists and set files_available accordingly
        if file_name:
            files_available = True
            # Ensure the file name is properly formatted for URLs
            file_name = file_name.replace('\\', '/')  # Replace backslashes with forward slashes

            # Prepare the download button
            download_button = f'''
                <button type="button" onclick="downloadFile('{file_name}')" class="btn btn-outline-primary btn-xs">
                    <i class="feather icon-download"></i> Download
                </button>
            '''
        else:
            
            download_button = '' 

        delete_button = f'''
            <button type="button" onclick="delete_qar('{item.id}')" class="btn btn-outline-danger btn-xs">
                <i class="feather icon-trash-2"></i> Delete
            </button>
        '''

        formatted_item = {
            'id': index + 1,
            'month':(item.month or '') + '/' + (item.year or ''),
            'time':item.generated_on,
            'action': f"""{download_button}{delete_button}""",  # Combine download and regenerate buttons
            'customer': getItemNameById(customer_table, item.customer_id) if item.customer_id else '-',
            'project': getItemNameById(project_table, item.project_id) if item.project_id else '-',
            'status': f'<span class="badge text-bg-{qar_status_color(item.qar_status)}" style="font-size:10pt;">{item.qar_status}</span>',
            'file_available': bool(file_name),  # Use file_name to set availability
            'file_url': file_name if file_name else ''  # Include file URL if available
        }
        data.append(formatted_item)

    return JsonResponse({'data': data, 'files_available': files_available})



def regenerateFile(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == "POST":
         frm = request.POST
    data = qar_report_status.objects.filter(id=request.POST.get('id'))    
    return JsonResponse(data.values()[0])



def qar_status_color(status):
    # Use the 'status' field from the passed argument, which should be 'item.qar_status'
    status = status.lower()  # Normalize status to lower case
    if status == 'generating':
        return 'warning'
    elif status == 'completed':
        return 'success'    
    else:
        return 'secondary'


def download_zip(zip_file_path, zip_file_name):
    if os.path.exists(zip_file_path):
        return FileResponse(open(zip_file_path, 'rb'), as_attachment=True, filename=zip_file_name)
    else:
        # Handle file not found
        return HttpResponseNotFound("File not found.")




import os
import shutil
from django.http import JsonResponse
from django.utils import timezone
from .models import qar_report_status, project_table  # Assuming you have these imports

import os
import shutil
from django.http import JsonResponse
from django.utils import timezone

import os
import shutil
from django.http import JsonResponse
from django.utils import timezone
from .models import qar_report_status
from django.conf import settings

import os
import shutil
from datetime import datetime
from django.http import JsonResponse
from django.utils import timezone
from .models import qar_report_status
from django.conf import settings

import os
import shutil
from datetime import datetime
from django.http import JsonResponse
from django.utils import timezone
from django.conf import settings

def delete_qar(request):
    if request.method == 'POST':
        data_id = request.POST.get('id')
        user_id = request.session.get('user_id')

        print('Received data_id:', data_id)
        print('User ID from session:', user_id)

        try:
            qar_report = qar_report_status.objects.get(id=data_id)
            file_path = qar_report.file  
            file_name = os.path.basename(file_path)
            project_name = getItemNameById(project_table, qar_report.project_id).replace(" ", "")
            month_year = qar_report.month.lower() + "-" + str(qar_report.year)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            zip_file_url = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, file_name)
            qar_report_directory = os.path.join(settings.MEDIA_ROOT, 'uploads', 'qar_reports', project_name, month_year)

            backup_directory = os.path.join(settings.MEDIA_ROOT, 'backup', 'qar_reports')
            if not os.path.exists(backup_directory):
                os.makedirs(backup_directory)  

            if os.path.isfile(zip_file_url):
                backup_file_path = os.path.join(backup_directory, f"{project_name}-{timestamp}-{file_name}")
                shutil.move(zip_file_url, backup_file_path)
                print('File successfully moved to backup:', backup_file_path)
            elif os.path.isdir(zip_file_url):
                print('The specified path is a directory, not a file:', zip_file_url)
            else:
                print('File does not exist:', zip_file_url)

            if os.path.exists(qar_report_directory) and os.path.isdir(qar_report_directory):
                backup_directory_path = os.path.join(backup_directory, f"{project_name}-{timestamp}-{month_year}")
                shutil.move(qar_report_directory, backup_directory_path)
                print('qar_report_directory successfully moved to backup:', backup_directory_path)
            else:
                print('qar_report_directory does not exist or is not a directory')

            qar_report.status = 0
            qar_report.file = ''
            qar_report.updated_on = timezone.now()
            qar_report.updated_by = user_id
            qar_report.save()

            print('qar_report updated successfully')
            return JsonResponse({'message': 'yes'})

        except qar_report_status.DoesNotExist:
            print(f'qar_report with id {data_id} does not exist')
            return JsonResponse({'message': 'no such data'})

    else:
        print('Invalid request method')
        return JsonResponse({'message': 'Invalid request method'})


#`````````````````````````````````````````````GENERATE QAR USING CELERY```````````````````````````````````````````````````````

# from .tasks import generate_qar_report_task

# def generate_qar_report(request):
#     if request.method == 'POST':
#         user_id = request.session.get('user_id')  # Get the logged-in user's ID
#         selected_customer_id = request.POST.get('customer_id')
#         selected_project_id = request.POST.get('project_id')
#         report_start_date = request.POST.get('start_date')
#         report_end_date = request.POST.get('end_date')

#         print("User ID:", user_id)
#         print("Selected Customer ID:", selected_customer_id)
#         print("Selected Project ID:", selected_project_id)
#         print("Report Start Date:", report_start_date)
#         print("Report End Date:", report_end_date)

#         try:
#             # Create the task
#             task = generate_qar_report_task.apply_async(args=[user_id, selected_customer_id, selected_project_id, report_start_date, report_end_date])

#             # Save the task ID in the TaskStatus table
#             TaskStatus.objects.create(
#                 user_id=user_id,
#                 task_id=task.id,  # Store the task ID from the Celery task
#                 status='PENDING',
#                 created_on=timezone.now(),
#                 # updated_on=timezone.now(),
#                 project_id=selected_project_id
#             )

#             print(f"Task created with ID: {task.id}")

#         except Exception as e:
#             print(f"Error initiating report generation: {e}")
#             return render(request, 'report_status.html', {'error': str(e)})

#     return render(request, 'report_status.html')  # Or wherever the form for generating reports is located

def report_status_view(request):
    tasks = TaskStatus.objects.filter(user=user_id).order_by('-created_on')    
    return render(request, 'report_status.html', {
        'tasks': tasks,
    })

   
def qar_report_completed(request):
    return render(request, 'success.html')


import os
import zipfile
from django.http import HttpResponse
from django.shortcuts import render  # Import if you need to render templates or handle other views

# def zip_folder(source_directory, output_zip_file):
#     """Zips the specified folder and returns the path to the created zip file."""
#     try:
#         with zipfile.ZipFile(output_zip_file, 'w', zipfile.ZIP_DEFLATED) as zip_file:
#             for root, dirs, files in os.walk(source_directory):
#                 for file in files:
#                     file_path = os.path.join(root, file)
#                     # Write the file to the zip file, using relative path
#                     zip_file.write(file_path, os.path.relpath(file_path, os.path.dirname(source_directory)))
#         return output_zip_file
#     except Exception as e:
#         print(f"Error zipping folder: {e}")
#         return None

# def download_zip(request):
#     source_directory = 'D:/CODEBASE/facility_management/media/uploads/qar_reports/YishunInterchange/oct-2024' 
#     output_zip_file = 'D:/CODEBASE/facility_management/media/uploads/qar_reports/YishunInterchange/oct-2024.zip'  # Name your output zip file

#     # Create the zip file
#     zip_path = zip_folder(source_directory, output_zip_file)
    
#     if zip_path and os.path.exists(zip_path):
#         with open(zip_path, 'rb') as zip_file:
#             response = HttpResponse(zip_file.read(), content_type='application/zip')
#             response['Content-Disposition'] = f'attachment; filename={os.path.basename(zip_path)}'
        
#         # After serving the file, remove the source directory
#         try:
#             for root, dirs, files in os.walk(source_directory, topdown=False):
#                 for name in files:
#                     os.remove(os.path.join(root, name))
#                 for name in dirs:
#                     os.rmdir(os.path.join(root, name))
#             os.rmdir(source_directory)  # Remove the top-level directory
#         except Exception as e:
#             print(f"Error removing directory: {e}")

#         return response
#     else:
#         return HttpResponse("Error: Unable to create the zip file.")



# ```````````````````````````````````````WOBI FILES````````````````````````````````````````````````````

import csv
from django.http import HttpResponse
from datetime import datetime, timedelta
from django.db.models import Q

def export_ticket_data(request):
    filters = {
        'is_active': 1,
        'status': 1,
        'ticket_status': 'Completed',
    }
    
    ticket_data = ticket_summary_table.objects.filter(Q(**filters))

    if 'summary_start_date' in request.POST and 'summary_end_date' in request.POST:
        ticket_data = ticket_data.filter(
            ticket_date__gte=request.POST['summary_start_date'],
            ticket_date__lte=request.POST['summary_end_date']
        )
        print('summary_start_date',request.POST['summary_start_date'])
        print('summary_end_date',request.POST['summary_end_date'])

    if 'customer_id' in request.POST:
        ticket_data = ticket_data.filter(customer_id=request.POST['customer_id'])
    
    response = HttpResponse(content_type='text/csv')
    file_name = f"TTS_WOBI_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
    response['Content-Disposition'] = f'attachment; filename="{file_name}"'
    writer = csv.writer(response)
    writer.writerow(["BMMSINBOUND|WOBI|", datetime.now().strftime('%Y%m%d%H%M%S'), ticket_data.count()])
    writer.writerow(["PTO_WRK_ORDR_NUM", "ASSET_SYS_SR_NUM", "EXIST_CMPNT_SR_NUM", "JOB_TYP", 
                     "SUB_TYP", "REPAIR_CHIT_NUM", "OPR_TECHN", "STR_DT_TM", "END_DT_TM", 
                     "LABOR_HRS", "NEW_CMPNT_SR_NUM", "ADT_REF", "PROB_CD", "NOTES"])
    
    # Inside your CSV generation logic
    for ticket in ticket_data:
        try:
            start_time = ticket.start_time if ticket.start_time != '0000-00-00 00:00:00' else None
            end_time = ticket.end_time if ticket.end_time != '0000-00-00 00:00:00' else None
            
            if start_time is None or end_time is None:
                print(f"Skipping ticket {ticket.id} due to invalid start or end time.")
                continue
            
            if isinstance(start_time, str):
                start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
            
            if isinstance(end_time, str):
                end_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')

            ticket_instance = ticket_table.objects.get(id=ticket.id)
            
            # Attempt to fetch project_data, handling missing projects gracefully
            try:
                project_data = project_table.objects.get(id=ticket_instance.project_id)
            except project_table.DoesNotExist:
                print(f"Project not found for ticket {ticket.id}. Assigning default project.")
                project_data = None  # or use a placeholder like '-'

            try:
                total_time = int(ticket.total_time) if isinstance(ticket.total_time, str) else ticket.total_time
                
                if total_time != 0:
                    total_hours = datetime.utcfromtimestamp(total_time).strftime('%H:%M:%S')
                else:
                    total_hours = datetime.strptime(ticket_instance.total_hrs, '%H:%M:%S').strftime('%H:%M:%S')
            except ValueError:
                total_hours = '00:00:00'
            
            # Process ticket information
            PTO_WRK_ORDR_NUM = ticket.ticket_no
            ASSET_SYS_SR_NUM = (f"{ticket.asset_group_code}_{project_data.prefix}" if project_data else ticket.asset_group_code)
            EXIST_CMPNT_SR_NUM = ticket.asset_group_code
            JOB_TYP = ticket.job_type
            SUB_TYP = 'CM-BKD' if JOB_TYP == 'CMT' else ticket.frequency_code
            
            REPAIR_CHIT_NUM = ticket.ticket_no
            OPR_TECHN = ticket.technician_name
            STR_DT_TM = f"{ticket.ticket_date} {start_time.strftime('%H:%M:%S')}"
            
            if end_time and end_time.time() > start_time.time():
                END_DT_TM = f"{ticket.ticket_date} {end_time.strftime('%H:%M:%S')}"
            else:
                END_DT_TM = f"{(ticket.ticket_date + timedelta(days=1)).strftime('%Y-%m-%d')} {end_time.strftime('%H:%M:%S')}"
            
            LABOR_HRS = total_hours
            NEW_CMPNT_SR_NUM = ""
            ADT_REF = ""
            PROB_CD = ""
            
            # Process notes
            notes = ticket.remarks or ""
            if ticket.description:
                notes += f".{ticket.description}" if notes else ticket.description
            if ticket.action:
                notes += f".{ticket.action}" if notes else ticket.action
            
            notes = notes.replace("\r", "").replace("\n", "")
            if len(notes) > 1000:
                notes = notes[:999]
            
            row = [PTO_WRK_ORDR_NUM, ASSET_SYS_SR_NUM, EXIST_CMPNT_SR_NUM, JOB_TYP, SUB_TYP,
                   REPAIR_CHIT_NUM, OPR_TECHN, STR_DT_TM, END_DT_TM, LABOR_HRS,
                   NEW_CMPNT_SR_NUM, ADT_REF, PROB_CD, notes or "."]
            
            writer.writerow(row)  # Directly write the row to CSV
        
        except (ValueError, ValidationError) as e:
            print(f"Error processing ticket {ticket.id}: {str(e)}")  # Print the error message if any exception occurs

    return response



from django.http import JsonResponse, HttpResponse
from django.utils.timezone import localtime, now
from rest_framework.decorators import api_view
from django.core.exceptions import ValidationError
import os
import csv
from datetime import timedelta
from django.conf import settings
from django.utils import timezone
from datetime import datetime

import shutil

# Utility function to get yesterday's date
def get_yesterday_date():
    yesterday = localtime(now()) - timedelta(days=1)
    return yesterday.date()

# Utility function to check and create directory if it doesn't exist
def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)

# The main API view to export ticket data
@api_view(['POST'])
def export_ticket_data_api(request):
    # Get yesterday's date automatically
    yesterday = get_yesterday_date()

    # Filters for active tickets
    filters = {
        'is_active': 1,
        'status': 1,
        'ticket_status': 'Completed',
    }
    
    # Apply filters and dates
    ticket_data = ticket_summary_table.objects.filter(Q(**filters))

    if 'summary_start_date' in request.POST and 'summary_end_date' in request.POST:
        ticket_data = ticket_data.filter(
            ticket_date__gte=request.POST['summary_start_date'],
            ticket_date__lte=request.POST['summary_end_date']
        )
        print('summary_start_date', request.POST['summary_start_date'])
        print('summary_end_date', request.POST['summary_end_date'])

    if 'customer_id' in request.POST:
        ticket_data = ticket_data.filter(customer_id=request.POST['customer_id'])

    # Create a directory for WOBI files if it doesn't exist
    export_directory = os.path.join(settings.MEDIA_ROOT, 'wobi', f'{yesterday}')
    create_directory(export_directory)

    # Prepare CSV file path
    file_name = f"TTS_WOBI_{yesterday.strftime('%Y%m%d')}.csv"
    file_path = os.path.join(export_directory, file_name)

    # Writing CSV file
    with open(file_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        writer.writerow(["BMMSINBOUND|WOBI|", datetime.now().strftime('%Y%m%d%H%M%S'), ticket_data.count()])
        writer.writerow(["PTO_WRK_ORDR_NUM", "ASSET_SYS_SR_NUM", "EXIST_CMPNT_SR_NUM", "JOB_TYP", 
                         "SUB_TYP", "REPAIR_CHIT_NUM", "OPR_TECHN", "STR_DT_TM", "END_DT_TM", 
                         "LABOR_HRS", "NEW_CMPNT_SR_NUM", "ADT_REF", "PROB_CD", "NOTES"])

        for ticket in ticket_data:
            try:
                start_time = ticket.start_time if ticket.start_time != '0000-00-00 00:00:00' else None
                end_time = ticket.end_time if ticket.end_time != '0000-00-00 00:00:00' else None

                if start_time is None or end_time is None:
                    print(f"Skipping ticket {ticket.id} due to invalid start or end time.")
                    continue

                if isinstance(start_time, str):
                    start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')

                if isinstance(end_time, str):
                    end_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')

                ticket_instance = ticket_table.objects.get(id=ticket.id)

                try:
                    project_data = project_table.objects.get(id=ticket_instance.project_id)
                except project_table.DoesNotExist:
                    print(f"Project not found for ticket {ticket.id}. Assigning default project.")
                    project_data = None  # Default to None if project not found

                try:
                    total_time = int(ticket.total_time) if isinstance(ticket.total_time, str) else ticket.total_time

                    if total_time != 0:
                        total_hours = datetime.utcfromtimestamp(total_time).strftime('%H:%M:%S')
                    else:
                        total_hours = datetime.strptime(ticket_instance.total_hrs, '%H:%M:%S').strftime('%H:%M:%S')
                except ValueError:
                    total_hours = '00:00:00'

                PTO_WRK_ORDR_NUM = ticket.ticket_no
                ASSET_SYS_SR_NUM = (f"{ticket.asset_group_code}_{project_data.prefix}" if project_data else ticket.asset_group_code)
                EXIST_CMPNT_SR_NUM = ticket.asset_group_code
                JOB_TYP = ticket.job_type
                SUB_TYP = 'CM-BKD' if JOB_TYP == 'CMT' else ticket.frequency_code

                REPAIR_CHIT_NUM = ticket.ticket_no
                OPR_TECHN = ticket.technician_name
                STR_DT_TM = f"{ticket.ticket_date} {start_time.strftime('%H:%M:%S')}"

                if end_time and end_time.time() > start_time.time():
                    END_DT_TM = f"{ticket.ticket_date} {end_time.strftime('%H:%M:%S')}"
                else:
                    END_DT_TM = f"{(ticket.ticket_date + timedelta(days=1)).strftime('%Y-%m-%d')} {end_time.strftime('%H:%M:%S')}"

                LABOR_HRS = total_hours
                NEW_CMPNT_SR_NUM = ""
                ADT_REF = ""
                PROB_CD = ""

                notes = ticket.remarks or ""
                if ticket.description:
                    notes += f".{ticket.description}" if notes else ticket.description
                if ticket.action:
                    notes += f".{ticket.action}" if notes else ticket.action

                notes = notes.replace("\r", "").replace("\n", "")
                if len(notes) > 1000:
                    notes = notes[:999]

                row = [PTO_WRK_ORDR_NUM, ASSET_SYS_SR_NUM, EXIST_CMPNT_SR_NUM, JOB_TYP, SUB_TYP,
                       REPAIR_CHIT_NUM, OPR_TECHN, STR_DT_TM, END_DT_TM, LABOR_HRS,
                       NEW_CMPNT_SR_NUM, ADT_REF, PROB_CD, notes or "."]
                writer.writerow(row)

            except (ValueError, ValidationError) as e:
                print(f"Error processing ticket {ticket.id}: {str(e)}")

    return JsonResponse({"message": "CSV export successful", "file_path": file_path})



# ```````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
























# `````````````````````````````````````````````API VIEWS``````````````````````````````````````````````

from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response
from .serializers import EmployeeSerializer, AssetSerializer
from rest_framework.decorators import api_view
from rest_framework import generics
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from django.contrib.auth.hashers import make_password, check_password
from .models import *
from rest_framework_simplejwt.authentication import JWTAuthentication
from django_filters import rest_framework as filters
from django.contrib.auth.models import User
from .serializers import *
from .serializers import TicketSerializer  
from django.views.decorators.csrf import csrf_exempt
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from django.conf import settings
from hashlib import md5
from rest_framework import status
from django.utils import timezone
from django.db.models import Count
from datetime import datetime, timedelta
from django.utils.timezone import make_aware
import calendar
from datetime import datetime
from django.db.models import Count, Q
import uuid
from django.utils.crypto import get_random_string
import random
import requests
from requests.exceptions import RequestException
from django.core.mail import EmailMessage, get_connection,send_mail





from rest_framework_simplejwt.tokens import AccessToken
from rest_framework.exceptions import AuthenticationFailed


from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.response import Response
import hashlib

from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.response import Response
import hashlib

from django.utils import timezone
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
import hashlib

# LOGIN
class LoginView(APIView):
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        device_id = request.data.get('device_id')
        fcm_token = request.data.get('fcm_token')

        # Validation checks
        if not email or not isinstance(email, str):
            return Response({'error': 'Valid email is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        if password is None:
            return Response({'error': 'Password is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        if isinstance(password, int):
            password = str(password)

        if not isinstance(password, str):
            return Response({'error': 'Valid password is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        if not device_id or not isinstance(device_id, str) or not fcm_token or not isinstance(fcm_token, str):
            return Response({'error': 'Device ID and FCM Token are required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            employee = employee_table.objects.get(email=email)
        except employee_table.DoesNotExist:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

        # if employee.company_id == 1 or employee.vendor_id == 0:
        #     return Response({'error': 'No access to login'}, status=status.HTTP_403_FORBIDDEN)

        password_hash = hashlib.md5(password.encode()).hexdigest()

        if password_hash != employee.password:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

        user, created = User.objects.get_or_create(username=email, defaults={'email': email})

        if created:
            user.set_password('temporary_password')
            user.save()

        employee.auth_id = user.id
        employee.device_id = device_id
        employee.fcm_token = fcm_token
        employee.save()

        # Generate tokens
        refresh = RefreshToken.for_user(user)
        print('refresh',refresh)
        access_token = str(refresh.access_token)
        print('access_token',access_token)

        try:
            token = AccessToken(access_token)
            print('token',token)
            user_id_from_token = token['user_id']
            print('user_id_from_token',user_id_from_token)
        except Exception as e:
            return Response({'error': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)

        # Store in session
        request.session['auth_id'] = user_id_from_token
        request.session['technician_id'] = employee.id
        request.session['vendor_id'] = employee.vendor_id

        # Retrieve employee details
        employee = get_object_or_404(employee_table, auth_id=user_id_from_token)
        vendor_id = employee.vendor_id
        technician_id = employee.id

        vendor_name = "-"
        company_name = "-"

        if vendor_id and vendor_id != 0:
            try:
                vendor = vendor_table.objects.get(id=vendor_id)
                vendor_name = vendor.name
            except vendor_table.DoesNotExist:
                pass

        if employee.company_id and employee.company_id != 0:
            try:
                company = company_table.objects.get(id=employee.company_id)
                company_name = company.name
            except company_table.DoesNotExist:
                pass

        certificate_url = employee.certificate.url if employee.certificate else '-'

        employee_details = {
            'id': employee.id,
            'name': employee.name,
            'username': employee.username,
            'email': employee.email,
            'finger_print': employee.finger_print,
            'address': {
                'line1': employee.address_line1,
                'line2': employee.address_line2,
                'city': employee.city,
                'postal_code': employee.postal_code,
            },
            'contact': {
                'phone': employee.phone,
                'mobile': employee.mobile,
            },
            'roles': {
                'is_scheduler': employee.is_scheduler,
                'is_technician': employee.is_technician,
                'is_supervisor': employee.is_supervisor,
                'is_foreigner': employee.is_foreigner,
                'is_gps': employee.is_gps,
                'is_photo': employee.is_photo,
                'is_qr': employee.is_qr,
                'is_signature': employee.is_signature,
            },
            'company': { 
                'vendor_name': vendor_name,
                'company_name': company_name,
            },
            'certificate': {
                'certificate': certificate_url,
            },
        }

        return Response({
            'status_code': status.HTTP_200_OK,
            'message': 'Logged in successfully.',
            'refresh': str(refresh),
            'access': access_token,
            'auth_id': user_id_from_token,
            'user_id': employee.id,
            'vendor_id': vendor_id,  # Include vendor_id in the response
            'vendor_name': vendor_name,
            'company_id': employee.company_id,
            'company_name': company_name,
            'device_id': device_id,
            'fcm_token': fcm_token,
            'data': employee_details
        }, status=status.HTTP_200_OK)






# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



# class DashboardView(generics.GenericAPIView):
    # authentication_classes = [JWTAuthentication]
    # permission_classes = [IsAuthenticated]
    
    # def get(self, request, *args, **kwargs):
        # print("Session Data:", request.session)
        # user_id = request.user.id
        # employee = get_object_or_404(employee_table, auth_id=user_id)
        # vendor_id = employee.vendor_id

        


        # if not vendor_id:
            # return Response({'error': 'Vendor ID not found in session data'}, status=status.HTTP_400_BAD_REQUEST)
        
        # counts = {
            # 'pending': ticket_table.objects.filter(ticket_status='pending', status=1, vendor_id=vendor_id).count(),
            # 'open': ticket_table.objects.filter(ticket_status='open', status=1, vendor_id=vendor_id).count(),
            # 'hold': ticket_table.objects.filter(ticket_status='hold', status=1, vendor_id=vendor_id).count(),
            # 'partial': ticket_table.objects.filter(ticket_status='partial', status=1, vendor_id=vendor_id).count(),
            # 'completed': ticket_table.objects.filter(ticket_status='completed', status=1, vendor_id=vendor_id).count(),
        # }
        
        # response_data = {
            # 'status_code': status.HTTP_200_OK,
            # 'message': 'Dashboard summary retrieved successfully.',
            # 'summary': counts
        # }
        
        # return Response(response_data, status=status.HTTP_200_OK)




class DashboardView(generics.GenericAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    
    def get(self, request, *args, **kwargs):
        print("Session Data:", request.session)
        user_id = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user_id)
        vendor_id = employee.vendor_id
        technician_id = employee.id

        


        if not vendor_id:
            return Response({'error': 'Vendor ID not found in session data'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Filter ticket counts based on vendor_id
        counts = {
            'pending': ticket_table.objects.filter(ticket_status='pending', status=1, vendor_id=vendor_id,technician_id=technician_id).count(),
            'open': ticket_table.objects.filter(ticket_status='open', status=1, vendor_id=vendor_id,technician_id=technician_id).count(),
            'hold': ticket_table.objects.filter(ticket_status='hold', status=1, vendor_id=vendor_id,technician_id=technician_id).count(),
            'partial': ticket_table.objects.filter(ticket_status='partial', status=1, vendor_id=vendor_id,technician_id=technician_id).count(),
            'completed': ticket_table.objects.filter(ticket_status='completed', status=1, vendor_id=vendor_id,technician_id=technician_id).count(),
        }
        
        response_data = {
            'status_code': status.HTTP_200_OK,
            'message': 'Dashboard summary retrieved successfully.',
            'summary': counts
        }
        
        return Response(response_data, status=status.HTTP_200_OK)

# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````
class AssetQrCode(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        qr_code_data = request.data.get('qr_code_data')
        user = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        user_id = employee.id

        
        if not qr_code_data:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'QR code data is required',
                'error': 'Missing QR code data'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Check for unauthorized access (missing vendor_id)
        if not vendor_id:
            return Response({
                'status_code': status.HTTP_401_UNAUTHORIZED,
                'message': 'Unauthorized access',
                'error': 'Vendor ID not found in session'
            }, status=status.HTTP_401_UNAUTHORIZED)

        # Get projects assigned to the vendor
        project_ids = project_vendor_table.objects.filter(vendor_id=vendor_id, is_active=1).values_list('project_id', flat=True)

        # Check if vendor has any active projects
        if not project_ids:
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'No projects found for this vendor',
                'error': 'Vendor has no assigned projects'
            }, status=status.HTTP_200_OK)

        try:
            # Attempt to find the asset
            asset = asset_table.objects.get(
                asset_item_code=qr_code_data,
                vendor_id=vendor_id,
                project_id__in=project_ids,
                technician_id=user_id
            )
            print('asset', asset)
        except asset_table.DoesNotExist:           
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Asset not found',
                'error': 'No asset found with the provided QR code data for this vendor'
            }, status=status.HTTP_200_OK)

        # Fetch checklists associated with the asset
        checklists = system_checklist.objects.filter(
            asset_group_id=asset.asset_group_id,
            is_active=1
        )

        asset_serializer = AssetSerializer(asset)
        checklist_serializer = ChecklistSerializer(checklists, many=True)

        # Return 200 OK if everything is successful
        return Response({
            'status_code': status.HTTP_200_OK,
            'message': 'Asset verified successfully',
            'data': {
                'asset': asset_serializer.data,
                'checklists': checklist_serializer.data
            }
        }, status=status.HTTP_200_OK)

 
# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````

class CreateNewTicket(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user.id
        print(user)
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        technician_id = employee.id

        
        asset_item_code = request.data.get('asset_item_code')
        description = request.data.get('description', '')
        priority = request.data.get('priority')
        name = request.data.get('name', None)  

        if not technician_id:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Technician ID is required',
                'error': 'Missing technician ID'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            asset = asset_table.objects.get(asset_item_code=asset_item_code)
        except asset_table.DoesNotExist:
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Asset not found',
                'error': 'No asset found with the provided code'
            }, status=status.HTTP_200_OK)

        if asset.vendor_id != vendor_id:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Unauthorized vendor',
                'error': 'Vendor ID does not match the asset\'s vendor'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            vendor = vendor_table.objects.get(id=asset.vendor_id)
        except vendor_table.DoesNotExist:
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Vendor not found',
                'error': 'No vendor found for the asset'
            }, status=status.HTTP_200_OK)

        try:
            project = project_table.objects.get(id=asset.project_id)
        except project_table.DoesNotExist:
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Project not found',
                'error': 'No project found for the asset'
            }, status=status.HTTP_200_OK)

        customer_prefix = vendor.customer_prefix
        num_series = generate_unique_ticket_code(vendor.id,project.id)
        ticket_no = f"{customer_prefix}{project.prefix}{num_series}"

        # If ticket_date and ticket_time are not provided, use the current date and time
        ticket_date = request.data.get('ticket_date', timezone.now().date())  # Default to current date
        ticket_time = request.data.get('ticket_time', timezone.now().time())  # Default to current time

        # Convert ticket_date and ticket_time to appropriate formats if provided
        try:
            ticket_date = timezone.datetime.strptime(ticket_date, '%Y-%m-%d').date() if isinstance(ticket_date, str) else ticket_date
            ticket_time = timezone.datetime.strptime(ticket_time, '%H:%M:%S').time() if isinstance(ticket_time, str) else ticket_time
        except ValueError:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Invalid date or time format',
                'error': 'Ticket date or time format is incorrect'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Split frequency_id if it's a comma-separated string
        frequency_ids = asset.frequency_id.split(',') if ',' in str(asset.frequency_id) else [str(asset.frequency_id)]

        # Loop through each frequency_id and create a ticket for each
        tickets_created = []
        for freq_id in frequency_ids:
            try:
                frequency = frequency_table.objects.get(id=freq_id.strip())
            except frequency_table.DoesNotExist:
                return Response({
                    'status_code': status.HTTP_200_OK,
                    'message': 'Frequency not found',
                    'error': f'No frequency found with ID {freq_id.strip()}'
                }, status=status.HTTP_200_OK)

            unique_color = generate_unique_color()

            # Prepare ticket data for each frequency_id
            ticket_data = {
                'vendor_id': vendor.id,
                'num_series': num_series,
                'project_id': project.id,
                'category_id': asset.category_id,
                'system_id': asset.id,
                'asset_item_id': asset.id,
                'description': description,
                'ticket_status': 'pending',
                'created_on': timezone.now(),
                'updated_on': timezone.now(),
                'created_by': technician_id,  # Assuming user ID from request
                'updated_by': technician_id,  # Assuming user ID from request
                'ticket_date': ticket_date,
                'ticket_time': ticket_time,
                'name': name if name else "",
                'ticket_no': ticket_no,
                'frequency_id': freq_id.strip(),
                'technician_id': technician_id,
                'color': unique_color
            }
            print('ticket_data', ticket_data)

            # Serialize and save the ticket
            serializer = TicketSerializer(data=ticket_data)
            if serializer.is_valid():
                serializer.save()
                return Response({
                    'status_code': status.HTTP_200_OK,
                    'message': 'Ticket created successfully',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'status_code': status.HTTP_400_BAD_REQUEST,
                    'message': 'Failed to create ticket',
                    'errors': serializer.errors
                }, status=status.HTTP_400_BAD_REQUEST)


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````

class TicketSummaryView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user.id
        print(user)
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        print(vendor_id)
        technician_id = employee.id

        year = request.query_params.get('year')
        
        
        if not year:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Year is required',
                'error': 'Missing year parameter'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            year = int(year)
        except ValueError:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Invalid year format',
                'error': 'Year should be an integer'
            }, status=status.HTTP_400_BAD_REQUEST)

        response_data = []

        for month in range(1, 13):
            start_date = make_aware(datetime(year, month, 1))
            end_date = make_aware(datetime(year, month + 1, 1)) if month < 12 else make_aware(datetime(year + 1, 1, 1))
            
            tickets = ticket_table.objects.filter(
                created_on__range=[start_date, end_date],
                vendor_id=vendor_id  # Filter by vendor_id
            )
            
            grouped_tickets = tickets.values('category_id', 'ticket_type').annotate(
                completed_count=Count('id', filter=Q(ticket_status='completed')),
                pending_count=Count('id', filter=Q(ticket_status='pending')),
                hold_count=Count('id', filter=Q(ticket_status='hold')),
                partial_count=Count('id', filter=Q(ticket_status='partial'))
            ).order_by('category_id', 'ticket_type')

            for ticket in grouped_tickets:
                category_id = ticket['category_id']
                ticket_type = ticket['ticket_type']

                # Initialize category and ticket type section if not present
                ticket_summary = {
                    "category_id": category_id,
                    "ticket_type": ticket_type,
                    "completed": {calendar.month_name[i]: 0 for i in range(1, 13)},
                    "pending": {calendar.month_name[i]: 0 for i in range(1, 13)},
                    "hold": {calendar.month_name[i]: 0 for i in range(1, 13)},
                    "partial": {calendar.month_name[i]: 0 for i in range(1, 13)}
                }

                ticket_summary['completed'][calendar.month_name[month]] = ticket['completed_count']
                ticket_summary['pending'][calendar.month_name[month]] = ticket['pending_count']
                ticket_summary['hold'][calendar.month_name[month]] = ticket['hold_count']
                ticket_summary['partial'][calendar.month_name[month]] = ticket['partial_count']

                # Add ticket_summary to response_data only if not already present
                existing_summary = next((item for item in response_data if item['category_id'] == category_id and item['ticket_type'] == ticket_type), None)
                if existing_summary:
                    existing_summary['completed'][calendar.month_name[month]] += ticket_summary['completed'][calendar.month_name[month]]
                    existing_summary['pending'][calendar.month_name[month]] += ticket_summary['pending'][calendar.month_name[month]]
                    existing_summary['hold'][calendar.month_name[month]] += ticket_summary['hold'][calendar.month_name[month]]
                    existing_summary['partial'][calendar.month_name[month]] += ticket_summary['partial'][calendar.month_name[month]]
                else:
                    response_data.append(ticket_summary)
        
        return Response({
            'status_code': status.HTTP_200_OK,
            'message': 'Ticket summary retrieved successfully',
            'data': response_data
        }, status=status.HTTP_200_OK)



# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````
class AssetSummaryView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    def get(self, request):
       
        summary = {
            'total_categories': asset_table.objects.values('category_id').distinct().count(),
            'total_projects': asset_table.objects.values('project_id').distinct().count(),
            'total_vendors': asset_table.objects.values('vendor_id').distinct().count(),
            'total_assets': asset_table.objects.count(),
            'details': {}
        }
        
        # Retrieve distinct asset_group_ids
        asset_groups = asset_table.objects.values_list('asset_group_id', flat=True).distinct()
        
        for group_id in asset_groups:
            actions = list(system_action.objects.filter(asset_group_id=group_id, is_active=1).values('name', 'status', 'created_on', 'updated_on'))
            findings = list(system_finding.objects.filter(asset_group_id=group_id, is_active=1).values('name', 'status', 'created_on', 'updated_on'))
            descriptions = list(system_description.objects.filter(asset_group_id=group_id, is_active=1).values('name', 'status', 'created_on', 'updated_on'))
            
            summary['details'][group_id] = {
                'actions': actions,
                'findings': findings,
                'descriptions': descriptions
            }
        
        return Response({
            'status_code': status.HTTP_200_OK,
            'message': 'Asset summary retrieved successfully',
            'data': summary
        }, status=status.HTTP_200_OK)
    


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````


class EmployeeDetais(APIView):
    
    def get(self, request, employee_id):
        try:
            employee = employee_table.objects.get(pk=employee_id)
            serializer = EmployeeSerializer(employee)
            return Response({
                "status_code": status.HTTP_200_OK,
                "message": "Employee details fetched successfully",
                "data": serializer.data
            })
        except employee_table.DoesNotExist:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Employee not found"
            }, status=status.HTTP_400_BAD_REQUEST)


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````

class TicketReport(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]    

    def get(self, request, ticket_id=None):
        user = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        technician_id = employee.id
        
        asset_item_id = request.GET.get('asset_id')  # Retrieve asset ID from query parameters

        try:
            if asset_item_id:
                tickets = ticket_table.objects.filter(asset_item_id=asset_item_id, vendor_id=vendor_id)
                if not tickets.exists():
                    return Response({
                        "status_code": status.HTTP_200_OK,
                        "message": "No tickets found for this asset."
                    }, status=status.HTTP_200_OK)
                serializer = SummarySerializers(tickets, many=True)
            else:
                ticket = ticket_table.objects.get(pk=ticket_id, vendor_id=vendor_id)
                serializer = SummarySerializers(ticket)

            return Response({
                "status_code": status.HTTP_200_OK,
                "message": "Ticket details fetched successfully",
                "data": serializer.data
            })
        except ticket_table.DoesNotExist:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Ticket not found for this technician or asset."
            }, status=status.HTTP_400_BAD_REQUEST)

# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````


class AssetList(APIView):    
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    def get(self, request, asset_id):
        user = request.user.id
        print(user)
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        print(vendor_id)
        technician_id = employee.id

        try:
            print('check')
            asset = asset_table.objects.get(pk=asset_id,vendor_id=vendor_id)
            print('asset', asset)
            serializer = AssetSummary(asset)
            return Response({
                "status_code": status.HTTP_200_OK,
                "message": "Asset details fetched successfully",
                "data": serializer.data
            })
        except asset_table.DoesNotExist:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Asset not found for this technician"
            }, status=status.HTTP_400_BAD_REQUEST)


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import ticket_table, employee_table
from .serializers import TicketUpdateSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from datetime import timedelta

from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

class TicketUpdate(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def put(self, request, ticket_id):
        user = request.user.id
        print(user)
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        print('vendor_id', vendor_id)
        technician_id = employee.id

        try:
            ticket = ticket_table.objects.get(pk=ticket_id, vendor_id=vendor_id)
        except ticket_table.DoesNotExist:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Ticket not found"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Get current status and request status, and convert both to lowercase for case-insensitive comparison
        current_status = ticket.ticket_status.lower()  # Current status in DB, converted to lowercase
        request_status = request.data.get('ticket_status', '').lower()  # Status in request data, converted to lowercase

        serializer = TicketUpdateSerializer(ticket, data=request.data, partial=True)
        
        if serializer.is_valid():
            # Condition 1: Update start_date only when status changes from "pending" to "open" (case-insensitive) and only once
            if current_status == 'pending' and request_status == 'open' and ticket.start_date is None:
                ticket.start_date = timezone.now()

            # Condition 2: Update end_date and calculate total hours only when status changes to "partial" (case-insensitive) and only once
            if request_status == 'partial' and ticket.end_date is None:
                ticket.end_date = timezone.now()
                if ticket.start_date:
                    total_hours = (ticket.end_date - ticket.start_date).total_seconds() / 3600
                    ticket.total_hrs = str(total_hours)

            # Save the serializer with the updated data
            serializer.save()

            return Response({
                "status_code": status.HTTP_200_OK,
                "message": "Ticket updated successfully",
                "data": serializer.data
            })

        # If the serializer is not valid, return an error response
        return Response({
            "status_code": status.HTTP_400_BAD_REQUEST,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)




# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



# class FileUpload(APIView):
#     authentication_classes = [JWTAuthentication]
#     permission_classes = [IsAuthenticated]

#     def post(self, request):
#         user = request.user.id
#         print(user)

#         # Get the employee details from the authenticated user
#         employee = get_object_or_404(employee_table, auth_id=user)
#         vendor_id = employee.vendor_id
#         technician_id = employee.id
#         print(vendor_id)

#         ticket_id = request.data.get('ticket_id')
#         if not ticket_id:
#             return Response({
#                 "status_code": status.HTTP_400_BAD_REQUEST,
#                 "message": "Ticket ID is required"
#             }, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             # Fetch the ticket based on ticket_id and vendor_id
#             ticket = ticket_table.objects.get(pk=ticket_id, vendor_id=vendor_id)
#         except ticket_table.DoesNotExist:
#             return Response({
#                 "status_code": status.HTTP_400_BAD_REQUEST,
#                 "message": "Ticket not found"
#             }, status=status.HTTP_400_BAD_REQUEST)

#         # Deserialize and update the ticket with the uploaded file
#         serializer = UpdatefileSerializer(ticket, data=request.data)
#         if serializer.is_valid():
#             serializer.save()

            
#             ticket.ticket_status = "completed"
#             ticket.save()

#             return Response({
#                 "status_code": status.HTTP_200_OK,
#                 "message": "File uploaded successfully and ticket status updated to completed.",
#                 "data": serializer.data
#             })
        
#         # Handle invalid data
#         return Response({
#             "status_code": status.HTTP_400_BAD_REQUEST,
#             "message": "Invalid data",
#             "errors": serializer.errors
#         }, status=status.HTTP_400_BAD_REQUEST)

from django.core.mail import EmailMessage
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import employee_table, ticket_table  # Assuming these models exist
from .serializers import UpdatefileSerializer  # Assuming this serializer exists

# class FileUpload(APIView):
#     authentication_classes = [JWTAuthentication]
#     permission_classes = [IsAuthenticated]

#     def post(self, request):
#         user = request.user.id
#         print(user)

#         # Get the employee details from the authenticated user
#         employee = get_object_or_404(employee_table, auth_id=user)
#         vendor_id = employee.vendor_id
#         technician_id = employee.id
#         print(vendor_id)

#         ticket_id = request.data.get('ticket_id')
#         if not ticket_id:
#             return Response({
#                 "status_code": status.HTTP_400_BAD_REQUEST,
#                 "message": "Ticket ID is required"
#             }, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             # Fetch the ticket based on ticket_id and vendor_id
#             ticket = ticket_table.objects.get(pk=ticket_id, vendor_id=vendor_id)
#         except ticket_table.DoesNotExist:
#             return Response({
#                 "status_code": status.HTTP_400_BAD_REQUEST,
#                 "message": "Ticket not found"
#             }, status=status.HTTP_400_BAD_REQUEST)

#         # Deserialize and update the ticket with the uploaded file
#         serializer = UpdatefileSerializer(ticket, data=request.data)
#         if serializer.is_valid():
#             serializer.save()

#             # Update the ticket status to 'completed'
#             ticket.ticket_status = "completed"
#             ticket.save()

#             # Call the email function after ticket update
#             email_sent = self.send_report_to_email(ticket)

#             return Response({
#                 "status_code": status.HTTP_200_OK,
#                 "message": f"File uploaded successfully and ticket status updated to completed. Email sent: {email_sent}",
#                 "data": serializer.data
#             })
        
#         # Handle invalid data
#         return Response({
#             "status_code": status.HTTP_400_BAD_REQUEST,
#             "message": "Invalid data",
#             "errors": serializer.errors
#         }, status=status.HTTP_400_BAD_REQUEST)


#     def send_report_to_email(self, ticket):
#         subject = f"{ticket.customer_id} | {ticket.project_id} | {ticket.system_id} | {ticket.ticket_date} | {ticket.ticket_no}"
#         message = (
#             "Please find the attached Service Report. "
#             "For any inquiries, please contact us at 6472 2819 or email at admin@peakengrg.com\n\n"
#             "Please do not reply to this message"
#         )

#         email = EmailMessage(
#             subject=subject,
#             body=message,
#             from_email='ttsfms_alert@towertransit.sg',
#             to=['genplusinnovations26@gmail.com']  # Make sure to pass a list or tuple for `to`
#         )

#         if ticket.file_name:
#             attachment_path = os.path.join(settings.MEDIA_ROOT, ticket.file_name.name)
#             print('*****************ticket_file_path**************', attachment_path)
            
#             # Check if the file exists before proceeding to attach it
#             if os.path.exists(attachment_path):
#                 print('*************************************  CONDITION MET')
                
#                 # Attach the file
#                 with open(attachment_path, 'rb') as file:
#                     email.attach(ticket.file_name.name, file.read(), 'application/pdf')
#             else:
#                 return "Attachment not found"

#         # Try sending the email
#         try:
#             email.send(fail_silently=False)
#             return "Email sent successfully"
#         except Exception as e:
#             return f"Failed to send email: {str(e)}"

# import os
# from django.core.mail import EmailMessage
# from django.conf import settings
# from django.http import JsonResponse
# from .models import Ticket  # Adjust this based on where your Ticket model is located
# from django.shortcuts import get_object_or_404

# def send_report_to_email(request, ticket):
#     # Fetch ticket data based on ticket_id
#     ticket_data = get_object_or_404(ticket_table, id=ticket.id)

#     file_name = ticket_data.file_name
#     attachment_path = os.path.join(settings.BASE_DIR, 'uploads', 'report_files', file_name)

#     # Set up the email subject and body
#     subject = f"{ticket_data.customer} | {ticket_data.project} | {ticket_data.asset_item_code} | {ticket_data.ticket_date} | {ticket_data.ticket_no}"
#     message = (
#         "Please find the attached Service Report. "
#         "For any inquiries, please contact us at 6472 2819 or email at admin@peakengrg.com\n\n"
#         "Please do not reply to this message"
#     )

#     # Create the email message
#     email = EmailMessage(
#         subject=subject,
#         body=message,
#         from_email=settings.EMAIL_HOST_USER,  # From email
#         to=[ticket_data.incharge_email],      # To email (recipient)
#     )

#     # Attach the file if it exists
#     if os.path.exists(attachment_path):
#         email.attach(file_name, open(attachment_path, 'rb').read(), 'application/pdf')
#     else:
#         return JsonResponse({"result": "failed", "message": "Attachment not found"}, status=400)

#     # Send the email
#     try:
#         email.send(fail_silently=False)
#         return JsonResponse({"result": "success"})
#     except Exception as e:
#         return JsonResponse({"result": "failed", "message": str(e)}, status=500)

# from django.core.mail import EmailMessage
# from django.conf import settings
# import os
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from .models import employee_table, ticket_table
# from .serializers import UpdatefileSerializer
# from django.shortcuts import get_object_or_404


class FileUpload(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user.id
        print(user)

        # Get the employee details from the authenticated user
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        technician_id = employee.id
        print(vendor_id)

        ticket_id = request.data.get('ticket_id')
        if not ticket_id:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Ticket ID is required"
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Fetch the ticket based on ticket_id and vendor_id
            ticket = ticket_table.objects.get(pk=ticket_id, vendor_id=vendor_id)
        except ticket_table.DoesNotExist:
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Ticket not found"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Deserialize and update the ticket with the uploaded file
        serializer = UpdatefileSerializer(ticket, data=request.data)
        if serializer.is_valid():
            serializer.save()

            # Update the ticket status to 'completed'
            ticket.ticket_status = "completed"
            ticket.save()

            # Call the email function after ticket update
            email_sent = self.send_report_to_email(ticket)

            return Response({
                "status_code": status.HTTP_200_OK,
                "message": f"File uploaded successfully and ticket status updated to completed. Email sent: {email_sent}",
                "data": serializer.data
            })

        # Handle invalid data
        return Response({
            "status_code": status.HTTP_400_BAD_REQUEST,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


    def send_report_to_email(self, ticket):
        ticket_data = get_object_or_404(ticket_table, id=ticket.id)
        customer_name = getItemNameById(customer_table, ticket.customer_id)
        project_name = getItemNameById(project_table, ticket.project_id)
        asset_system = getItemNameById(system_table, ticket.system_id)

        if ticket_data.file_name:
            attachment_path = os.path.join(settings.MEDIA_ROOT, ticket_data.file_name.name)
            print('*****************ticket_file_path**************', attachment_path)

            if os.path.exists(attachment_path):
                print('*************************************  CONDITION MET')
                
                # Set the email subject and body
                subject = f"{customer_name} | {project_name} | {asset_system} | {ticket_data.ticket_date} | {ticket_data.ticket_no}"
            
                
                # Print the subject to check in the console
                print("Email Subject:", subject)

                message = (
                    f"Subject: {subject}\n\n"  # Include the subject in the email body
                    "Please find the attached Service Report. "
                    "For any inquiries, please contact us at 6472 2819 or email at admin@peakengrg.com\n\n"
                    "Please do not reply to this message"
                )
                
                # Create the email message
                email = EmailMessage(
                    subject=subject,
                    body=message,
                    from_email='dhivyadharshinikd@gmail.com',  # From email
                    to=['genplusinnovations26@gmail.com'],      # To email (recipient)
                )

                with open(attachment_path, 'rb') as file:
                    email.attach(ticket_data.file_name.name, file.read(), 'application/pdf')

                # Send the email
                try:
                    email.send(fail_silently=False)
                    print(f"Email sent successfully to {', '.join(email.to)}")
                    return "success"
                except Exception as e:
                    print(f"Failed to send email: {str(e)}")
                    return f"Failed to send email: {str(e)}"
            else:
                print(f"Attachment not found at {attachment_path}")
                return "Attachment not found"
        else:
            return "No file attached"

# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````


class TicketDates(generics.GenericAPIView):

    serializer_class = TicketDate

    def get(self, request):
        
       

        technician_id = request.query_params.get('technician_id')
        
        print('technician_id',technician_id)

        if not technician_id:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'Technician ID is required'
            }, status=status.HTTP_400_BAD_REQUEST)

        status_list = request.query_params.getlist('ticket_status')

        # Initialize filters dictionary
        filters = {
            'technician_id': technician_id
        }

        if status_list:
            filters['ticket_status__in'] = status_list
        
        try:
            tickets = ticket_table.objects.filter(**filters).order_by('ticket_date')
            print('tickets',tickets)

            # Check if tickets exist
            if not tickets.exists():
                return Response({
                    'status_code':status.HTTP_200_OK,
                    'message': 'No Tickets Found',
                    'data' : tickets
                }, status=status.HTTP_200_OK)

            # Group tickets by date
            grouped_tickets = tickets.values('ticket_date').annotate(ticket_count=Count('id')).order_by('ticket_date')

            # Prepare the response data with grouped dates
            response_data = [
                {
                    'date': group['ticket_date']
                }
                for group in grouped_tickets
            ]

            # Return the response with grouped dates
            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Grouped tickets by date retrieved successfully.',
                'data': response_data
            }, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Handle any exceptions that occur
            return Response({
                'status_code': status.HTTP_500_INTERNAL_SERVER_ERROR,
                'message': 'An error occurred while processing the request.',
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone
from django.shortcuts import get_object_or_404
from .models import ticket_table
from .serializers import TicketSerializer

from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken

class TicketList(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    def get(self, request):
        user = request.user.id
        print(user)
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        print(vendor_id)
        technician_id = employee.id

        # technician_id = request.session.get('technician_id')
        
        status_list = request.query_params.getlist('ticket_status')
        from_date = request.query_params.get('from_date')
        to_date = request.query_params.get('to_date')
        filters = {}

        if technician_id:
            filters['technician_id'] = technician_id
        
        if status_list:
            filters['ticket_status__in'] = status_list
        
        if from_date and to_date:
            try:
                from_date = timezone.make_aware(timezone.datetime.strptime(from_date, '%Y-%m-%d'))
                to_date = timezone.make_aware(timezone.datetime.strptime(to_date, '%Y-%m-%d'))
                filters['ticket_date__range'] = (from_date, to_date)
            except ValueError:
                return Response({
                    'status_code': status.HTTP_400_BAD_REQUEST,
                    'message': 'Invalid date format. Use YYYY-MM-DD.'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        elif from_date:
            try:
                from_date = timezone.make_aware(timezone.datetime.strptime(from_date, '%Y-%m-%d'))
                filters['ticket_date__gte'] = from_date
            except ValueError:
                return Response({
                    'status_code': status.HTTP_400_BAD_REQUEST,
                    'message': 'Invalid from_date format. Use YYYY-MM-DD.'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        elif to_date:
            try:
                to_date = timezone.make_aware(timezone.datetime.strptime(to_date, '%Y-%m-%d'))
                filters['ticket_date__lte'] = to_date
            except ValueError:
                return Response({
                    'status_code': status.HTTP_400_BAD_REQUEST,
                    'message': 'Invalid to_date format. Use YYYY-MM-DD.'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            tickets = ticket_table.objects.filter(**filters)
            
            data = []
            for ticket in tickets:
                vendor_name = "-"
                project_name = "-"
                category_name = "-"
                system_name = "-"
                asset_item_name = "-"
                asset_system_code = "-"
                frequency_name = "-"
                location = "-"
                
                # Fetch related names
                if ticket.vendor_id:
                    try:
                        vendor = vendor_table.objects.get(id=ticket.vendor_id)
                        vendor_name = vendor.name
                    except vendor_table.DoesNotExist:
                        pass

                if ticket.project_id:
                    try:
                        project = project_table.objects.get(id=ticket.project_id)
                        project_name = project.name
                    except project_table.DoesNotExist:
                        pass

                if ticket.category_id:
                    try:
                        category = category_table.objects.get(id=ticket.category_id)
                        category_name = category.name
                    except category_table.DoesNotExist:
                        pass

                if ticket.system_id:
                    try:
                        system = system_table.objects.get(id=ticket.system_id)
                        system_name = system.name
                        asset_system_code = system.category_id
                    except system_table.DoesNotExist:
                        pass

                if ticket.asset_item_id:
                    try:
                        asset_item = asset_table.objects.get(id=ticket.asset_item_id)
                        asset_item_name = asset_item.name
                        asset_item_code = asset_item.asset_item_code
                        location = asset_item.location
                    except asset_table.DoesNotExist:
                        pass

                if ticket.frequency_id:
                    try:
                        frequency = frequency_table.objects.get(id=ticket.frequency_id)
                        frequency_name = frequency.name
                    except frequency_table.DoesNotExist:
                        pass

                if ticket.technician_id:
                    try:
                        technician = employee_table.objects.get(id=ticket.technician_id)
                        technician_name = technician.name
                    except employee_table.DoesNotExist:
                        pass

                # Prepare response data
                ticket_data = {
                    'ticket_id': ticket.id,
                    'ticket_no': ticket.ticket_no,
                    'num_series': ticket.num_series,
                    'vendor_id': ticket.vendor_id,
                    'vendor_name': vendor_name,
                    'project_id': ticket.project_id,
                    'project_name': project_name,
                    'category_id': ticket.category_id,
                    'category_name': category_name,
                    'asset_libaray_id': ticket.system_id,
                    'asset_libaray_code': system_name,
                    'asset_libaray_name': asset_system_code,
                    'frequency_id': ticket.frequency_id,
                    'frequency_name': frequency_name,
                    'asset_id': ticket.asset_item_id,
                    'asset_code': asset_item_code,
                    'asset_name': asset_item_name,
                    'technician_id': ticket.technician_id,
                    'technician_name': technician_name,
                    'location': location,
                    'ticket_status': ticket.ticket_status,
                    'ticket_date': ticket.ticket_date.strftime('%Y-%m-%d') if ticket.ticket_date else '-',
                    'schedule_date': ticket.schedule_date.strftime('%Y-%m-%d') if ticket.schedule_date else '-',
                    'ticket_time': ticket.ticket_time.strftime('%H:%M:%S') if ticket.ticket_time else '-',
                    'priority': ticket.priority,
                    'ticket_type': ticket.ticket_type,
                    'description': ticket.description or "",
                    'action': ticket.action or "",
                    'findings': ticket.findings or "",
                    'remarks': ticket.remarks or "",
                    'signature': ticket.signature.url if ticket.signature else '',
                    'customer_signature': ticket.customer_signature.url if ticket.customer_signature else '',
                    'file_name': ticket.file_name.url if ticket.file_name else '',
                    'is_checklist': ticket.is_checklist,
                    'is_signature': ticket.is_signature,
                    'is_completed': ticket.is_completed,
                    'is_uploaded': ticket.is_uploaded,
                    'is_sensor_ticket': ticket.is_sensor_ticket,
                    'is_customer_signed': ticket.is_customer_signed,
                    'signed_by': ticket.signed_by,
                    'created_on': ticket.created_on.isoformat(),
                    'updated_on': ticket.updated_on.isoformat(),
                    'color': ticket.color
                }

                data.append(ticket_data)

            return Response({
                'status_code': status.HTTP_200_OK,
                'message': 'Tickets retrieved successfully.',
                'data': data
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'status_code': status.HTTP_500_INTERNAL_SERVER_ERROR,
                'message': 'An error occurred while processing the request.',
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



class ChecklistByTicketView(generics.GenericAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request: Request):
        data = request.data
        asset_item_code = data.get('asset_item_code')
        print('asset_item_code', asset_item_code)
        frequency_id = data.get('frequency_id')
        print('frequency_id', frequency_id)
        ticket_id = data.get('ticket_id')

        user = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        technician_id = employee.id

        if not asset_item_code or not frequency_id or not ticket_id:
            return Response({
                'status_code': status.HTTP_400_BAD_REQUEST,
                'message': 'asset_item_code, frequency_id, and ticket_id are required.'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            asset = asset_table.objects.get(asset_item_code=asset_item_code)
            asset_group_id = asset.asset_group_id
            print('asset_group_id', asset_group_id)
        except asset_table.DoesNotExist:
            return Response({
                'status_code': status.HTTP_404_NOT_FOUND,
                'message': 'Asset item code not found.'
            }, status=status.HTTP_404_NOT_FOUND)

        checklists = system_checklist.objects.filter(
            asset_group_id=asset_group_id,
            frequency_id=frequency_id,
            status=1
        ).values('id', 'description', 'question', 'asset_group_id', 'frequency_id')
        print('checklists', checklists)

        ticket_checklist_data = []

        # Fetch frequency name
        try:
            frequency = frequency_table.objects.get(id=frequency_id)
            frequency_name = frequency.name
            frequency_code = frequency.frequency_code
        except frequency_table.DoesNotExist:
            frequency_name = None  # or handle as needed

        for checklist in checklists:
            checklist_id = checklist['id']

            ticket_checklist, created = TicketChecklistTable.objects.update_or_create(
                ticket_id=ticket_id,
                asset_group_id=asset_group_id,
                frequency_id=frequency_id,
                checklist_id=checklist_id,
                defaults={
                    'is_checked': 0,
                    'updated_on': timezone.now(),
                    'updated_by': technician_id
                }
            )

            if created:
                ticket_checklist.created_on = timezone.now()
                ticket_checklist.created_by = technician_id
                ticket_checklist.save()

            # Append TicketChecklist data for the response
            ticket_checklist_data.append({
                'id': ticket_checklist.id,
                'ticket_id': ticket_checklist.ticket_id,
                'asset_group_id': ticket_checklist.asset_group_id,
                'checklist_id': ticket_checklist.checklist_id,
                'is_checked': ticket_checklist.is_checked,
                'frequency_id': ticket_checklist.frequency_id,
                'frequency_name': frequency_name,
                'frequency_code': frequency_code,
                'checklist_description': checklist['description'] if checklist['description'] else '-',  # Append checklist description
                'checklist_question': checklist['question']  # Append checklist question
            })

        # Update is_checklist field in the ticket_table
        try:
            ticket = ticket_table.objects.get(id=ticket_id)
            ticket.is_checklist = 1  # Mark the checklist as completed
            ticket.save()
        except ticket_table.DoesNotExist:
            return Response({
                'status_code': status.HTTP_404_NOT_FOUND,
                'message': 'Ticket not found.'
            }, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'status_code': status.HTTP_200_OK,
            'message': 'Checklist data processed, TicketChecklist updated, and ticket marked as checklist completed.',
            'ticket_checklists': ticket_checklist_data  # TicketChecklist data
        }, status=status.HTTP_200_OK)

        


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



import requests



class UpdateTicketChecklist(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    def put(self, request, *args, **kwargs):
        user = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        technician_id = employee.id


        if not request.content_type == 'application/json':
            return Response({
                "status_code": status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                "message": "Unsupported media type. Please send data as application/json."
            }, status=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE)

        data = request.data

        if not isinstance(data, list):
            return Response({
                "status_code": status.HTTP_400_BAD_REQUEST,
                "message": "Expected a list of checklist items."
            }, status=status.HTTP_400_BAD_REQUEST)       

        # Process each checklist item
        for item in data:
            if not isinstance(item, dict):
                return Response({
                    "status_code": status.HTTP_400_BAD_REQUEST,
                    "message": "Each checklist item should be a JSON object."
                }, status=status.HTTP_400_BAD_REQUEST)

            ticket_id = item.get('id')
            checklist_id = item.get('checklist_id')
            is_checked = item.get('is_checked')

            if not ticket_id or not checklist_id or is_checked is None:
                return Response({
                    "status_code": status.HTTP_400_BAD_REQUEST,
                    "message": "Missing required fields in one of the checklist items"
                }, status=status.HTTP_400_BAD_REQUEST)

            try:
                checklist_item = TicketChecklistTable.objects.get(id=ticket_id, checklist_id=checklist_id)
            except TicketChecklistTable.DoesNotExist:
                return Response({
                    "status_code": status.HTTP_404_NOT_FOUND,
                    "message": f"TicketChecklistTable item not found for ticket_id {ticket_id} and checklist_id {checklist_id}"
                }, status=status.HTTP_404_NOT_FOUND)

            checklist_item.is_checked = is_checked
            checklist_item.updated_by = technician_id
            checklist_item.updated_on = timezone.now()
            checklist_item.save()

        return Response({
            "status_code": status.HTTP_200_OK,
            "message": "Ticket Checklists updated successfully"
        }, status=status.HTTP_200_OK)

   


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````

class TicketHistory(APIView):
    authentication_classes = [JWTAuthentication]  
    permission_classes = [IsAuthenticated]  

    def get(self, request, asset_id, *args, **kwargs):
        user = request.user.id
        employee = get_object_or_404(employee_table, auth_id=user)
        vendor_id = employee.vendor_id
        print('vendor_id',vendor_id)
        print('asset_id',asset_id)

        tickets = ticket_table.objects.filter(asset_item_id=asset_id,vendor_id=vendor_id) 
        print('tickets',tickets)       
        if tickets.exists():
            serializer = TicketSerializer(tickets, many=True)
            return Response({
                "status_code": status.HTTP_200_OK,
                "message": "Tickets against asset retrieved successfully",
                "tickets": serializer.data
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                "status_code": status.HTTP_200_OK,
                "message": f"No tickets found for asset_id {asset_id}"
            }, status=status.HTTP_200_OK)


# ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````



# def week_of_month(dt):
#     first_day = dt.replace(day=1)
#     dom = dt.day
#     adjusted_dom = dom + first_day.weekday()
#     return int((adjusted_dom - 1) / 7) + 1



# from datetime import timedelta
# from calendar import monthrange



# from datetime import timedelta
# def check_public_holiday(date):
#     return holiday_table.objects.filter(date=date).exists()

# def last_day_of_month(date):
#     return date.replace(day=monthrange(date.year, date.month)[1])


# def adjust_ticket_date(ticket_date, include_public_holiday, include_saturday, include_sunday):
#     if include_public_holiday:
#         print(f"Public holidays are included. Using original ticket date: {ticket_date}")
#         return ticket_date

#     is_public_holiday = check_public_holiday(ticket_date)
#     print(f"Checked if {ticket_date} is a public holiday: {is_public_holiday}")

#     # If public holiday is not included and the date is a public holiday
#     if not include_public_holiday and is_public_holiday:
#         print(f"Skipping public holiday: {ticket_date}")
#         # Check if it's the last day of the month
#         if ticket_date == last_day_of_month(ticket_date):
#             ticket_date -= timedelta(days=1)  # Move to the previous day
#             print(f"Adjusted to previous day (last day of month): {ticket_date}")
#         else:
#             # Adjust for Saturday
#             if not include_saturday and ticket_date.isoweekday() == 6:  # Saturday
#                 ticket_date += timedelta(days=2 if not include_sunday else 1)  # Move to next weekday
#                 print(f"Adjusted to next weekday (Saturday): {ticket_date}")
#             # Adjust for Sunday
#             elif not include_sunday and ticket_date.isoweekday() == 7:  # Sunday
#                 ticket_date += timedelta(days=1)  # Move to next day (Monday)
#                 print(f"Adjusted to next day (Sunday): {ticket_date}")

#     return ticket_date


# def frequency_year_wise(start, end, times, name, include_public_holiday, include_saturday=0, include_sunday=0):
#     # Prepare start and end date
#     begin = start.date()  # Convert to date
#     end = end.date()  # Convert to date
#     interval = int(times)
#     begin_day_no = begin.isoweekday()
#     begin_week_no = week_of_month(begin)

#     # Define the query parameters for fetching records
#     where = {
#         'day_no': begin_day_no,
#         'week_no': begin_week_no,
#         'mm': begin.month,
#         'mdate__gte': begin,
#         'mdate__lte': end,
#     }

#     # Fetch relevant data from the DateMaster model
#     data = list(DateMaster.objects.filter(**where))

#     if not data:
#         print("No data found for the given date range and criteria.")
#         return []

#     json_data = []

#     for v in data:
#         ticket_date = v.mdate
#         print(f"Initial ticket_date: {ticket_date}")

#         # Adjust the ticket date based on the conditions
#         ticket_date = adjust_ticket_date(ticket_date, include_public_holiday, include_saturday, include_sunday)
#         print(f"Adjusted ticket_date: {ticket_date}")

#         # Update the day based on the new ticket date
#         adjusted_day_name = ticket_date.strftime('%A')  # Get the correct day name after adjustment
#         print(f"Day of the week after adjustment: {adjusted_day_name}")

#         # Check for interval condition and public holiday handling
#         days_difference = (ticket_date - begin).days
#         print(f"Days difference from begin date: {days_difference}")
#         if days_difference >= 0 and (days_difference % interval == 0):  # Ensure ticket_date matches the interval
#             if not check_public_holiday(ticket_date) or include_public_holiday:
#                 cdata = {
#                     'ticket_date': ticket_date.strftime('%Y-%m-%d'),  # Convert to string format
#                     'ticket_day': adjusted_day_name,# Updated day after date adjustment
#                     'week_no': v.week_no,
#                     'frequency': name
#                 }
#                 json_data.append(cdata)
#                 print(f"Added to json_data: {cdata}")
#             else:
#                 print(f"Skipped adding ticket_date {ticket_date} as it falls on a public holiday and public holidays are excluded.")

#     print(f"Final json_data: {json_data}")
#     return json_data


# def frequency_month_wise(start, end, times, name, include_public_holiday, include_saturday=0, include_sunday=0):
#     interval = int(times)
#     begin_day_no = start.isoweekday()
#     begin_week_no = week_of_month(start)

#     where = {
#         'mdate__gte': start,
#         'mdate__lte': end,
#         'day_no': begin_day_no,
#         'week_no': begin_week_no
#     }

#     data = DateMaster.objects.filter(**where)

#     json_data = []
#     i = 0

#     for v in data:
#         ticket_date = v.mdate
#         print(f"Initial ticket_date: {ticket_date}")

#         # Adjust the ticket date based on the conditions
#         adjusted_ticket_date = adjust_ticket_date(ticket_date, include_public_holiday, include_saturday, include_sunday)
#         print(f"Adjusted ticket_date: {adjusted_ticket_date}")

#         # Interval check to add every `interval` instance
#         if interval == 1 or i % interval == 0:
#             # Create a new entry for json_data with adjusted date
#             cdata = {
#                 'ticket_date': adjusted_ticket_date.strftime('%Y-%m-%d'),
#                 'ticket_day': adjusted_ticket_date.strftime('%A'),  # Correctly set the day from the adjusted date
#                 'week_no': week_of_month(adjusted_ticket_date),  # Update week_no for adjusted date
#                 'frequency': name
#             }
#             json_data.append(cdata)
        
#         # Increment index
#         i += 1

#     print(f"Final json_data: {json_data}")

#     return json_data









# def frequency_week_wise(start, end, times, name, include_public_holiday=False, include_saturday=0, include_sunday=0):
#     start_str = start.strftime('%Y-%m-%d')
#     end_str = end.strftime('%Y-%m-%d')
    
#     begin = datetime.strptime(start_str, '%Y-%m-%d')
#     end = datetime.strptime(end_str, '%Y-%m-%d')    
#     interval = int(times)    
#     begin_day_no = begin.isoweekday() 
#     mjson = []    
    
#     for year in range(start.year, end.year + 1):
#         year_start = max(begin, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))
#         where = {
#             'mdate__gte': year_start,
#             'mdate__lte': year_end,
#             'day_no': begin_day_no,
#         }
        
#         data = DateMaster.objects.filter(**where)
#         if not data:
#             print("No data found for the given date range and criteria.")
#             return []

#         json_data = []
#         for i, d in enumerate(data):
#             if i % interval == 0 or interval == 1:
#                 # Convert mdate to datetime object if it's not already
#                 if isinstance(d.mdate, str):
#                     d.mdate = datetime.strptime(d.mdate, '%Y-%m-%d')
#                 json_data.append(d)

#         for item in json_data:
#             # Adjust the ticket date according to the rules provided
#             ticket_date = adjust_ticket_date(item.mdate, include_public_holiday, include_saturday, include_sunday)

#             cdata = {
#                 'ticket_date': ticket_date.strftime('%Y-%m-%d'),  # Ensure date is in string format
#                 'ticket_day': ticket_date.strftime('%A'),  # Get the day of the week for the ticket date
#                 'week_no': item.week_no,
#                 'frequency': name
#             }
#             mjson.append(cdata)

#     return mjson


# def frequency_day_wise(start, end, times, name, include_holiday, include_saturday=0, include_sunday=0, include_sunday_only=0):
#     interval = int(times)
#     mjson = []

#     for year in range(start.year, end.year + 1):
#         year_start = max(start, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))

#         # Fetch the relevant records from DateMaster
#         data = DateMaster.objects.filter(mdate__range=[year_start, year_end])

#         for i, d in enumerate(data):
#             ticket_date = d.mdate
#             is_holiday = check_public_holiday(ticket_date)
#             ticket_day = ticket_date.strftime('%A')  # Get the day of the week

#             # If include_sunday_only is set to 1, only allow scheduling on Sundays
#             if include_sunday_only == 1:
#                 if ticket_day == 'Sunday':
#                     if include_holiday == 1 or (include_holiday == 0 and not is_holiday):
#                         if interval == 1 or i % interval == 0:
#                             cdata = {
#                                 'ticket_date': ticket_date.strftime('%Y-%m-%d'),
#                                 'ticket_day': ticket_day,
#                                 'week_no': week_of_month(ticket_date),
#                                 'frequency': name
#                             }
#                             mjson.append(cdata)
#             else:
#                 # Normal conditions for including Saturdays and Sundays
#                 if (include_holiday == 1 or (include_holiday == 0 and not is_holiday)):
#                     if (include_saturday == 1 or ticket_day != 'Saturday') and (include_sunday == 1 or ticket_day != 'Sunday'):
#                         if interval == 1 or i % interval == 0:
#                             cdata = {
#                                 'ticket_date': ticket_date.strftime('%Y-%m-%d'),
#                                 'ticket_day': ticket_day,
#                                 'week_no': week_of_month(ticket_date),
#                                 'frequency': name
#                             }
#                             mjson.append(cdata)

#     return mjson


# def generate_ticket_frequency(request):
#     if request.method != 'POST':
#         return JsonResponse({'error': 'Invalid request method'}, status=400)

#     start_date_str = request.POST.get('startdate')
#     end_date_str = request.POST.get('todate')
#     frequency_ids = request.POST.getlist('frequency_id')
#     print('frequency_ids',frequency_ids)
#     print('start_date_str',start_date_str)
#     print('end_date_str',end_date_str)

#     # Retrieve inclusion flags for weekends and public holidays
#     is_include_saturday = int(request.POST.get('is_include_saturday', '0'))  # Convert to integer
#     is_include_sunday = int(request.POST.get('is_include_sunday', '0'))  # Convert to integer
#     is_include_public_holiday = int(request.POST.get('is_include_public', '0'))  # Convert to integer
#     is_include_sunday_only = int(request.POST.get('sunday_only', '0'))  # Convert to integer
#     print("is_include_saturday",is_include_saturday)
#     print("is_include_sunday",is_include_sunday)
#     print("is_include_public_holiday",is_include_public_holiday)
#     print("is_include_sunday_only",is_include_sunday_only)

#     if not start_date_str or not end_date_str or not frequency_ids:
#         return JsonResponse({'error': 'Missing required parameters'}, status=400)

#     try:
#         start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
#         end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
#     except ValueError as e:
#         return JsonResponse({'error': f'Invalid date format: {e}'}, status=400)

#     result = []
#     existing_dates = set()  # To track dates and ensure only one ticket per day

#     for frequency_id in frequency_ids:
#         freq = get_object_or_404(frequency_table, id=frequency_id)
#         generated_result = []

#         # Call the appropriate frequency function based on the frequency type
#         if freq.frequency == 'YEAR':
#             generated_result.extend(frequency_year_wise(
#                 start_date, end_date, freq.times, freq.name,
#                 is_include_public_holiday, is_include_saturday, is_include_sunday
#             ))
#         elif freq.frequency == 'MONTH':
#             generated_result.extend(frequency_month_wise(
#                 start_date, end_date, freq.times, freq.name,
#                 is_include_public_holiday, is_include_saturday, is_include_sunday
#             ))
#         elif freq.frequency == 'WEEK':
#             generated_result.extend(frequency_week_wise(
#                 start_date, end_date, freq.times, freq.name,
#                 is_include_public_holiday, is_include_saturday, is_include_sunday
#             ))
#         elif freq.frequency == 'DAY':
#             generated_result.extend(frequency_day_wise(
#                  start_date, end_date, int(freq.times), freq.name,
#                 is_include_public_holiday, is_include_saturday, is_include_sunday, is_include_sunday_only
#             ))

#         # Ensure only one ticket per date
#         for ticket in generated_result:
#             ticket_date = ticket.get('ticket_date')
#             if ticket_date not in existing_dates:  # Check if the date is already added
#                 result.append(ticket)  # Append ticket if it's not a duplicate
#                 existing_dates.add(ticket_date)  # Add the date to the set

#     result_data = [{'ticket_date': date.get('ticket_date'), 'ticket_day': date.get('ticket_day'), 'frequency': date.get('frequency')} for date in result]
#     return JsonResponse(result_data, safe=False)




def week_of_month(dt):
    first_day = dt.replace(day=1)
    dom = dt.day
    adjusted_dom = dom + first_day.weekday()
    return int((adjusted_dom - 1) / 7) + 1


def frequency_year_wise(start, end, times, name):
    start_str = start.strftime('%Y-%m-%d')
    end_str = end.strftime('%Y-%m-%d')
    begin = datetime.strptime(start_str, '%Y-%m-%d')
    end = datetime.strptime(end_str, '%Y-%m-%d')
    interval = int(times)
    begin_day_no = begin.isoweekday()
    begin_week_no = week_of_month(begin) 

    where = {
        'day_no': begin_day_no,
        'week_no': begin_week_no,
        'mm': begin.month,
        'mdate__gte': begin,
        'mdate__lte': end,
        'mm': begin.month
    }
    # #print("parameter",where);

    data = list(DateMaster.objects.filter(**where))

    #print("Data table values:", data)

    if not data:
        #print("No data found in DateMaster table for the specified conditions.")
        return []

    json_data = []

    i = 0
    for v in data:
        if interval == 1 or i % interval == 0:
            cdata = {
                'ticket_date': v.mdate,  # Ensure this is a datetime.date or datetime.datetime object
                'ticket_day': v.day,
                'week_no': v.week_no,
                'frequency': name
            }
            json_data.append(cdata)
        i += 1

    return json_data


def frequency_week_wise(start, end, times, name):
    start_str = start.strftime('%Y-%m-%d')
    end_str = end.strftime('%Y-%m-%d')
    
    begin = datetime.strptime(start_str, '%Y-%m-%d')
    end = datetime.strptime(end_str, '%Y-%m-%d')    
    interval = int(times)    
    begin_day_no = begin.isoweekday() 
    mjson = []    
    for year in range(start.year, end.year + 1):
        year_start = max(begin, datetime(year, 1, 1))
        year_end = min(end, datetime(year, 12, 31))
        where = {
            'mdate__gte': year_start,
            'mdate__lte': year_end,
            'day_no': begin_day_no,
        }
        data = DateMaster.objects.filter(**where)

        json_data = []
        for i, d in enumerate(data):
            if i % interval == 0 or interval == 1:
                # Convert mdate to datetime object if it's not already
                if isinstance(d.mdate, str):
                    d.mdate = datetime.strptime(d.mdate, '%Y-%m-%d')
                json_data.append(d)

        for item in json_data:
            cdata = {
                'ticket_date': item.mdate.strftime('%Y-%m-%d'),  # Ensure date is in string format
                'ticket_day': item.day,
                'week_no': item.week_no,
                'frequency': name
            }
            mjson.append(cdata)
            #print(mjson)

    return mjson




from datetime import datetime
from .models import DateMaster

# def frequency_day_wise(start, end, times, name, is_include_saturday):
#     interval = int(times)
#     mjson = []

#     for year in range(start.year, end.year + 1):
#         year_start = max(start, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))

#         # Filter DateMaster based on day range and whether Saturday is included
#         data = DateMaster.objects.filter(
#             mdate__range=[year_start, year_end],
#             day_no__lte=7 if is_include_saturday else 5
#         )

#         begin_day_no = data.first().day_no if data.exists() else None
#         m = None  # Initialize for day adjustments

#         for i, d in enumerate(data):
#             # Adjust day intervals based on times value, similar to PHP logic
#             if interval == 1:
#                 # For interval = 1, include every day within the range
#                 cdata = {
#                     'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                     'ticket_day': d.day,
#                     'week_no': week_of_month(d.mdate),
#                     'frequency': name
#                 }
#                 mjson.append(cdata)

#             elif interval == 2:
#                 # Twice-weekly logic: Adjust by ±2 around begin_day_no
#                 if begin_day_no >= 4:
#                     m = begin_day_no - 2
#                 else:
#                     m = begin_day_no + 2

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             elif interval == 3:
#                 # Thrice-weekly logic: Adjust by ±3 around begin_day_no
#                 if begin_day_no >= 3:
#                     m = begin_day_no - 3
#                 else:
#                     m = begin_day_no + 3

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             else:
#                 # For other intervals, use regular modular check like PHP
#                 if i % interval == 0:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#     return mjson

def frequency_month_wise(start, end, times, name):
    interval = int(times)
    begin_day_no = start.isoweekday()
    begin_week_no = week_of_month(start)

    where = {
        'mdate__gte': start,
        'mdate__lte': end,
        'day_no': begin_day_no,
        'week_no': begin_week_no
    }

    data = DateMaster.objects.filter(**where)

    json_data = []
    i = 0
    for v in data:
        if interval == 1 or i % interval == 0:
            json_data.append(v)
        i += 1

    mjson = []
    for item in json_data:
        cdata = {
            'ticket_date': item.mdate.strftime('%Y-%m-%d'),
            'ticket_day': item.day,
            'week_no': week_of_month(item.mdate),  # Using week_of_month for each item's date
            'frequency': name
        }
        mjson.append(cdata)

    return mjson


# def generate_ticket_frequency(request):
#     if request.method != 'POST':
#         return JsonResponse({'error': 'Invalid request method'}, status=400)
    
#     start_date_str = request.POST.get('startdate')
#     end_date_str = request.POST.get('todate')
#     asset_id = request.POST.get('edit_id')
#     frequency_ids = request.POST.getlist('frequency_id')
#     is_include_saturday = request.POST.get('is_include_saturday', '0') == '1'
#     print('start_date_str',start_date_str)
#     print('end_date_str',end_date_str)
#     print('asset_id',asset_id)
#     print('frequency_ids',frequency_ids)
#     print('is_include_saturday',is_include_saturday)
    
#     if not start_date_str or not end_date_str or not frequency_ids:
#         return JsonResponse({'error': 'Missing required parameters'}, status=400)

#     try:
#         start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
#         end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
#     except ValueError as e:
#         return JsonResponse({'error': f'Invalid date format: {e}'}, status=400)

#     result = []

#     for frequency_id in frequency_ids:
#         freq = get_object_or_404(frequency_table, id=frequency_id)
#         generated_result = []

#         if freq.frequency == 'YEAR':
#             generated_result.extend(frequency_year_wise(start_date, end_date, freq.times, freq.name))
#         elif freq.frequency == 'MONTH':
#             generated_result.extend(frequency_month_wise(start_date, end_date, freq.times, freq.name))
#         elif freq.frequency == 'WEEK':
#             generated_result.extend(frequency_week_wise(start_date, end_date, freq.times, freq.name))
#         elif freq.frequency == 'DAY':
#             generated_result.extend(frequency_day_wise(start_date, end_date, int(freq.times), freq.name, is_include_saturday))
        
#         if generated_result:
#             result.extend(generated_result)

#     result_data = [{'ticket_date': date.get('ticket_date'), 'ticket_day': date.get('ticket_day'), 'frequency': date.get('frequency')} for date in result]

#     return JsonResponse(result_data, safe=False)
from datetime import datetime  # Ensure datetime is imported

from datetime import datetime  # Ensure datetime is imported

def generate_ticket_frequency(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=400)
    
    start_date_str = request.POST.get('startdate')
    end_date_str = request.POST.get('todate')
    asset_id = request.POST.get('edit_id')
    frequency_ids = request.POST.getlist('frequency_id')

    include_saturday = request.POST.get('include_saturday', '0') == '1'
    include_sunday = request.POST.get('include_sunday', '0') == '1'
    include_public_holiday = request.POST.get('include_ph', '0') == '1'
    include_sunday_only = request.POST.get('sunday_only', '0') == '1'
    public_holiday_only = request.POST.get('holiday_only', '0') == '1'
   

    if not start_date_str or not end_date_str or not frequency_ids:
        return JsonResponse({'error': 'Missing required parameters'}, status=400)

    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    except ValueError as e:
        return JsonResponse({'error': f'Invalid date format: {e}'}, status=400)

    result = []

    for frequency_id in frequency_ids:
        freq = get_object_or_404(frequency_table, id=frequency_id)
        generated_result = []

        if freq.frequency == 'YEAR':
            generated_result.extend(frequency_year_wise(start_date, end_date, freq.times, freq.name))
        elif freq.frequency == 'MONTH':
            generated_result.extend(frequency_month_wise(start_date, end_date, freq.times, freq.name))
        elif freq.frequency == 'WEEK':
            generated_result.extend(frequency_week_wise(start_date, end_date, freq.times, freq.name))
        elif freq.frequency == 'DAY':
            generated_result.extend(frequency_day_wise(start_date, end_date, int(freq.times), freq.name, include_saturday, include_sunday, include_sunday_only, include_public_holiday,public_holiday_only))
        
        if generated_result:
            result.extend(generated_result)

    result_data = [{'ticket_date': date.get('ticket_date'), 'ticket_day': date.get('ticket_day'), 'frequency': date.get('frequency')} for date in result]

    return JsonResponse(result_data, safe=False)




# def frequency_day_wise(start, end, times, name, include_saturday, include_sunday):
#     interval = int(times)
#     mjson = []
#     print('day include_saturday',include_saturday)
#     print('day include_sunday',include_sunday)

#     day_no_limit = 5  
#     if include_saturday and include_sunday:
#         print('condition true')
#         day_no_limit = 7  
#     elif include_saturday:
#         day_no_limit = 6  
    
#     for year in range(start.year, end.year + 1):
#         year_start = max(start, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))

#         # Filter DateMaster with custom day_no based on conditions
#         data = DateMaster.objects.filter(
#             mdate__range=[year_start, year_end],
#             day_no__lte=day_no_limit
#         )

#         begin_day_no = data.first().day_no if data.exists() else None

#         for i, d in enumerate(data):
#             if interval == 1:
#                 mjson.append({
#                     'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                     'ticket_day': d.day,
#                     'week_no': week_of_month(d.mdate),
#                     'frequency': name
#                 })
#             elif interval == 2:
#                 if d.day_no == begin_day_no or d.day_no == begin_day_no + 2:
#                     mjson.append({
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     })
#             elif interval == 3:
#                 if d.day_no == begin_day_no or d.day_no == begin_day_no + 3:
#                     mjson.append({
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     })
#             else:
#                 if i % interval == 0:
#                     mjson.append({
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     })

#     return mjson


from datetime import datetime
from .models import DateMaster

# def frequency_day_wise(start, end, times, name, is_include_saturday, include_sunday):
#     interval = int(times)
#     mjson = []

#     for year in range(start.year, end.year + 1):
#         year_start = max(start, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))

#         # Filter DateMaster based on day range and whether Saturday is included
#         day_limit = 7  # Default to all 7 days in a week
#         if not is_include_saturday:
#             day_limit = 6  # Exclude Saturday (limit to 6 days)
        
#         data = DateMaster.objects.filter(
#             mdate__range=[year_start, year_end],
#             day_no__lte=day_limit
#         )

#         begin_day_no = data.first().day_no if data.exists() else None
#         m = None  # Initialize for day adjustments

#         for i, d in enumerate(data):
#             # Skip Saturdays if is_include_saturday = False
#             if d.mdate.weekday() == 5 and not is_include_saturday:  # 5 is Saturday
#                 continue

#             # Skip Sundays if include_sunday = False
#             if d.mdate.weekday() == 6 and not include_sunday:  # 6 is Sunday
#                 continue

#             # Adjust day intervals based on times value
#             if interval == 1:
#                 # For interval = 1, include every day within the range
#                 cdata = {
#                     'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                     'ticket_day': d.day,
#                     'week_no': week_of_month(d.mdate),
#                     'frequency': name
#                 }
#                 mjson.append(cdata)

#             elif interval == 2:
#                 # Twice-weekly logic: Adjust by ±2 around begin_day_no
#                 if begin_day_no >= 4:
#                     m = begin_day_no - 2
#                 else:
#                     m = begin_day_no + 2

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             elif interval == 3:
#                 # Thrice-weekly logic: Adjust by ±3 around begin_day_no
#                 if begin_day_no >= 3:
#                     m = begin_day_no - 3
#                 else:
#                     m = begin_day_no + 3

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             else:
#                 # For other intervals, use regular modular check like PHP
#                 if i % interval == 0:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#     return mjson
from datetime import datetime
from .models import DateMaster

# def frequency_day_wise(start, end, times, name, is_include_saturday, include_sunday, include_sunday_only):
#     interval = int(times)
#     mjson = []

#     for year in range(start.year, end.year + 1):
#         year_start = max(start, datetime(year, 1, 1))
#         year_end = min(end, datetime(year, 12, 31))

#         # Filter DateMaster based on day range and whether Saturday is included
#         day_limit = 7  # Default to all 7 days in a week
#         if not is_include_saturday:
#             day_limit = 6  # Exclude Saturday (limit to 6 days)
        
#         data = DateMaster.objects.filter(
#             mdate__range=[year_start, year_end],
#             day_no__lte=day_limit
#         )

#         begin_day_no = data.first().day_no if data.exists() else None
#         m = None  # Initialize for day adjustments

#         for i, d in enumerate(data):
#             # Skip Saturdays if is_include_saturday = False
#             if d.mdate.weekday() == 5 and not is_include_saturday:  # 5 is Saturday
#                 continue

#             # Skip Sundays if include_sunday = False
#             if d.mdate.weekday() == 6 and not include_sunday:  # 6 is Sunday
#                 continue

#             # If include_sunday_only = 1, generate ticket only on Sundays
#             if include_sunday_only == 1 and d.mdate.weekday() != 6:  # Not Sunday (6 is Sunday)
#                 continue

#             # Adjust day intervals based on times value
#             if interval == 1:
#                 # For interval = 1, include every day within the range
#                 cdata = {
#                     'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                     'ticket_day': d.day,
#                     'week_no': week_of_month(d.mdate),
#                     'frequency': name
#                 }
#                 mjson.append(cdata)

#             elif interval == 2:
#                 # Twice-weekly logic: Adjust by ±2 around begin_day_no
#                 if begin_day_no >= 4:
#                     m = begin_day_no - 2
#                 else:
#                     m = begin_day_no + 2

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             elif interval == 3:
#                 # Thrice-weekly logic: Adjust by ±3 around begin_day_no
#                 if begin_day_no >= 3:
#                     m = begin_day_no - 3
#                 else:
#                     m = begin_day_no + 3

#                 if d.day_no == begin_day_no or d.day_no == m:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#             else:
#                 # For other intervals, use regular modular check like PHP
#                 if i % interval == 0:
#                     cdata = {
#                         'ticket_date': d.mdate.strftime('%Y-%m-%d'),
#                         'ticket_day': d.day,
#                         'week_no': week_of_month(d.mdate),
#                         'frequency': name
#                     }
#                     mjson.append(cdata)

#     return mjson


from datetime import datetime, timedelta
from .models import DateMaster, holiday_table

from datetime import datetime, timedelta
from .models import DateMaster, holiday_table

def frequency_day_wise(start, end, times, name, is_include_saturday, include_sunday, include_sunday_only, include_public_holiday, public_holiday_only):
    interval = int(times)
    mjson = []

    print('public_holiday_only',public_holiday_only)
    public_holidays = set(
        holiday.date for holiday in holiday_table.objects.filter(date__range=[start, end], is_active=1, status=1)
    )
    print(f"Public Holidays within the range {start} to {end}: {public_holidays}")

    for year in range(start.year, end.year + 1):
        year_start = max(start, datetime(year, 1, 1))
        year_end = min(end, datetime(year, 12, 31))

        day_limit = 7  # Default to all 7 days
        if not is_include_saturday:
            day_limit = 6  # Exclude Saturdays
        print(f"Year: {year}, Start Date: {year_start}, End Date: {year_end}, Day Limit: {day_limit}")

        data = DateMaster.objects.filter(
            mdate__range=[year_start, year_end],
            day_no__lte=day_limit
        )
        print(f"Total Dates from DateMaster for year {year}: {data.count()}")

        begin_day_no = data.first().day_no if data.exists() else None
        m = None

        for i, d in enumerate(data):
            print(f"Processing Date: {d.mdate}, Day No: {d.day_no}, Weekday: {d.mdate.weekday()}")

            # Check if we only want to generate tickets on public holidays
            if public_holiday_only == 1:
                if d.mdate not in public_holidays:
                    print(f"Skipping non-holiday date as public_holiday_only is set: {d.mdate}")
                    continue

            # Apply Saturday and Sunday filters if not limited to public holidays
            if public_holiday_only == 0:
                if d.mdate.weekday() == 5 and not is_include_saturday:
                    print(f"Skipping Saturday: {d.mdate}")
                    continue
                if d.mdate.weekday() == 6 and not include_sunday:
                    print(f"Skipping Sunday: {d.mdate}")
                    continue
                if include_sunday_only == 1 and d.mdate.weekday() != 6:
                    print(f"Skipping Non-Sunday as include_sunday_only is set: {d.mdate}")
                    continue

                # Skip public holidays if include_public_holiday = 0
                if d.mdate in public_holidays and include_public_holiday == 0:
                    print(f"Skipping Public Holiday: {d.mdate}")
                    continue

            # Adjust day intervals based on interval value
            if interval == 1:
                print(f"Adding daily ticket for date: {d.mdate}")
                mjson.append(create_ticket_data(d, name))
            elif interval == 2:
                m = begin_day_no - 2 if begin_day_no >= 4 else begin_day_no + 2
                if d.day_no == begin_day_no or d.day_no == m:
                    print(f"Adding twice-weekly ticket for date: {d.mdate}")
                    mjson.append(create_ticket_data(d, name))
            elif interval == 3:
                m = begin_day_no - 3 if begin_day_no >= 3 else begin_day_no + 3
                if d.day_no == begin_day_no or d.day_no == m:
                    print(f"Adding thrice-weekly ticket for date: {d.mdate}")
                    mjson.append(create_ticket_data(d, name))
            else:
                if i % interval == 0:
                    print(f"Adding ticket based on modular interval for date: {d.mdate}")
                    mjson.append(create_ticket_data(d, name))

    print("Generated Tickets:", mjson)
    return mjson


def create_ticket_data(d, frequency_name):
    return {
        'ticket_date': d.mdate.strftime('%Y-%m-%d'),
        'ticket_day': d.day,
        'week_no': week_of_month(d.mdate),
        'frequency': frequency_name
    }

from datetime import datetime, timedelta

def next_possible_workingday(mdate, frequency):
    # Get all active public holidays
    public_holidays = set(
        holiday.date for holiday in holiday_table.objects.filter(is_active=1, status=1)
    )
    
    # Get dates with tickets having the same frequency
    dates_with_same_frequency = set(
        ticket.date for ticket in ticket_table.objects.filter(frequency=frequency)
    )
    
    print(f"Checking next working day for date: {mdate}")
    
    # Convert mdate to a datetime object if it's a string
    if isinstance(mdate, str):
        mdate = datetime.strptime(mdate, '%Y-%m-%d')

    # Check each day and move to the next day if it's a holiday, Saturday, or Sunday
    while (mdate in public_holidays or mdate.weekday() >= 5 or mdate in dates_with_same_frequency):
        if mdate in public_holidays:
            print(f"{mdate} is a public holiday, moving to the next day.")
        elif mdate.weekday() >= 5:
            print(f"{mdate} is a weekend (Saturday or Sunday), moving to the next day.")
        elif mdate in dates_with_same_frequency:
            print(f"{mdate} already has a ticket with frequency '{frequency}', moving to the next day.")
        
        # Move to the next day
        mdate += timedelta(days=1)

    print(f"Next possible working day: {mdate}")
    return mdate.strftime('%Y-%m-%d')
