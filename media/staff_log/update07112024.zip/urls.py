from django.contrib import admin
from django.urls import path
from facility_app import views

from  facility_app.custom_views import customer_views

from django.contrib.auth import views as auth_views
from .views import * 
from django.urls import path, include
from rest_framework.routers import DefaultRouter


from django.contrib.auth.views import (
    LogoutView, 
    PasswordResetView, 
    PasswordResetDoneView, 
    PasswordResetConfirmView,
    PasswordResetCompleteView
)

urlpatterns = [

    path('login/', LoginView.as_view(), name='login'),  

    
    path('api/dashboard_summary/', DashboardView.as_view(), name='dashboard'),


    path('api/verify_asset/', AssetQrCode.as_view(), name='asset-qr'),


    path('api/create_ticket/', CreateNewTicket.as_view(), name='create_ticket'),


    path('api/ticket_summary/', TicketSummaryView.as_view(), name='ticket-summary'),


    path('api/asset_summary/', AssetSummaryView.as_view(), name='asset-summary'),


    path('api/employee_details/<int:employee_id>/', EmployeeDetais.as_view(), name='employee-detail'),


    path('api/ticket_report/<int:ticket_id>/', TicketReport.as_view(), name='ticket-detail'),


    path('api/asset_list/<int:asset_id>/', AssetList.as_view(), name='asset-detail'),   



    path('ticket_update/<int:ticket_id>/', TicketUpdate.as_view(), name='ticket-update'),



    path('file_upload/', FileUpload.as_view(), name='ticket-upload'),



    path('ticket_dates/', TicketDates.as_view(), name='tickets_by_technician'),



    path('ticket_lists/', TicketList.as_view(), name='filtered-tickets'),


    path('ticket_checklist/', ChecklistByTicketView.as_view(), name='checklist-tickets'),


    path('ticket_checklist_update/', UpdateTicketChecklist.as_view(), name='update-ticket-checklist'),


    path('ticket_history/<int:asset_id>/', TicketHistory.as_view(), name='asset-detail'),  

     path('api/generate_wobi/', export_ticket_data_api.as_view(), name='export_ticket_data_api'), 






    path('get_vendors_for_project/', views.get_vendors_for_project, name='get_vendors_by_project'),
    path('get_projects_for_vendor/', views.get_projects_for_vendor, name='get_projects_for_vendor'),
    path('load_employee/',views.load_employee),

    path('get_vendors/<int:project_id>/', views.get_vendors_by_project, name='get_vendors'),
    path('get_vendors/', get_all_vendors, name='get_all_vendors'),
    path('get_assets/<int:vendor_id>/', views.get_assets_by_vendor),
    path('get_assets/', get_all_assets,),

    path('get_projects_by_customer/<int:customer_id>/', views.get_projects_by_customer, name='get_projects_by_customer'),
    path('get_technicians/<int:vendor_id>/', views.get_technicians_by_vendor, name='get_technicians'),

    path('fetch_assets/', views.fetch_assets, name='fetch_assets'),
    path('fetch_assets2/',views.fetch_assets2),
    path('fetch_technicians/',views.fetch_technicians),











    path('', views.index),
    path('signin',views.signin),
    path('login',views.login),
    path('session_out',views.logout),
    path('auth_login/', views.auth_login, name='auth_login'),

    path('admin',views.dashboard),
    path('dashboard',views.dashboard),
    path('get_projects/',views.get_projects),
    path('get_assets/',views.get_assets),
    path('asset_dashboard/',views.asset_dashboard),
    path('ticket_dashboard/',views.ticket_dashboard),
    path('company',views.company),
    path('profile',views.profile),
    path('update_company/',views.update_company, name='update_company'),
    

    path('user_roles',views.user_roles),
    path('vendor/user_roles',views.user_roles),
    path('get_roles/',views.get_roles),
    path('view_roles/',views.view_roles),
    path('add_roles/',views.add_roles),
    path('privileges_update/',views.privileges_update),
    path('edit_roles/',views.edit_roles),
    path('update_roles/',views.update_roles),
    path('duplicate_add/',views.duplicate_add),
    path('role_duplicate/',views.role_duplicate),
    path('delete_roles/',views.delete_roles),
    path('refresh_privileges/',views.refresh_privileges),


    path('category_page',views.category),
    path('category_add/',views.category_add),
    path('category_view/',views.category_view),
    path('category_edit/',views.category_edit),
    path('category_update/',views.category_update),
    path('category_delete/',views.category_delete),


    path('brand',views.brand),
    path('brand_add/',views.brand_add),
    path('brand_view/',views.brand_view),
    path('brand_edit/',views.brand_edit),
    path('brand_update/',views.brand_update),
    path('brand_delete/',views.brand_delete),


    path('uom',views.uom),
    path('uom_add/',views.uom_add),
    path('uom_view/',views.uom_view),
    path('uom_edit/',views.uom_edit),
    path('uom_update/',views.uom_update),
    path('uom_delete/',views.uom_delete),

    path('holidays',views.holidays),
    path('holidays_add/',views.holidays_add),
    path('holidays_view/',views.holidays_view),
    path('holidays_edit/',views.holidays_edit),
    path('holidays_update/',views.holidays_update),
    path('holidays_delete/',views.holidays_delete),
    


    path('service_frequency',views.service_frequency),
    path('frequency_add/',views.frequency_add),
    path('frequency_view/',views.frequency_view),
    path('frequency_edit/',views.frequency_edit),
    path('frequency_update/',views.frequency_update),
    path('frequency_delete/',views.frequency_delete),


    path('asset_system',views.asset_system),
    path('system_add/',views.system_add),
    path('system_view/',views.system_view),
    path('system_edit/',views.system_edit),
    path('system_update/',views.system_update),
    path('system_delete/',views.system_delete),

    path('action_page/',views.action_page),
    path('action_add/',views.action_add),
    path('action_view/',views.action_view),
    path('action_edit/',views.action_edit),
    path('action_update/',views.action_update),
    path('action_delete/',views.action_delete),


    path('finding_page/',views.finding_page),
    path('finding_add/',views.finding_add),
    path('finding_view/',views.finding_view),
    path('finding_edit/',views.finding_edit),
    path('finding_update/',views.finding_update),
    path('finding_delete/',views.finding_delete),


    path('description_page/',views.description_page),
    path('description_add/',views.description_add),
    path('description_view/',views.description_view),
    path('description_edit/',views.description_edit),
    path('description_update/',views.description_update),
    path('description_delete/',views.description_delete),

    path('checklist_page/',views.checklist_page),
    path('checklist_add/',views.checklist_add),
    path('checklist_view/',views.checklist_view),
    path('checklist_edit/',views.checklist_edit),
    path('checklist_update/',views.checklist_update),
    path('checklist_delete/',views.checklist_delete),


    path('customer',views.customer),
    path('customer_add/',views.customer_add),
    path('customer_view/',views.customer_view),
    path('customer_edit/',views.customer_edit),
    path('customer_update/',views.customer_update),
    path('customer_delete/',views.customer_delete),


    path('vendors',views.vendor),
    path('vendor_add/',views.vendor_add),
    path('vendor_view/',views.vendor_view),
    path('vendor_edit/',views.vendor_edit),
    path('vendor_update/',views.vendor_update),
    path('vendor_delete/',views.vendor_delete),


    path('user_page/',views.user_page),
    path('user_add/',views.user_add),
    path('user_view/',views.user_view),
    path('user_edit/',views.user_edit),
    path('user_update/',views.user_update),
    path('user_delete/',views.user_delete),


    path('project_page/',views.project_page),
    path('project_add/',views.project_add),
    path('project_view/',views.project_view),
    path('project_edit/',views.project_edit),
    path('project_update/',views.project_update),
    path('project_delete/',views.project_delete),
    path('project',views.project),
    path('fetch_employees/',views.fetch_employees),
    path('fetch_asset_parents/',views.fetch_asset_parents),
    path('fetch_vendor_employee/',views.fetch_vendor_employee),
   

    path('asset/',views.asset),
    path('download/', views.download_file, name='download_file'),
    path('assets',views.asset),
    path('asset_page/',views.asset_page),
    path('ad_asset_page/',views.ad_asset_page),
    path('fetch_projects/', views.fetch_projects),
    path('asset_add/',views.asset_add),
    path('asset_view/',views.asset_view),
    path('asset_edit/',views.asset_edit),
    path('asset_update/',views.asset_update),
    path('load_asset/',views.load_asset),
    path('generate_schedule/',views.generate_schedule),
    path('ticket_page/',views.ticket_page),
    path('generate_ticket_frequency/', views.generate_ticket_frequency),
    path('bulk_upload_assets/',views.bulk_upload_assets),
    path('ticket_save/',views.ticket_save),
    path('load_movelist/',views.load_movelist),
    path('move_assets/',views.move_assets),
    path('asset_delete/',views.asset_delete),
    path('load_movelist2/',views.load_movelist2),
    path('ticket_view/',views.ticket_view),
    path('ticket_edit/',views.ticket_edit),
    path('ticket_update/',views.ticket_update),
    path('request_delete/',views.request_delete),
    path('attachment_file/',views.attachment_file),
    path('attach_update/',views.attach_update),
    path('print_btn/',views.print_btn),
    path('print_page/',views.print_page),
    path('transfer_btn/',views.transfer_btn),
    path('transfer_tickets/',views.transfer_tickets),
    path('appointments_add',views.service_add),
    path('generate_qar/',views.generate_qar),
    path('approve_ticket/',views.approve_ticket),
    path('asset_edit_view/',views.asset_edit_view),
    path('asset_vendor_edit/',views.asset_vendor_edit),
   # path('ticket_report/<int:ticket_id>/', ticket_report, name='ticket_report'),
   path('asset_vendor_update/',views.asset_vendor_update),
   path('asset_vendor_add/',views.asset_vendor_add),
   path('export_ticket_data/',views.export_ticket_data),
   path('download_zip/',views.download_zip),
   path('outstanding_report_summary/',views.outstanding_report_summary),
   path('completed_report_summary/',views.completed_report_summary),


   # QAR report
   path('generate_qar_report/',views.generate_qar_report),
   path('qar_report_completed/', qar_report_completed, name='qar_report_completed'),    
   path('list_view/',views.list_view),
   path('update_ticket_date/',views.update_ticket_date),
   path('qar_generator',views.qar_generator),
   path('qar_view/',views.qar_view),
   path('regenerateFile/',views.regenerateFile),
   # path('regenerate_qar_report/',views.regenerate_qar_report),
   path('month_wise_report/',views.month_wise_report),
   path('work_hour_report/',views.work_hour_report),
   path('delete_qar/',views.delete_qar),


    


    path('complaints',views.complaints),
    path('complaint_view/',views.complaint_view),
    path('complaint_show/',views.complaint_show),


    path('fetch_details/',views.fetch_details),
    path('new_ticket/',views.new_ticket),
    path('appointment_page',views.service_page),
    path('ticket_add',views.service_page),
    
    path('service_view/',views.service_view),

    path('request_summary',views.request_summary),


    path('pre_schedule',views.pre_schedule),
    path('assets_manager/<str:encoded_vendor_id>/', views.assets_manager),
    path('assets_manager/<str:encoded_vendor_id>/<str:encoded_project_id>/', views.assets_manager),
    path('assets_manager/<str:encoded_vendor_id>/<str:encoded_project_id>/<str:encoded_asset_id>/', views.assets_manager),
    path('schedule_view/',views.schedule_view),


    path('monthwise_summary',views.monthwise_summary),


    path('ticket_summary',views.ticket_summary),


    path('outstanding_summary',views.outstanding_summary),


    path('completed_summary',views.completed_summary),


    path('work_report',views.work_report),


    path('kpi_report',views.kpi_report),
    path('load_technician/',views.load_technician),
    path('load_schedule/',views.load_schedule),
    path('work_calendar',views.work_calendar),


    path('employee',views.employee),
    path('employee_view/',views.employee_view),
    path('employee_edit/',views.employee_edit),
    path('employee_add/',views.employee_add),
    path('employee_update/',views.employee_update),
    path('employee_delete/',views.employee_delete),
    path('service_request/<str:encoded_vendor_id>/<str:encoded_project_id>/<str:encoded_asset_id>/<str:encoded_technician_id>/', views.service_request),

    # ```````````````````````````````````````````*******************`````````````````````````````````````````````````



   # customer_views

   path('vendor/dashboard',customer_views.customer_side),
   path('user_login',customer_views.customer_side),

   # path('vendor/company',customer_views.ck_company),
   #  path('ck_update_company/<int:id>/', customer_views.ck_update_company, name='ck_update_company'),

   
   # path('vendor/user_roles',customer_views.ck_user_roles),
   path('ck_get_roles/',customer_views.ck_get_roles),
   path('ck_view_roles/',customer_views.ck_view_roles),
   path('ck_add_roles/',customer_views.ck_add_roles),
   path('ck_privileges_update/',customer_views.ck_privileges_update),
   path('ck_edit_roles/',customer_views.ck_edit_roles),
   path('ck_update_roles/',customer_views.ck_update_roles),
   path('ck_duplicate_add/',customer_views.ck_duplicate_add),
   path('ck_role_duplicate/',customer_views.ck_role_duplicate),
   path('ck_delete_roles/',customer_views.ck_delete_roles),
   path('ck_refresh_privileges/',customer_views.ck_refresh_privileges),
   path('ck_asset_page/',customer_views.ck_asset_page),


   path('vendor/asset_group',customer_views.asset_group),
   path('ck_system_view/',customer_views.ck_system_view),

   path('ck_action_page/',customer_views.ck_action_page),
   path('ck_action_add/',customer_views.ck_action_add),
   path('ck_action_view/',customer_views.ck_action_view),

   path('ck_finding_page/',customer_views.ck_finding_page),
   path('ck_finding_add/',customer_views.ck_finding_add),
   path('ck_finding_view/',customer_views.ck_finding_view),

   path('ck_description_page/',customer_views.ck_description_page),
   path('ck_description_add/',customer_views.ck_description_add),
   path('ck_description_view/',customer_views.ck_description_view),


   path('ck_checklist_page/',customer_views.ck_checklist_page),
   path('ck_checklist_add/',customer_views.ck_checklist_add),
   path('ck_checklist_view/',customer_views.ck_checklist_view),


   path('vendor/complaints',customer_views.ck_compliants),
   path('ck_complaints_add/',customer_views.ck_complaints_add),
   path('ck_compliants_view/',customer_views.ck_compliants_view),
   path('ck_complaint_show/',customer_views.ck_complaint_show),


   path('vendor/projects',customer_views.ck_projects),
   path('ck_project_view/',customer_views.ck_project_view),
   path('ck_project_tab/',customer_views.ck_project_tab),
   path('ck_load_asset/',customer_views.ck_load_asset),
   path('ck_project_tab/',customer_views.ck_project_tab),
   path('ck_project_update/',customer_views.ck_project_update),
   path('ck_incharge_view/',customer_views.ck_incharge_view),

   path('vendor/asset',customer_views.ck_assets),
   path('ck_load_projects/',customer_views.ck_load_projects),
   path('ck_asset_view/',customer_views.ck_asset_view),
   path('ck_generate_schedule/',customer_views.ck_generate_schedule),

   path('ck_asset_list/',customer_views.ck_asset_list),
   path('ck_list_view/',customer_views.ck_list_view),
   path('ck_load_movelist/',customer_views.ck_load_movelist),
   path('ck_move_assets/',customer_views.ck_move_assets),
   path('ck_ticket_page/',customer_views.ck_ticket_page),
   path('ck_load_assets/',customer_views.ck_load_assets),
   path('ck_ticket_view/',customer_views.ck_ticket_view),

   path('ck_print_btn/',customer_views.ck_print_btn),
   path('ck_print_page/',customer_views.ck_print_page),
   path('ticket_approve/',customer_views.ticket_approve),
   path('ticket_report/',customer_views.ticket_report),

   
  
   path('generate_qr/', views.generate_qr, name='generate_qr'),
   path('qr_code/', views.display_qr_codes, name='display_qr_codes'),



    

























 
    


   

]